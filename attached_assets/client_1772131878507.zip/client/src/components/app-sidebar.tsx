import { useState, useCallback, useSyncExternalStore } from "react";
import { useLocation, Link } from "wouter";
import {
  LayoutDashboard,
  Users,
  Package,
  FileText,
  LifeBuoy,
  Building2,
  Store,
  MapPin,
  UserCog,
  Shield,
  Handshake,
  DollarSign,
  BookOpen,
  ArrowLeftRight,
  ListTodo,
  HardDrive,
  Boxes,
  Bell,
  BarChart3,
  Settings,
  Globe,
  LogOut,
  ChevronRight,
  ChevronDown,
  UserPlus,
  List,
  Wallet,
  Receipt,
  TrendingUp,
  Zap,
  GitBranch,
  ClipboardList,
  Calendar,
  Clock,
  BadgeDollarSign,
  Gift,
  Banknote,
  PalmtreeIcon,
  ShieldCheck,
  KeyRound,
  Search,
  Network,
  Layers,
  Send,
  MessageSquare,
  Mail,
  Megaphone,
  Hash,
  CreditCard,
  Activity,
  Radio,
  FileCheck,
  FolderOpen,
  Plus,
  Router,
  MonitorSmartphone,
  Gauge,
  Map,
  PieChart,
  Timer,
  Download,
  type LucideIcon,
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { apiRequest } from "@/lib/queryClient";

interface SubItem {
  title: string;
  url: string;
  icon: LucideIcon;
}

interface NavItem {
  title: string;
  icon: LucideIcon;
  url?: string;
  subItems?: SubItem[];
}

const dashboardNav: NavItem[] = [
  {
    title: "Dashboard",
    icon: LayoutDashboard,
    subItems: [
      { title: "Overview", url: "/?tab=overview", icon: LayoutDashboard },
      { title: "Customers Dashboard", url: "/?tab=customers", icon: Users },
      { title: "Revenue & Collection", url: "/?tab=revenue", icon: TrendingUp },
      { title: "Quick Actions", url: "/?tab=quick-actions", icon: Zap },
    ],
  },
];

const managementNav: NavItem[] = [
  {
    title: "Company Profile",
    icon: Building2,
    subItems: [
      { title: "Company Profile", url: "/company?tab=profile", icon: Building2 },
      { title: "Branches & Department", url: "/company?tab=branches", icon: GitBranch },
    ],
  },
  {
    title: "Vendors",
    icon: Store,
    subItems: [
      { title: "Vendor Type", url: "/vendors?tab=types", icon: Layers },
      { title: "Add Vendor", url: "/vendors?tab=add", icon: UserPlus },
      { title: "Vendor List", url: "/vendors?tab=list", icon: List },
      { title: "Vendor Packages", url: "/vendors?tab=packages", icon: Package },
      { title: "Bandwidth Changes", url: "/vendors?tab=bandwidth-changes", icon: Activity },
      { title: "Account & Ledger", url: "/vendors?tab=account", icon: BookOpen },
      { title: "Wallet & Billing", url: "/vendors?tab=wallet", icon: Wallet },
    ],
  },
  {
    title: "Packages",
    icon: Package,
    subItems: [
      { title: "Packages List", url: "/packages?tab=list", icon: List },
      { title: "Tax & Extra Fee", url: "/packages?tab=tax", icon: Receipt },
      { title: "Reseller Packages", url: "/packages?tab=reseller", icon: Handshake },
    ],
  },
  {
    title: "Area Management",
    icon: MapPin,
    subItems: [
      { title: "Add Area", url: "/areas?tab=add", icon: UserPlus },
      { title: "Area List", url: "/areas?tab=list", icon: List },
      { title: "Area Allocation", url: "/areas?tab=allocation", icon: MapPin },
      { title: "Service Availability", url: "/areas?tab=availability", icon: Search },
      { title: "Multi Branch Control", url: "/areas?tab=branch-control", icon: Network },
    ],
  },
];

const hrmNav: NavItem[] = [
  {
    title: "HR & Payroll",
    icon: UserCog,
    subItems: [
      { title: "Add Employee", url: "/hr?tab=add", icon: UserPlus },
      { title: "Employee List", url: "/hr?tab=list", icon: List },
      { title: "Employee Type/Role", url: "/hr?tab=roles", icon: Shield },
      { title: "Shift & Scheduling", url: "/hr?tab=shifts", icon: Clock },
      { title: "Attendance", url: "/hr?tab=attendance", icon: ClipboardList },
      { title: "Attendance Tracking", url: "/attendance", icon: Calendar },
      { title: "Employee Salary", url: "/hr?tab=salary", icon: BadgeDollarSign },
      { title: "Bonus & Commission", url: "/hr?tab=bonus", icon: Gift },
      { title: "Advance & Loan", url: "/hr?tab=advance", icon: Banknote },
      { title: "Holiday & Leave", url: "/hr?tab=leave", icon: PalmtreeIcon },
    ],
  },
  {
    title: "HRM",
    icon: ShieldCheck,
    subItems: [
      { title: "HRM Role & Type", url: "/access?tab=roles", icon: Shield },
      { title: "Staff User Login", url: "/access?tab=users", icon: KeyRound },
      { title: "Areas Allocation", url: "/access?tab=areas", icon: MapPin },
    ],
  },
];

const customerNav: NavItem[] = [
  {
    title: "Customers",
    icon: Users,
    subItems: [
      { title: "Customer Type", url: "/customers?tab=types", icon: Hash },
      { title: "Add New Customer", url: "/customers?tab=add", icon: UserPlus },
      { title: "Customer List", url: "/customers?tab=list", icon: List },
      { title: "New Client Request", url: "/customers?tab=query-new", icon: Search },
      { title: "Client Request", url: "/customers?tab=query-list", icon: ClipboardList },
    ],
  },
  {
    title: "Customer Portal",
    icon: MonitorSmartphone,
    url: "/customer-portal",
  },
  {
    title: "Reseller Management",
    icon: Handshake,
    subItems: [
      { title: "Reseller Type & Role", url: "/resellers?tab=types", icon: Hash },
      { title: "Add New Reseller", url: "/resellers?tab=add", icon: UserPlus },
      { title: "Reseller List", url: "/resellers?tab=list", icon: List },
      { title: "Wallet & Transaction", url: "/resellers?tab=wallet", icon: Wallet },
      { title: "Commission Report", url: "/resellers?tab=commission", icon: TrendingUp },
    ],
  },
];

const billingNav: NavItem[] = [
  {
    title: "Support & Ticket",
    icon: LifeBuoy,
    subItems: [
      { title: "Support Type", url: "/tickets?tab=types", icon: Hash },
      { title: "Open New Ticket", url: "/tickets?tab=new", icon: Plus },
      { title: "Support & Ticket", url: "/tickets?tab=list", icon: LifeBuoy },
      { title: "Support History", url: "/tickets?tab=history", icon: Clock },
    ],
  },
  {
    title: "Sale",
    icon: FileText,
    subItems: [
      { title: "Invoice Type", url: "/invoices?tab=types", icon: Hash },
      { title: "Add New Invoice", url: "/invoices?tab=add", icon: UserPlus },
      { title: "Invoice List", url: "/invoices?tab=list", icon: List },
      { title: "Daily Collection", url: "/daily-collection", icon: BadgeDollarSign },
      { title: "Collection Allocation", url: "/invoices?tab=allocation", icon: Receipt },
    ],
  },
  {
    title: "Accounting",
    icon: BookOpen,
    subItems: [
      { title: "Account Type", url: "/accounting?tab=types", icon: Hash },
      { title: "New Account", url: "/accounting?tab=add", icon: UserPlus },
      { title: "Income Entry", url: "/accounting?tab=income", icon: TrendingUp },
      { title: "Expense Entry", url: "/accounting?tab=expense", icon: Banknote },
      { title: "Budget Allocation", url: "/accounting?tab=budget", icon: DollarSign },
      { title: "Expense Tracking", url: "/expenses", icon: Receipt },
      { title: "Credit Notes", url: "/credit-notes", icon: CreditCard },
      { title: "Billing Rules", url: "/billing-rules", icon: Timer },
      { title: "Payment Gateway", url: "/payment-gateway", icon: Banknote },
    ],
  },
  {
    title: "Transactions",
    icon: ArrowLeftRight,
    subItems: [
      { title: "Transaction Type", url: "/transactions?tab=types", icon: Hash },
      { title: "Transactions List", url: "/transactions?tab=list", icon: List },
      { title: "Customer Collections", url: "/transactions?tab=customer-collections", icon: Users },
      { title: "Reseller Collections", url: "/transactions?tab=reseller-collections", icon: Handshake },
      { title: "Refund & Credit", url: "/transactions?tab=refund", icon: ArrowLeftRight },
      { title: "Transfer Account", url: "/transactions?tab=transfer", icon: Send },
      { title: "Wallet & Prepaid", url: "/transactions?tab=wallet", icon: Wallet },
      { title: "Approval Workflow", url: "/transactions?tab=approval", icon: FileCheck },
    ],
  },
];

const operationsNav: NavItem[] = [
  {
    title: "Task Management",
    icon: ListTodo,
    subItems: [
      { title: "Project", url: "/tasks?tab=projects", icon: FolderOpen },
      { title: "Tasks", url: "/tasks?tab=list", icon: ListTodo },
      { title: "Team Management", url: "/tasks?tab=team", icon: Users },
      { title: "Progress Tracking", url: "/tasks?tab=progress", icon: TrendingUp },
      { title: "Task Audit", url: "/tasks?tab=audit", icon: ClipboardList },
    ],
  },
  {
    title: "Network & IPAM",
    icon: Globe,
    subItems: [
      { title: "Network Monitoring", url: "/network-monitoring", icon: Gauge },
      { title: "MikroTik Integration", url: "/mikrotik", icon: Router },
      { title: "IP Addresses", url: "/ipam", icon: Network },
      { title: "RADIUS / AAA", url: "/radius", icon: Radio },
      { title: "Bandwidth Usage", url: "/bandwidth-usage", icon: Download },
      { title: "Customer Map", url: "/customer-map", icon: Map },
    ],
  },
  {
    title: "Service Outages",
    icon: Zap,
    subItems: [
      { title: "Outage Management", url: "/outages", icon: Activity },
    ],
  },
  {
    title: "Assets",
    icon: HardDrive,
    subItems: [
      { title: "Assets Type", url: "/assets?tab=types", icon: Hash },
      { title: "Assets List", url: "/assets?tab=list", icon: List },
      { title: "Request & Approvals", url: "/assets?tab=requests", icon: FileCheck },
      { title: "Asset Tracking", url: "/assets?tab=tracking", icon: Search },
      { title: "Asset Allocation", url: "/assets?tab=allocation", icon: Layers },
    ],
  },
  {
    title: "Inventory",
    icon: Boxes,
    subItems: [
      { title: "Product Type", url: "/inventory?tab=types", icon: Hash },
      { title: "Suppliers", url: "/inventory?tab=suppliers", icon: Store },
      { title: "Brands & Products", url: "/inventory?tab=brands", icon: Package },
      { title: "Purchase Order", url: "/inventory?tab=purchase-order", icon: FileText },
      { title: "Stock Management", url: "/inventory?tab=stock", icon: Boxes },
      { title: "Purchase", url: "/inventory?tab=purchase", icon: DollarSign },
      { title: "Sales", url: "/inventory?tab=sales", icon: TrendingUp },
      { title: "Inventory List", url: "/inventory?tab=list", icon: List },
      { title: "Batch & Serial", url: "/inventory?tab=batch", icon: Hash },
      { title: "Expiry & Warranty", url: "/inventory?tab=warranty", icon: Calendar },
    ],
  },
];

const systemNav: NavItem[] = [
  {
    title: "Notifications",
    icon: Bell,
    subItems: [
      { title: "Notification Type", url: "/notifications?tab=types", icon: Hash },
      { title: "Alert & Templates", url: "/notifications?tab=templates", icon: FileText },
      { title: "Push Notification", url: "/notifications?tab=push", icon: Bell },
      { title: "Bulk & Campaign", url: "/notifications?tab=bulk", icon: Megaphone },
      { title: "Bulk Messaging", url: "/bulk-messaging", icon: Send },
      { title: "SMS & Email API", url: "/notifications?tab=api", icon: MessageSquare },
    ],
  },
  {
    title: "All Reports",
    icon: BarChart3,
    subItems: [
      { title: "Reports", url: "/reports", icon: BarChart3 },
      { title: "Revenue Analytics", url: "/revenue-analytics", icon: PieChart },
      { title: "Aging Report", url: "/aging-report", icon: Timer },
    ],
  },
  {
    title: "Settings",
    icon: Settings,
    subItems: [
      { title: "General", url: "/settings?tab=general", icon: Settings },
      { title: "Company", url: "/settings?tab=company", icon: Building2 },
      { title: "Billing", url: "/settings?tab=billing", icon: CreditCard },
      { title: "HRM Rights Setup", url: "/settings?tab=hrm-rights", icon: ShieldCheck },
      { title: "Customer Rights", url: "/settings?tab=customer-rights", icon: Users },
      { title: "Invoice Template", url: "/settings?tab=invoice-template", icon: FileText },
      { title: "Notification Setting", url: "/settings?tab=notification", icon: Bell },
      { title: "Payment Gateway", url: "/settings?tab=payment", icon: CreditCard },
      { title: "Activity Log", url: "/settings?tab=activity-log", icon: Activity },
      { title: "Audit Log", url: "/audit-log", icon: Shield },
    ],
  },
];

function getBasePath(url: string) {
  return url.split("?")[0];
}

function subscribeToUrl(callback: () => void) {
  window.addEventListener("popstate", callback);
  window.addEventListener("pushstate", callback);
  window.addEventListener("replacestate", callback);
  return () => {
    window.removeEventListener("popstate", callback);
    window.removeEventListener("pushstate", callback);
    window.removeEventListener("replacestate", callback);
  };
}

function useSearch() {
  return useSyncExternalStore(subscribeToUrl, () => window.location.search, () => "");
}

function CollapsibleNavItem({ item }: { item: NavItem }) {
  const [location] = useLocation();
  const currentPath = location.split("?")[0];
  const currentSearch = useSearch();

  const isParentActive = item.subItems
    ? item.subItems.some((sub) => {
        const subPath = getBasePath(sub.url);
        return subPath === "/" ? currentPath === "/" : currentPath.startsWith(subPath);
      })
    : item.url
    ? getBasePath(item.url) === "/" ? currentPath === "/" : currentPath.startsWith(getBasePath(item.url))
    : false;

  const [isOpen, setIsOpen] = useState(isParentActive);

  if (!item.subItems) {
    const isActive = item.url
      ? getBasePath(item.url) === "/" ? currentPath === "/" : currentPath.startsWith(getBasePath(item.url))
      : false;
    return (
      <SidebarMenuItem>
        <SidebarMenuButton
          asChild
          data-active={isActive}
          className={`group relative mx-1 rounded-lg ${
            isActive
              ? "bg-white/12 text-white shadow-[0_0_12px_rgba(0,135,255,0.15)] border border-white/10"
              : "text-blue-100/70 border border-transparent"
          }`}
        >
          <Link href={item.url || "/"} data-testid={`nav-${item.title.toLowerCase().replace(/\s+/g, "-")}`}>
            <item.icon className={`h-4 w-4 transition-colors ${isActive ? "text-blue-300" : "text-blue-200/50 group-hover:text-blue-300/80"}`} />
            <span className="flex-1 text-[13px] font-medium">{item.title}</span>
            {isActive && <ChevronRight className="h-3.5 w-3.5 text-blue-300/60" />}
          </Link>
        </SidebarMenuButton>
      </SidebarMenuItem>
    );
  }

  return (
    <SidebarMenuItem>
      <Collapsible open={isOpen} onOpenChange={setIsOpen}>
        <CollapsibleTrigger asChild>
          <SidebarMenuButton
            data-testid={`nav-${item.title.toLowerCase().replace(/\s+/g, "-")}`}
            className={`group relative mx-1 rounded-lg cursor-pointer ${
              isParentActive
                ? "bg-white/8 text-white border border-white/8"
                : "text-blue-100/70 border border-transparent"
            }`}
          >
            <item.icon className={`h-4 w-4 transition-colors ${isParentActive ? "text-blue-300" : "text-blue-200/50 group-hover:text-blue-300/80"}`} />
            <span className="flex-1 text-[13px] font-medium">{item.title}</span>
            {isOpen ? (
              <ChevronDown className="h-3.5 w-3.5 text-blue-300/60 transition-transform" />
            ) : (
              <ChevronRight className="h-3.5 w-3.5 text-blue-200/40 transition-transform" />
            )}
          </SidebarMenuButton>
        </CollapsibleTrigger>
        <CollapsibleContent>
          <div className="ml-4 mt-0.5 mb-1 space-y-0.5 border-l border-white/8 pl-2">
            {item.subItems.map((sub) => {
              const subBasePath = getBasePath(sub.url);
              const subTab = sub.url.includes("?tab=") ? sub.url.split("?tab=")[1] : "";
              const currentTab = currentSearch.includes("tab=") ? new URLSearchParams(currentSearch).get("tab") || "" : "";
              const isSubActive = subBasePath === currentPath && (subTab === currentTab || (!currentTab && subTab === item.subItems![0].url.split("?tab=")[1]));

              return (
                <SidebarMenuButton
                  key={sub.title}
                  asChild
                  className={`rounded-md h-7 text-[12px] mx-0 ${
                    isSubActive
                      ? "bg-white/10 text-white font-medium"
                      : "text-blue-100/55 hover:text-blue-100/80 hover:bg-white/5"
                  }`}
                >
                  <Link href={sub.url} data-testid={`nav-sub-${sub.title.toLowerCase().replace(/\s+/g, "-")}`}>
                    <sub.icon className={`h-3 w-3 ${isSubActive ? "text-blue-300" : "text-blue-200/40"}`} />
                    <span>{sub.title}</span>
                  </Link>
                </SidebarMenuButton>
              );
            })}
          </div>
        </CollapsibleContent>
      </Collapsible>
    </SidebarMenuItem>
  );
}

function NavGroup({
  label,
  items,
}: {
  label: string;
  items: NavItem[];
}) {
  return (
    <SidebarGroup>
      <SidebarGroupLabel className="text-[10px] font-semibold uppercase tracking-[0.08em] text-blue-200/50 dark:text-blue-300/40 px-3 mb-0.5">
        {label}
      </SidebarGroupLabel>
      <SidebarGroupContent>
        <SidebarMenu>
          {items.map((item) => (
            <CollapsibleNavItem key={item.title} item={item} />
          ))}
        </SidebarMenu>
      </SidebarGroupContent>
    </SidebarGroup>
  );
}

export function AppSidebar() {
  const handleLogout = async () => {
    try {
      await apiRequest("POST", "/api/auth/logout");
      window.location.href = "/login";
    } catch {
      window.location.href = "/login";
    }
  };

  return (
    <Sidebar className="gradient-sidebar border-r-0">
      <SidebarHeader className="px-4 py-5">
        <Link href="/" className="flex items-center gap-3">
          <div className="flex items-center justify-center w-9 h-9 rounded-xl gradient-primary shadow-[0_2px_10px_rgba(0,87,255,0.3)]">
            <Globe className="h-4.5 w-4.5 text-white" />
          </div>
          <div className="flex flex-col">
            <span className="text-[15px] font-bold tracking-tight text-white" data-testid="text-brand-name">NetSphere</span>
            <span className="text-[10px] font-medium text-blue-200/50 tracking-wide uppercase">ISP Platform</span>
          </div>
        </Link>
      </SidebarHeader>
      <div className="mx-3 h-px bg-white/8" />
      <SidebarContent>
        <ScrollArea className="flex-1 py-2">
          <NavGroup label="Overview" items={dashboardNav} />
          <NavGroup label="Management" items={managementNav} />
          <NavGroup label="HR & People" items={hrmNav} />
          <NavGroup label="Customers & Resellers" items={customerNav} />
          <NavGroup label="Billing & Finance" items={billingNav} />
          <NavGroup label="Operations" items={operationsNav} />
          <NavGroup label="System" items={systemNav} />
        </ScrollArea>
      </SidebarContent>
      <div className="mx-3 h-px bg-white/8" />
      <SidebarFooter className="p-2">
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton
              onClick={handleLogout}
              data-testid="button-logout"
              className="mx-1 rounded-lg text-blue-100/60 hover:text-red-300 hover:bg-red-500/10 transition-all duration-200"
            >
              <LogOut className="h-4 w-4" />
              <span className="text-[13px] font-medium">Logout</span>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  );
}
