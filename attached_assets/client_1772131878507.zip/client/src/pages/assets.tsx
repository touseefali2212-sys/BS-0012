import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Plus,
  Search,
  MoreHorizontal,
  Edit,
  Trash2,
  HardDrive,
  CheckCircle,
  Wrench,
  AlertTriangle,
  XCircle,
  Router,
  Network,
  Cable,
  MapPin,
  Users,
  Clock,
  FileCheck,
  Package,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useTab } from "@/hooks/use-tab";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertAssetSchema, type Asset, type InsertAsset, type Vendor } from "@shared/schema";
import { z } from "zod";

const assetFormSchema = insertAssetSchema.extend({
  assetTag: z.string().min(1, "Asset tag is required"),
  name: z.string().min(2, "Name is required"),
  type: z.string().min(1, "Type is required"),
});

export default function AssetsPage() {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingAsset, setEditingAsset] = useState<Asset | null>(null);

  const { data: assets, isLoading } = useQuery<Asset[]>({
    queryKey: ["/api/assets"],
  });

  const { data: vendors } = useQuery<Vendor[]>({
    queryKey: ["/api/vendors"],
  });

  const form = useForm<InsertAsset>({
    resolver: zodResolver(assetFormSchema),
    defaultValues: {
      assetTag: "",
      name: "",
      type: "router",
      brand: "",
      model: "",
      serialNumber: "",
      vendorId: undefined,
      purchaseDate: "",
      purchaseCost: "",
      warrantyEnd: "",
      location: "",
      assignedTo: "",
      status: "available",
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertAsset) => {
      const res = await apiRequest("POST", "/api/assets", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/assets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      setDialogOpen(false);
      form.reset();
      toast({ title: "Asset created successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertAsset> }) => {
      const res = await apiRequest("PATCH", `/api/assets/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/assets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      setDialogOpen(false);
      setEditingAsset(null);
      form.reset();
      toast({ title: "Asset updated successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/assets/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/assets"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({ title: "Asset deleted" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const openCreate = () => {
    setEditingAsset(null);
    form.reset({
      assetTag: "",
      name: "",
      type: "router",
      brand: "",
      model: "",
      serialNumber: "",
      vendorId: undefined,
      purchaseDate: "",
      purchaseCost: "",
      warrantyEnd: "",
      location: "",
      assignedTo: "",
      status: "available",
    });
    setDialogOpen(true);
  };

  const openEdit = (asset: Asset) => {
    setEditingAsset(asset);
    form.reset({
      assetTag: asset.assetTag,
      name: asset.name,
      type: asset.type,
      brand: asset.brand || "",
      model: asset.model || "",
      serialNumber: asset.serialNumber || "",
      vendorId: asset.vendorId ?? undefined,
      purchaseDate: asset.purchaseDate || "",
      purchaseCost: asset.purchaseCost || "",
      warrantyEnd: asset.warrantyEnd || "",
      location: asset.location || "",
      assignedTo: asset.assignedTo || "",
      status: asset.status,
    });
    setDialogOpen(true);
  };

  const onSubmit = (data: InsertAsset) => {
    if (editingAsset) {
      updateMutation.mutate({ id: editingAsset.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const filtered = (assets || []).filter((a) => {
    const matchSearch =
      a.assetTag.toLowerCase().includes(search.toLowerCase()) ||
      a.name.toLowerCase().includes(search.toLowerCase()) ||
      (a.serialNumber || "").toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === "all" || a.status === statusFilter;
    const matchType = typeFilter === "all" || a.type === typeFilter;
    return matchSearch && matchStatus && matchType;
  });

  const [activeTab, setActiveTab] = useTab("list");

  const statusConfig: Record<string, { icon: any; color: string }> = {
    available: { icon: CheckCircle, color: "text-green-700 dark:text-green-300 bg-green-50 dark:bg-green-950" },
    deployed: { icon: Router, color: "text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950" },
    maintenance: { icon: Wrench, color: "text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950" },
    retired: { icon: XCircle, color: "text-gray-500 bg-gray-50 dark:bg-gray-900" },
    lost: { icon: AlertTriangle, color: "text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950" },
  };

  const assetTypes = [
    { name: "Routers", type: "router", icon: Router, description: "Network routers and gateways" },
    { name: "ONT Devices", type: "ONT", icon: Network, description: "Optical network terminals" },
    { name: "OLT Devices", type: "OLT", icon: Network, description: "Optical line terminals" },
    { name: "Switches", type: "switch", icon: HardDrive, description: "Network switches" },
    { name: "Cables", type: "cable", icon: Cable, description: "Fiber and ethernet cables" },
    { name: "Splitters", type: "splitter", icon: Package, description: "Fiber optic splitters" },
    { name: "UPS Units", type: "UPS", icon: HardDrive, description: "Uninterruptible power supplies" },
    { name: "Other", type: "other", icon: Package, description: "Other network equipment" },
  ];

  const getTypeCount = (type: string) => (assets || []).filter((a) => a.type === type).length;

  const deployedAssets = (assets || []).filter((a) => a.status === "deployed");
  const maintenanceAssets = (assets || []).filter((a) => a.status === "maintenance");
  const allocatedAssets = (assets || []).filter((a) => a.assignedTo);

  return (
    <div className="p-6 space-y-6 max-w-[1400px] mx-auto">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight" data-testid="text-assets-title">Network Assets</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Manage network equipment and assets</p>
        </div>
        <Button onClick={openCreate} data-testid="button-add-asset">
          <Plus className="h-4 w-4 mr-1" />
          Add Asset
        </Button>
      </div>

      {activeTab === "types" && (<div className="mt-5" data-testid="tab-content-types">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {assetTypes.map((at) => {
              const count = getTypeCount(at.type);
              const AtIcon = at.icon;
              return (
                <Card key={at.type} data-testid={`card-asset-type-${at.type}`}>
                  <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
                    <CardTitle className="text-sm font-medium">{at.name}</CardTitle>
                    <AtIcon className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold" data-testid={`text-type-count-${at.type}`}>{count}</div>
                    <p className="text-xs text-muted-foreground mt-1">{at.description}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>)}

      {activeTab === "list" && (<div className="mt-5" data-testid="tab-content-list">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 flex-wrap">
                <div className="relative flex-1 w-full sm:max-w-xs">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search assets..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="pl-9"
                    data-testid="input-search-assets"
                  />
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[160px]" data-testid="select-asset-status-filter">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="available">Available</SelectItem>
                    <SelectItem value="deployed">Deployed</SelectItem>
                    <SelectItem value="maintenance">Maintenance</SelectItem>
                    <SelectItem value="retired">Retired</SelectItem>
                    <SelectItem value="lost">Lost</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={typeFilter} onValueChange={setTypeFilter}>
                  <SelectTrigger className="w-[160px]" data-testid="select-asset-type-filter">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="router">Router</SelectItem>
                    <SelectItem value="ONT">ONT</SelectItem>
                    <SelectItem value="OLT">OLT</SelectItem>
                    <SelectItem value="switch">Switch</SelectItem>
                    <SelectItem value="cable">Cable</SelectItem>
                    <SelectItem value="splitter">Splitter</SelectItem>
                    <SelectItem value="UPS">UPS</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              {isLoading ? (
                <div className="p-5 space-y-3">
                  {[1, 2, 3].map((i) => (
                    <Skeleton key={i} className="h-14 w-full" />
                  ))}
                </div>
              ) : filtered.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                  <HardDrive className="h-12 w-12 mb-3 opacity-30" />
                  <p className="font-medium">No assets found</p>
                  <p className="text-sm mt-1">Add your first network asset</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Asset Tag</TableHead>
                        <TableHead>Name</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead className="hidden md:table-cell">Brand/Model</TableHead>
                        <TableHead className="hidden lg:table-cell">Location</TableHead>
                        <TableHead className="hidden lg:table-cell">Assigned To</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="w-10"></TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filtered.map((asset) => {
                        const config = statusConfig[asset.status] || statusConfig.available;
                        const StatusIcon = config.icon;
                        return (
                          <TableRow key={asset.id} data-testid={`row-asset-${asset.id}`}>
                            <TableCell className="font-mono text-xs" data-testid={`text-asset-tag-${asset.id}`}>
                              {asset.assetTag}
                            </TableCell>
                            <TableCell>
                              <div className="font-medium max-w-[200px] truncate">{asset.name}</div>
                            </TableCell>
                            <TableCell>
                              <Badge variant="secondary" className="no-default-active-elevate text-[10px] capitalize">
                                {asset.type}
                              </Badge>
                            </TableCell>
                            <TableCell className="hidden md:table-cell text-sm text-muted-foreground">
                              {[asset.brand, asset.model].filter(Boolean).join(" ") || "\u2014"}
                            </TableCell>
                            <TableCell className="hidden lg:table-cell text-sm text-muted-foreground">
                              {asset.location || "\u2014"}
                            </TableCell>
                            <TableCell className="hidden lg:table-cell text-sm text-muted-foreground">
                              {asset.assignedTo || "\u2014"}
                            </TableCell>
                            <TableCell>
                              <Badge variant="secondary" className={`no-default-active-elevate text-[10px] capitalize ${config.color}`}>
                                <StatusIcon className="h-3 w-3 mr-1" />
                                {asset.status}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon" data-testid={`button-asset-actions-${asset.id}`}>
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem onClick={() => openEdit(asset)} data-testid={`button-edit-asset-${asset.id}`}>
                                    <Edit className="h-4 w-4 mr-2" />
                                    Edit
                                  </DropdownMenuItem>
                                  <DropdownMenuItem
                                    className="text-destructive"
                                    onClick={() => deleteMutation.mutate(asset.id)}
                                    data-testid={`button-delete-asset-${asset.id}`}
                                  >
                                    <Trash2 className="h-4 w-4 mr-2" />
                                    Delete
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>)}

      {activeTab === "requests" && (<div className="mt-5" data-testid="tab-content-requests">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg">Request & Approvals</CardTitle>
              <p className="text-sm text-muted-foreground">Asset request and approval workflow</p>
            </CardHeader>
            <CardContent className="p-0">
              {isLoading ? (
                <div className="p-5 space-y-3">
                  {[1, 2, 3].map((i) => (
                    <Skeleton key={i} className="h-14 w-full" />
                  ))}
                </div>
              ) : (assets || []).length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                  <FileCheck className="h-12 w-12 mb-3 opacity-30" />
                  <p className="font-medium">No asset requests</p>
                  <p className="text-sm mt-1">Asset requests will appear here</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Asset</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Requested By</TableHead>
                        <TableHead>Request Date</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Approval</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {(assets || []).map((asset) => (
                        <TableRow key={asset.id} data-testid={`row-request-${asset.id}`}>
                          <TableCell className="font-medium" data-testid={`text-request-name-${asset.id}`}>
                            {asset.name}
                          </TableCell>
                          <TableCell>
                            <Badge variant="secondary" className="no-default-active-elevate text-[10px] capitalize">
                              {asset.type}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground" data-testid={`text-request-by-${asset.id}`}>
                            {asset.assignedTo || "Unassigned"}
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {asset.purchaseDate || "\u2014"}
                          </TableCell>
                          <TableCell>
                            <Badge variant="secondary" className={`no-default-active-elevate text-[10px] capitalize ${statusConfig[asset.status]?.color || ""}`}>
                              {asset.status}
                            </Badge>
                          </TableCell>
                          <TableCell data-testid={`text-approval-status-${asset.id}`}>
                            <Badge variant="secondary" className={`no-default-active-elevate text-[10px] ${asset.status === "deployed" ? "text-green-700 dark:text-green-300 bg-green-50 dark:bg-green-950" : asset.status === "available" ? "text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950" : "text-muted-foreground"}`}>
                              {asset.status === "deployed" ? "Approved" : asset.status === "available" ? "Pending" : "Review"}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>)}

      {activeTab === "tracking" && (<div className="mt-5" data-testid="tab-content-tracking">
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Card data-testid="card-tracking-deployed">
                <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
                  <CardTitle className="text-sm font-medium">Deployed Assets</CardTitle>
                  <Router className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold" data-testid="text-deployed-count">{deployedAssets.length}</div>
                  <p className="text-xs text-muted-foreground mt-1">Currently in the field</p>
                </CardContent>
              </Card>
              <Card data-testid="card-tracking-maintenance">
                <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
                  <CardTitle className="text-sm font-medium">Under Maintenance</CardTitle>
                  <Wrench className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold" data-testid="text-maintenance-count">{maintenanceAssets.length}</div>
                  <p className="text-xs text-muted-foreground mt-1">Being serviced or repaired</p>
                </CardContent>
              </Card>
              <Card data-testid="card-tracking-total">
                <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
                  <CardTitle className="text-sm font-medium">Total Assets</CardTitle>
                  <HardDrive className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold" data-testid="text-total-count">{(assets || []).length}</div>
                  <p className="text-xs text-muted-foreground mt-1">All tracked assets</p>
                </CardContent>
              </Card>
            </div>
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Asset Locations & Status</CardTitle>
                <p className="text-sm text-muted-foreground">Track asset locations and maintenance history</p>
              </CardHeader>
              <CardContent className="p-0">
                {isLoading ? (
                  <div className="p-5 space-y-3">
                    {[1, 2, 3].map((i) => (
                      <Skeleton key={i} className="h-14 w-full" />
                    ))}
                  </div>
                ) : (assets || []).length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                    <MapPin className="h-12 w-12 mb-3 opacity-30" />
                    <p className="font-medium">No assets to track</p>
                    <p className="text-sm mt-1">Add assets to start tracking</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Asset Tag</TableHead>
                          <TableHead>Name</TableHead>
                          <TableHead>Location</TableHead>
                          <TableHead>Assigned To</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Last Updated</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {(assets || []).map((asset) => {
                          const config = statusConfig[asset.status] || statusConfig.available;
                          const StatusIcon = config.icon;
                          return (
                            <TableRow key={asset.id} data-testid={`row-tracking-${asset.id}`}>
                              <TableCell className="font-mono text-xs" data-testid={`text-tracking-tag-${asset.id}`}>
                                {asset.assetTag}
                              </TableCell>
                              <TableCell className="font-medium">{asset.name}</TableCell>
                              <TableCell data-testid={`text-tracking-location-${asset.id}`}>
                                <div className="flex items-center gap-1.5 text-sm">
                                  <MapPin className="h-3.5 w-3.5 text-muted-foreground" />
                                  {asset.location || "Unassigned"}
                                </div>
                              </TableCell>
                              <TableCell className="text-sm text-muted-foreground">
                                {asset.assignedTo || "\u2014"}
                              </TableCell>
                              <TableCell>
                                <Badge variant="secondary" className={`no-default-active-elevate text-[10px] capitalize ${config.color}`}>
                                  <StatusIcon className="h-3 w-3 mr-1" />
                                  {asset.status}
                                </Badge>
                              </TableCell>
                              <TableCell className="text-sm text-muted-foreground">
                                <div className="flex items-center gap-1.5">
                                  <Clock className="h-3.5 w-3.5" />
                                  {asset.purchaseDate || "\u2014"}
                                </div>
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>)}

      {activeTab === "allocation" && (<div className="mt-5" data-testid="tab-content-allocation">
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Card data-testid="card-allocated-count">
                <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
                  <CardTitle className="text-sm font-medium">Allocated Assets</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold" data-testid="text-allocated-count">{allocatedAssets.length}</div>
                  <p className="text-xs text-muted-foreground mt-1">Assigned to employees or locations</p>
                </CardContent>
              </Card>
              <Card data-testid="card-unallocated-count">
                <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
                  <CardTitle className="text-sm font-medium">Unallocated Assets</CardTitle>
                  <Package className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold" data-testid="text-unallocated-count">{(assets || []).length - allocatedAssets.length}</div>
                  <p className="text-xs text-muted-foreground mt-1">Available for assignment</p>
                </CardContent>
              </Card>
            </div>
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Asset Allocation</CardTitle>
                <p className="text-sm text-muted-foreground">Assets assigned to employees and locations</p>
              </CardHeader>
              <CardContent className="p-0">
                {isLoading ? (
                  <div className="p-5 space-y-3">
                    {[1, 2, 3].map((i) => (
                      <Skeleton key={i} className="h-14 w-full" />
                    ))}
                  </div>
                ) : allocatedAssets.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                    <Users className="h-12 w-12 mb-3 opacity-30" />
                    <p className="font-medium">No allocated assets</p>
                    <p className="text-sm mt-1">Assign assets to employees or locations</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Asset Tag</TableHead>
                          <TableHead>Name</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Assigned To</TableHead>
                          <TableHead>Location</TableHead>
                          <TableHead>Status</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {allocatedAssets.map((asset) => {
                          const config = statusConfig[asset.status] || statusConfig.available;
                          const StatusIcon = config.icon;
                          return (
                            <TableRow key={asset.id} data-testid={`row-allocation-${asset.id}`}>
                              <TableCell className="font-mono text-xs" data-testid={`text-allocation-tag-${asset.id}`}>
                                {asset.assetTag}
                              </TableCell>
                              <TableCell className="font-medium">{asset.name}</TableCell>
                              <TableCell>
                                <Badge variant="secondary" className="no-default-active-elevate text-[10px] capitalize">
                                  {asset.type}
                                </Badge>
                              </TableCell>
                              <TableCell data-testid={`text-allocation-assigned-${asset.id}`}>
                                <div className="flex items-center gap-1.5 text-sm">
                                  <Users className="h-3.5 w-3.5 text-muted-foreground" />
                                  {asset.assignedTo}
                                </div>
                              </TableCell>
                              <TableCell data-testid={`text-allocation-location-${asset.id}`}>
                                <div className="flex items-center gap-1.5 text-sm">
                                  <MapPin className="h-3.5 w-3.5 text-muted-foreground" />
                                  {asset.location || "No location"}
                                </div>
                              </TableCell>
                              <TableCell>
                                <Badge variant="secondary" className={`no-default-active-elevate text-[10px] capitalize ${config.color}`}>
                                  <StatusIcon className="h-3 w-3 mr-1" />
                                  {asset.status}
                                </Badge>
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>)}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingAsset ? "Edit Asset" : "Add Asset"}</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="assetTag"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Asset Tag</FormLabel>
                      <FormControl>
                        <Input placeholder="AST-001" data-testid="input-asset-tag" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Asset name" data-testid="input-asset-name" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Type</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value || "router"}>
                        <FormControl>
                          <SelectTrigger data-testid="select-asset-type">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="router">Router</SelectItem>
                          <SelectItem value="ONT">ONT</SelectItem>
                          <SelectItem value="OLT">OLT</SelectItem>
                          <SelectItem value="switch">Switch</SelectItem>
                          <SelectItem value="cable">Cable</SelectItem>
                          <SelectItem value="splitter">Splitter</SelectItem>
                          <SelectItem value="UPS">UPS</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Status</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value || "available"}>
                        <FormControl>
                          <SelectTrigger data-testid="select-asset-status">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="available">Available</SelectItem>
                          <SelectItem value="deployed">Deployed</SelectItem>
                          <SelectItem value="maintenance">Maintenance</SelectItem>
                          <SelectItem value="retired">Retired</SelectItem>
                          <SelectItem value="lost">Lost</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="brand"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Brand</FormLabel>
                      <FormControl>
                        <Input placeholder="Brand" data-testid="input-asset-brand" {...field} value={field.value || ""} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="model"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Model</FormLabel>
                      <FormControl>
                        <Input placeholder="Model" data-testid="input-asset-model" {...field} value={field.value || ""} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={form.control}
                name="serialNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Serial Number</FormLabel>
                    <FormControl>
                      <Input placeholder="Serial number" data-testid="input-asset-serial" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="vendorId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Vendor</FormLabel>
                    <Select
                      onValueChange={(v) => field.onChange(v === "none" ? undefined : parseInt(v))}
                      value={field.value?.toString() || "none"}
                    >
                      <FormControl>
                        <SelectTrigger data-testid="select-asset-vendor">
                          <SelectValue placeholder="Select vendor" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="none">No vendor</SelectItem>
                        {(vendors || []).map((v) => (
                          <SelectItem key={v.id} value={v.id.toString()}>
                            {v.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="grid grid-cols-3 gap-4">
                <FormField
                  control={form.control}
                  name="purchaseDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Purchase Date</FormLabel>
                      <FormControl>
                        <Input type="date" data-testid="input-asset-purchase-date" {...field} value={field.value || ""} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="purchaseCost"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Cost (Rs.)</FormLabel>
                      <FormControl>
                        <Input type="number" step="0.01" placeholder="0.00" data-testid="input-asset-cost" {...field} value={field.value || ""} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="warrantyEnd"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Warranty End</FormLabel>
                      <FormControl>
                        <Input type="date" data-testid="input-asset-warranty" {...field} value={field.value || ""} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="location"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Location</FormLabel>
                      <FormControl>
                        <Input placeholder="Location" data-testid="input-asset-location" {...field} value={field.value || ""} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="assignedTo"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Assigned To</FormLabel>
                      <FormControl>
                        <Input placeholder="Person or team" data-testid="input-asset-assigned-to" {...field} value={field.value || ""} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <DialogFooter>
                <Button type="button" variant="secondary" onClick={() => setDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending} data-testid="button-save-asset">
                  {createMutation.isPending || updateMutation.isPending ? "Saving..." : editingAsset ? "Update" : "Create"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
