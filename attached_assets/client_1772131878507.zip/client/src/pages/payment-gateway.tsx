import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Plus,
  Search,
  MoreHorizontal,
  Edit,
  Trash2,
  CreditCard,
  DollarSign,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  Wallet,
  Settings,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  insertPaymentSchema,
  type Payment,
  type InsertPayment,
  insertPaymentGatewaySchema,
  type PaymentGateway,
  type InsertPaymentGateway,
  type Customer,
} from "@shared/schema";
import { z } from "zod";

const paymentFormSchema = insertPaymentSchema.extend({
  paymentId: z.string().min(1, "Payment ID is required"),
  customerId: z.coerce.number().min(1, "Customer is required"),
  amount: z.string().min(1, "Amount is required"),
  method: z.string().min(1, "Method is required"),
  status: z.string().min(1, "Status is required"),
  paidAt: z.string().min(1, "Date is required"),
});

const gatewayFormSchema = insertPaymentGatewaySchema.extend({
  name: z.string().min(1, "Name is required"),
  provider: z.string().min(1, "Provider is required"),
  mode: z.string().min(1, "Mode is required"),
});

export default function PaymentGatewayPage() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("payments");
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [paymentDialogOpen, setPaymentDialogOpen] = useState(false);
  const [gatewayDialogOpen, setGatewayDialogOpen] = useState(false);
  const [editingPayment, setEditingPayment] = useState<Payment | null>(null);
  const [editingGateway, setEditingGateway] = useState<PaymentGateway | null>(null);

  const { data: payments, isLoading: paymentsLoading } = useQuery<(Payment & { customerName?: string })[]>({
    queryKey: ["/api/payments"],
  });

  const { data: gateways, isLoading: gatewaysLoading } = useQuery<PaymentGateway[]>({
    queryKey: ["/api/payment-gateways"],
  });

  const { data: customers } = useQuery<Customer[]>({
    queryKey: ["/api/customers"],
  });

  const paymentForm = useForm<InsertPayment>({
    resolver: zodResolver(paymentFormSchema),
    defaultValues: {
      paymentId: "",
      customerId: 0,
      invoiceId: undefined,
      amount: "",
      method: "cash",
      gateway: "",
      transactionRef: "",
      status: "completed",
      paidAt: new Date().toISOString().split("T")[0],
      receivedBy: "",
      notes: "",
    },
  });

  const gatewayForm = useForm<InsertPaymentGateway>({
    resolver: zodResolver(gatewayFormSchema),
    defaultValues: {
      name: "",
      provider: "cash",
      merchantId: "",
      apiKey: "",
      apiSecret: "",
      callbackUrl: "",
      mode: "test",
      isActive: false,
      supportedMethods: "",
      notes: "",
    },
  });

  const createPaymentMutation = useMutation({
    mutationFn: async (data: InsertPayment) => {
      const res = await apiRequest("POST", "/api/payments", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/payments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      setPaymentDialogOpen(false);
      paymentForm.reset();
      toast({ title: "Payment created successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const updatePaymentMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertPayment> }) => {
      const res = await apiRequest("PATCH", `/api/payments/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/payments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      setPaymentDialogOpen(false);
      setEditingPayment(null);
      paymentForm.reset();
      toast({ title: "Payment updated successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const deletePaymentMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/payments/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/payments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({ title: "Payment deleted" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const createGatewayMutation = useMutation({
    mutationFn: async (data: InsertPaymentGateway) => {
      const res = await apiRequest("POST", "/api/payment-gateways", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/payment-gateways"] });
      setGatewayDialogOpen(false);
      gatewayForm.reset();
      toast({ title: "Gateway created successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const updateGatewayMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertPaymentGateway> }) => {
      const res = await apiRequest("PATCH", `/api/payment-gateways/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/payment-gateways"] });
      setGatewayDialogOpen(false);
      setEditingGateway(null);
      gatewayForm.reset();
      toast({ title: "Gateway updated successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const deleteGatewayMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/payment-gateways/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/payment-gateways"] });
      toast({ title: "Gateway deleted" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const openCreatePayment = () => {
    setEditingPayment(null);
    paymentForm.reset({
      paymentId: "",
      customerId: 0,
      invoiceId: undefined,
      amount: "",
      method: "cash",
      gateway: "",
      transactionRef: "",
      status: "completed",
      paidAt: new Date().toISOString().split("T")[0],
      receivedBy: "",
      notes: "",
    });
    setPaymentDialogOpen(true);
  };

  const openEditPayment = (payment: Payment) => {
    setEditingPayment(payment);
    paymentForm.reset({
      paymentId: payment.paymentId,
      customerId: payment.customerId,
      invoiceId: payment.invoiceId ?? undefined,
      amount: payment.amount,
      method: payment.method,
      gateway: payment.gateway || "",
      transactionRef: payment.transactionRef || "",
      status: payment.status,
      paidAt: payment.paidAt,
      receivedBy: payment.receivedBy || "",
      notes: payment.notes || "",
    });
    setPaymentDialogOpen(true);
  };

  const openCreateGateway = () => {
    setEditingGateway(null);
    gatewayForm.reset({
      name: "",
      provider: "cash",
      merchantId: "",
      apiKey: "",
      apiSecret: "",
      callbackUrl: "",
      mode: "test",
      isActive: false,
      supportedMethods: "",
      notes: "",
    });
    setGatewayDialogOpen(true);
  };

  const openEditGateway = (gw: PaymentGateway) => {
    setEditingGateway(gw);
    gatewayForm.reset({
      name: gw.name,
      provider: gw.provider,
      merchantId: gw.merchantId || "",
      apiKey: gw.apiKey || "",
      apiSecret: gw.apiSecret || "",
      callbackUrl: gw.callbackUrl || "",
      mode: gw.mode,
      isActive: gw.isActive,
      supportedMethods: gw.supportedMethods || "",
      notes: gw.notes || "",
    });
    setGatewayDialogOpen(true);
  };

  const onSubmitPayment = (data: InsertPayment) => {
    if (editingPayment) {
      updatePaymentMutation.mutate({ id: editingPayment.id, data });
    } else {
      createPaymentMutation.mutate(data);
    }
  };

  const onSubmitGateway = (data: InsertPaymentGateway) => {
    if (editingGateway) {
      updateGatewayMutation.mutate({ id: editingGateway.id, data });
    } else {
      createGatewayMutation.mutate(data);
    }
  };

  const filteredPayments = (payments || []).filter((p) => {
    const matchSearch =
      p.paymentId.toLowerCase().includes(search.toLowerCase()) ||
      (p.customerName || "").toLowerCase().includes(search.toLowerCase()) ||
      (p.transactionRef || "").toLowerCase().includes(search.toLowerCase()) ||
      (p.gateway || "").toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === "all" || p.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const paymentStatusConfig: Record<string, { color: string }> = {
    completed: { color: "text-green-700 dark:text-green-300 bg-green-50 dark:bg-green-950" },
    pending: { color: "text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950" },
    failed: { color: "text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950" },
    refunded: { color: "text-purple-700 dark:text-purple-300 bg-purple-50 dark:bg-purple-950" },
  };

  const methodColors: Record<string, string> = {
    cash: "text-green-700 dark:text-green-300 bg-green-50 dark:bg-green-950",
    bank_transfer: "text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950",
    jazzcash: "text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950",
    easypaisa: "text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950",
    online: "text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-950",
  };

  const providerColors: Record<string, string> = {
    jazzcash: "text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950",
    easypaisa: "text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950",
    stripe: "text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-950",
    bank_transfer: "text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950",
    cash: "text-green-700 dark:text-green-300 bg-green-50 dark:bg-green-950",
  };

  const allPayments = payments || [];
  const totalPayments = allPayments.length;
  const todaysCollection = allPayments
    .filter((p) => p.paidAt === new Date().toISOString().split("T")[0] && p.status === "completed")
    .reduce((sum, p) => sum + parseFloat(p.amount), 0);
  const pendingPayments = allPayments.filter((p) => p.status === "pending").length;
  const activeGateways = (gateways || []).filter((g) => g.isActive).length;

  const summaryCards = [
    { title: "Total Payments", value: totalPayments, icon: CreditCard, color: "text-blue-600 dark:text-blue-400" },
    { title: "Today's Collection", value: `Rs ${todaysCollection.toFixed(0)}`, icon: DollarSign, color: "text-green-600 dark:text-green-400" },
    { title: "Pending Payments", value: pendingPayments, icon: Clock, color: "text-amber-600 dark:text-amber-400" },
    { title: "Active Gateways", value: activeGateways, icon: Wallet, color: "text-purple-600 dark:text-purple-400" },
  ];

  return (
    <div className="p-6 space-y-6 max-w-[1400px] mx-auto">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight" data-testid="text-payment-gateway-title">Payment Gateway</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Manage payments, collections, and gateway configurations</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {activeTab === "payments" ? (
            <Button onClick={openCreatePayment} data-testid="button-add-payment">
              <Plus className="h-4 w-4 mr-1" />
              Add Payment
            </Button>
          ) : (
            <Button onClick={openCreateGateway} data-testid="button-add-gateway">
              <Plus className="h-4 w-4 mr-1" />
              Add Gateway
            </Button>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {summaryCards.map((card) => (
          <Card key={card.title} data-testid={`card-summary-${card.title.toLowerCase().replace(/\s+/g, "-")}`}>
            <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
              <span className="text-sm font-medium text-muted-foreground">{card.title}</span>
              <card.icon className={`h-4 w-4 ${card.color}`} />
            </CardHeader>
            <CardContent>
              {paymentsLoading || gatewaysLoading ? (
                <Skeleton className="h-8 w-16" />
              ) : (
                <div className="text-2xl font-bold" data-testid={`text-summary-${card.title.toLowerCase().replace(/\s+/g, "-")}`}>
                  {card.value}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList data-testid="tabs-payment-gateway">
          <TabsTrigger value="payments" data-testid="tab-payments">Payments</TabsTrigger>
          <TabsTrigger value="gateway-config" data-testid="tab-gateway-config">Gateway Config</TabsTrigger>
        </TabsList>

        <TabsContent value="payments" className="mt-4">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
                <div className="relative flex-1 w-full sm:max-w-xs">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search payments..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="pl-9"
                    data-testid="input-search-payments"
                  />
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[160px]" data-testid="select-payment-status-filter">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="failed">Failed</SelectItem>
                    <SelectItem value="refunded">Refunded</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              {paymentsLoading ? (
                <div className="p-5 space-y-3">
                  {[1, 2, 3].map((i) => (
                    <Skeleton key={i} className="h-14 w-full" />
                  ))}
                </div>
              ) : filteredPayments.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                  <CreditCard className="h-12 w-12 mb-3 opacity-30" />
                  <p className="font-medium">No payments found</p>
                  <p className="text-sm mt-1">Add a new payment to get started</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Payment ID</TableHead>
                        <TableHead>Customer</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Method</TableHead>
                        <TableHead className="hidden md:table-cell">Gateway</TableHead>
                        <TableHead className="hidden lg:table-cell">Transaction Ref</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="hidden md:table-cell">Date</TableHead>
                        <TableHead className="hidden lg:table-cell">Received By</TableHead>
                        <TableHead className="w-10"></TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredPayments.map((payment) => {
                        const statusCfg = paymentStatusConfig[payment.status] || paymentStatusConfig.completed;
                        return (
                          <TableRow key={payment.id} data-testid={`row-payment-${payment.id}`}>
                            <TableCell>
                              <span className="font-mono font-medium" data-testid={`text-payment-id-${payment.id}`}>{payment.paymentId}</span>
                            </TableCell>
                            <TableCell className="text-sm" data-testid={`text-payment-customer-${payment.id}`}>
                              {payment.customerName || `#${payment.customerId}`}
                            </TableCell>
                            <TableCell>
                              <span className="font-medium" data-testid={`text-payment-amount-${payment.id}`}>Rs {payment.amount}</span>
                            </TableCell>
                            <TableCell>
                              <Badge variant="secondary" className={`no-default-active-elevate text-[10px] capitalize ${methodColors[payment.method] || ""}`} data-testid={`badge-payment-method-${payment.id}`}>
                                {payment.method.replace("_", " ")}
                              </Badge>
                            </TableCell>
                            <TableCell className="hidden md:table-cell text-sm text-muted-foreground">
                              {payment.gateway || "\u2014"}
                            </TableCell>
                            <TableCell className="hidden lg:table-cell text-sm text-muted-foreground font-mono">
                              {payment.transactionRef || "\u2014"}
                            </TableCell>
                            <TableCell>
                              <Badge variant="secondary" className={`no-default-active-elevate text-[10px] capitalize ${statusCfg.color}`} data-testid={`badge-payment-status-${payment.id}`}>
                                {payment.status}
                              </Badge>
                            </TableCell>
                            <TableCell className="hidden md:table-cell text-sm text-muted-foreground">
                              {payment.paidAt}
                            </TableCell>
                            <TableCell className="hidden lg:table-cell text-sm text-muted-foreground">
                              {payment.receivedBy || "\u2014"}
                            </TableCell>
                            <TableCell>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon" data-testid={`button-payment-actions-${payment.id}`}>
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem onClick={() => openEditPayment(payment)} data-testid={`button-edit-payment-${payment.id}`}>
                                    <Edit className="h-4 w-4 mr-2" />
                                    Edit
                                  </DropdownMenuItem>
                                  <DropdownMenuItem
                                    className="text-destructive"
                                    onClick={() => deletePaymentMutation.mutate(payment.id)}
                                    data-testid={`button-delete-payment-${payment.id}`}
                                  >
                                    <Trash2 className="h-4 w-4 mr-2" />
                                    Delete
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="gateway-config" className="mt-4">
          <Card>
            <CardContent className="p-0">
              {gatewaysLoading ? (
                <div className="p-5 space-y-3">
                  {[1, 2, 3].map((i) => (
                    <Skeleton key={i} className="h-14 w-full" />
                  ))}
                </div>
              ) : (gateways || []).length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                  <Settings className="h-12 w-12 mb-3 opacity-30" />
                  <p className="font-medium">No gateways configured</p>
                  <p className="text-sm mt-1">Add a payment gateway to get started</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead>Provider</TableHead>
                        <TableHead className="hidden md:table-cell">Merchant ID</TableHead>
                        <TableHead>Mode</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="hidden lg:table-cell">Supported Methods</TableHead>
                        <TableHead className="w-10"></TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {(gateways || []).map((gw) => (
                        <TableRow key={gw.id} data-testid={`row-gateway-${gw.id}`}>
                          <TableCell>
                            <span className="font-medium" data-testid={`text-gateway-name-${gw.id}`}>{gw.name}</span>
                          </TableCell>
                          <TableCell>
                            <Badge variant="secondary" className={`no-default-active-elevate text-[10px] capitalize ${providerColors[gw.provider] || ""}`} data-testid={`badge-gateway-provider-${gw.id}`}>
                              {gw.provider.replace("_", " ")}
                            </Badge>
                          </TableCell>
                          <TableCell className="hidden md:table-cell text-sm text-muted-foreground font-mono">
                            {gw.merchantId || "\u2014"}
                          </TableCell>
                          <TableCell>
                            <Badge
                              variant="secondary"
                              className={`no-default-active-elevate text-[10px] uppercase ${
                                gw.mode === "live"
                                  ? "text-green-700 dark:text-green-300 bg-green-50 dark:bg-green-950"
                                  : "text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950"
                              }`}
                              data-testid={`badge-gateway-mode-${gw.id}`}
                            >
                              {gw.mode}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge
                              variant="secondary"
                              className={`no-default-active-elevate text-[10px] capitalize ${
                                gw.isActive
                                  ? "text-green-700 dark:text-green-300 bg-green-50 dark:bg-green-950"
                                  : "text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950"
                              }`}
                              data-testid={`badge-gateway-status-${gw.id}`}
                            >
                              {gw.isActive ? "active" : "inactive"}
                            </Badge>
                          </TableCell>
                          <TableCell className="hidden lg:table-cell text-sm text-muted-foreground">
                            {gw.supportedMethods || "\u2014"}
                          </TableCell>
                          <TableCell>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button variant="ghost" size="icon" data-testid={`button-gateway-actions-${gw.id}`}>
                                  <MoreHorizontal className="h-4 w-4" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem onClick={() => openEditGateway(gw)} data-testid={`button-edit-gateway-${gw.id}`}>
                                  <Edit className="h-4 w-4 mr-2" />
                                  Edit
                                </DropdownMenuItem>
                                <DropdownMenuItem
                                  className="text-destructive"
                                  onClick={() => deleteGatewayMutation.mutate(gw.id)}
                                  data-testid={`button-delete-gateway-${gw.id}`}
                                >
                                  <Trash2 className="h-4 w-4 mr-2" />
                                  Delete
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog open={paymentDialogOpen} onOpenChange={setPaymentDialogOpen}>
        <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle data-testid="text-payment-dialog-title">
              {editingPayment ? "Edit Payment" : "Add Payment"}
            </DialogTitle>
          </DialogHeader>
          <Form {...paymentForm}>
            <form onSubmit={paymentForm.handleSubmit(onSubmitPayment)} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <FormField
                  control={paymentForm.control}
                  name="paymentId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Payment ID</FormLabel>
                      <FormControl>
                        <Input placeholder="PAY-001" {...field} data-testid="input-payment-id" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={paymentForm.control}
                  name="customerId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Customer</FormLabel>
                      <Select
                        onValueChange={(v) => field.onChange(parseInt(v))}
                        value={field.value ? String(field.value) : ""}
                      >
                        <FormControl>
                          <SelectTrigger data-testid="select-payment-customer">
                            <SelectValue placeholder="Select customer" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {(customers || []).map((c) => (
                            <SelectItem key={c.id} value={String(c.id)}>
                              {c.fullName} ({c.customerId})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={paymentForm.control}
                  name="amount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Amount</FormLabel>
                      <FormControl>
                        <Input type="number" step="0.01" placeholder="0.00" {...field} data-testid="input-payment-amount" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={paymentForm.control}
                  name="method"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Method</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-payment-method">
                            <SelectValue placeholder="Select method" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="cash">Cash</SelectItem>
                          <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
                          <SelectItem value="jazzcash">JazzCash</SelectItem>
                          <SelectItem value="easypaisa">Easypaisa</SelectItem>
                          <SelectItem value="online">Online</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={paymentForm.control}
                  name="gateway"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Gateway</FormLabel>
                      <FormControl>
                        <Input placeholder="Gateway name" {...field} value={field.value || ""} data-testid="input-payment-gateway" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={paymentForm.control}
                  name="transactionRef"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Transaction Ref</FormLabel>
                      <FormControl>
                        <Input placeholder="TXN-REF" {...field} value={field.value || ""} data-testid="input-payment-txn-ref" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={paymentForm.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Status</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-payment-status">
                            <SelectValue placeholder="Select status" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="completed">Completed</SelectItem>
                          <SelectItem value="pending">Pending</SelectItem>
                          <SelectItem value="failed">Failed</SelectItem>
                          <SelectItem value="refunded">Refunded</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={paymentForm.control}
                  name="paidAt"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Date</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} data-testid="input-payment-date" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={paymentForm.control}
                  name="receivedBy"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Received By</FormLabel>
                      <FormControl>
                        <Input placeholder="Staff name" {...field} value={field.value || ""} data-testid="input-payment-received-by" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={paymentForm.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem className="sm:col-span-2">
                      <FormLabel>Notes</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Additional notes..." {...field} value={field.value || ""} data-testid="input-payment-notes" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setPaymentDialogOpen(false)}
                  data-testid="button-cancel-payment"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={createPaymentMutation.isPending || updatePaymentMutation.isPending}
                  data-testid="button-submit-payment"
                >
                  {createPaymentMutation.isPending || updatePaymentMutation.isPending
                    ? "Saving..."
                    : editingPayment
                      ? "Update"
                      : "Create"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <Dialog open={gatewayDialogOpen} onOpenChange={setGatewayDialogOpen}>
        <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle data-testid="text-gateway-dialog-title">
              {editingGateway ? "Edit Gateway" : "Add Gateway"}
            </DialogTitle>
          </DialogHeader>
          <Form {...gatewayForm}>
            <form onSubmit={gatewayForm.handleSubmit(onSubmitGateway)} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <FormField
                  control={gatewayForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Gateway name" {...field} data-testid="input-gateway-name" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={gatewayForm.control}
                  name="provider"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Provider</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-gateway-provider">
                            <SelectValue placeholder="Select provider" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="jazzcash">JazzCash</SelectItem>
                          <SelectItem value="easypaisa">Easypaisa</SelectItem>
                          <SelectItem value="stripe">Stripe</SelectItem>
                          <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
                          <SelectItem value="cash">Cash</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={gatewayForm.control}
                  name="merchantId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Merchant ID</FormLabel>
                      <FormControl>
                        <Input placeholder="Merchant ID" {...field} value={field.value || ""} data-testid="input-gateway-merchant-id" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={gatewayForm.control}
                  name="apiKey"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>API Key</FormLabel>
                      <FormControl>
                        <Input placeholder="API Key" {...field} value={field.value || ""} data-testid="input-gateway-api-key" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={gatewayForm.control}
                  name="apiSecret"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>API Secret</FormLabel>
                      <FormControl>
                        <Input type="password" placeholder="API Secret" {...field} value={field.value || ""} data-testid="input-gateway-api-secret" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={gatewayForm.control}
                  name="callbackUrl"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Callback URL</FormLabel>
                      <FormControl>
                        <Input placeholder="https://..." {...field} value={field.value || ""} data-testid="input-gateway-callback-url" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={gatewayForm.control}
                  name="mode"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Mode</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-gateway-mode">
                            <SelectValue placeholder="Select mode" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="test">Test</SelectItem>
                          <SelectItem value="live">Live</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={gatewayForm.control}
                  name="isActive"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                      <FormLabel>Active</FormLabel>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          data-testid="switch-gateway-active"
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <FormField
                  control={gatewayForm.control}
                  name="supportedMethods"
                  render={({ field }) => (
                    <FormItem className="sm:col-span-2">
                      <FormLabel>Supported Methods</FormLabel>
                      <FormControl>
                        <Input placeholder="cash, bank_transfer, jazzcash" {...field} value={field.value || ""} data-testid="input-gateway-supported-methods" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={gatewayForm.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem className="sm:col-span-2">
                      <FormLabel>Notes</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Additional notes..." {...field} value={field.value || ""} data-testid="input-gateway-notes" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setGatewayDialogOpen(false)}
                  data-testid="button-cancel-gateway"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={createGatewayMutation.isPending || updateGatewayMutation.isPending}
                  data-testid="button-submit-gateway"
                >
                  {createGatewayMutation.isPending || updateGatewayMutation.isPending
                    ? "Saving..."
                    : editingGateway
                      ? "Update"
                      : "Create"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}