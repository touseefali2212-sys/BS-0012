import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Plus,
  Search,
  MoreHorizontal,
  Edit,
  Trash2,
  FileText,
  Shield,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Bell,
  BellOff,
  Play,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertBillingRuleSchema, type BillingRule, type InsertBillingRule } from "@shared/schema";
import { z } from "zod";

const billingRuleFormSchema = insertBillingRuleSchema.extend({
  name: z.string().min(1, "Name is required"),
  type: z.string().min(1, "Type is required"),
});

export default function BillingRulesPage() {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingRule, setEditingRule] = useState<BillingRule | null>(null);

  const { data: billingRules, isLoading } = useQuery<BillingRule[]>({
    queryKey: ["/api/billing-rules"],
  });

  const form = useForm<InsertBillingRule>({
    resolver: zodResolver(billingRuleFormSchema),
    defaultValues: {
      name: "",
      type: "late_fee",
      graceDays: 7,
      penaltyType: "fixed",
      penaltyAmount: undefined,
      penaltyPercent: undefined,
      maxPenalty: undefined,
      autoSuspendDays: 30,
      autoDisconnectDays: 60,
      notifyOnApply: true,
      isActive: true,
      description: "",
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertBillingRule) => {
      const res = await apiRequest("POST", "/api/billing-rules", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/billing-rules"] });
      setDialogOpen(false);
      form.reset();
      toast({ title: "Billing rule created successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertBillingRule> }) => {
      const res = await apiRequest("PATCH", `/api/billing-rules/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/billing-rules"] });
      setDialogOpen(false);
      setEditingRule(null);
      form.reset();
      toast({ title: "Billing rule updated successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/billing-rules/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/billing-rules"] });
      toast({ title: "Billing rule deleted" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const openCreate = () => {
    setEditingRule(null);
    form.reset({
      name: "",
      type: "late_fee",
      graceDays: 7,
      penaltyType: "fixed",
      penaltyAmount: undefined,
      penaltyPercent: undefined,
      maxPenalty: undefined,
      autoSuspendDays: 30,
      autoDisconnectDays: 60,
      notifyOnApply: true,
      isActive: true,
      description: "",
    });
    setDialogOpen(true);
  };

  const openEdit = (rule: BillingRule) => {
    setEditingRule(rule);
    form.reset({
      name: rule.name,
      type: rule.type,
      graceDays: rule.graceDays ?? 7,
      penaltyType: rule.penaltyType || "fixed",
      penaltyAmount: rule.penaltyAmount || undefined,
      penaltyPercent: rule.penaltyPercent || undefined,
      maxPenalty: rule.maxPenalty || undefined,
      autoSuspendDays: rule.autoSuspendDays ?? 30,
      autoDisconnectDays: rule.autoDisconnectDays ?? 60,
      notifyOnApply: rule.notifyOnApply ?? true,
      isActive: rule.isActive,
      description: rule.description || "",
    });
    setDialogOpen(true);
  };

  const onSubmit = (data: InsertBillingRule) => {
    if (editingRule) {
      updateMutation.mutate({ id: editingRule.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleRunBillingCheck = () => {
    toast({ title: "Billing rules check initiated" });
  };

  const filtered = (billingRules || []).filter((rule) => {
    const matchSearch = rule.name.toLowerCase().includes(search.toLowerCase());
    const matchType = typeFilter === "all" || rule.type === typeFilter;
    const matchStatus =
      statusFilter === "all" ||
      (statusFilter === "active" && rule.isActive) ||
      (statusFilter === "inactive" && !rule.isActive);
    return matchSearch && matchType && matchStatus;
  });

  const typeColors: Record<string, string> = {
    late_fee: "text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950",
    suspension: "text-red-700 dark:text-red-300 bg-red-50 dark:bg-red-950",
    disconnection: "text-purple-700 dark:text-purple-300 bg-purple-50 dark:bg-purple-950",
  };

  const allRules = billingRules || [];
  const totalRules = allRules.length;
  const activeRules = allRules.filter((r) => r.isActive).length;
  const lateFeeRules = allRules.filter((r) => r.type === "late_fee").length;
  const suspensionRules = allRules.filter((r) => r.type === "suspension").length;

  const summaryCards = [
    { title: "Total Rules", value: totalRules, icon: FileText, color: "text-blue-600 dark:text-blue-400" },
    { title: "Active Rules", value: activeRules, icon: CheckCircle, color: "text-green-600 dark:text-green-400" },
    { title: "Late Fee Rules", value: lateFeeRules, icon: AlertTriangle, color: "text-amber-600 dark:text-amber-400" },
    { title: "Suspension Rules", value: suspensionRules, icon: Shield, color: "text-red-600 dark:text-red-400" },
  ];

  return (
    <div className="p-6 space-y-6 max-w-[1400px] mx-auto">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight" data-testid="text-billing-rules-title">Billing Rules</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Configure auto late fee, suspension, and disconnection rules</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button variant="outline" onClick={handleRunBillingCheck} data-testid="button-run-billing-check">
            <Play className="h-4 w-4 mr-1" />
            Run Billing Check
          </Button>
          <Button onClick={openCreate} data-testid="button-add-billing-rule">
            <Plus className="h-4 w-4 mr-1" />
            Add Billing Rule
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {summaryCards.map((card) => (
          <Card key={card.title} data-testid={`card-summary-${card.title.toLowerCase().replace(/\s+/g, "-")}`}>
            <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
              <span className="text-sm font-medium text-muted-foreground">{card.title}</span>
              <card.icon className={`h-4 w-4 ${card.color}`} />
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-8 w-16" />
              ) : (
                <div className="text-2xl font-bold" data-testid={`text-summary-${card.title.toLowerCase().replace(/\s+/g, "-")}`}>
                  {card.value}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
            <div className="relative flex-1 w-full sm:max-w-xs">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search billing rules..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9"
                data-testid="input-search-billing-rules"
              />
            </div>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-[160px]" data-testid="select-billing-rule-type-filter">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="late_fee">Late Fee</SelectItem>
                <SelectItem value="suspension">Suspension</SelectItem>
                <SelectItem value="disconnection">Disconnection</SelectItem>
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[160px]" data-testid="select-billing-rule-status-filter">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-5 space-y-3">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-14 w-full" />
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
              <FileText className="h-12 w-12 mb-3 opacity-30" />
              <p className="font-medium">No billing rules found</p>
              <p className="text-sm mt-1">Add a new billing rule to get started</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead className="hidden md:table-cell">Grace Days</TableHead>
                    <TableHead className="hidden md:table-cell">Penalty Type</TableHead>
                    <TableHead className="hidden lg:table-cell">Penalty Amount</TableHead>
                    <TableHead className="hidden lg:table-cell">Max Penalty</TableHead>
                    <TableHead className="hidden xl:table-cell">Auto Suspend Days</TableHead>
                    <TableHead className="hidden xl:table-cell">Auto Disconnect Days</TableHead>
                    <TableHead className="hidden md:table-cell">Notify</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="w-10"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((rule) => (
                    <TableRow key={rule.id} data-testid={`row-billing-rule-${rule.id}`}>
                      <TableCell>
                        <span className="font-medium" data-testid={`text-billing-rule-name-${rule.id}`}>{rule.name}</span>
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary" className={`no-default-active-elevate text-[10px] capitalize ${typeColors[rule.type] || ""}`} data-testid={`badge-billing-rule-type-${rule.id}`}>
                          {rule.type.replace("_", " ")}
                        </Badge>
                      </TableCell>
                      <TableCell className="hidden md:table-cell text-sm text-muted-foreground">
                        {rule.graceDays ?? "\u2014"}
                      </TableCell>
                      <TableCell className="hidden md:table-cell text-sm text-muted-foreground capitalize">
                        {rule.penaltyType || "\u2014"}
                      </TableCell>
                      <TableCell className="hidden lg:table-cell text-sm text-muted-foreground">
                        {rule.penaltyType === "percentage"
                          ? rule.penaltyPercent ? `${rule.penaltyPercent}%` : "\u2014"
                          : rule.penaltyAmount ? `$${rule.penaltyAmount}` : "\u2014"}
                      </TableCell>
                      <TableCell className="hidden lg:table-cell text-sm text-muted-foreground">
                        {rule.maxPenalty ? `$${rule.maxPenalty}` : "\u2014"}
                      </TableCell>
                      <TableCell className="hidden xl:table-cell text-sm text-muted-foreground">
                        {rule.autoSuspendDays ?? "\u2014"}
                      </TableCell>
                      <TableCell className="hidden xl:table-cell text-sm text-muted-foreground">
                        {rule.autoDisconnectDays ?? "\u2014"}
                      </TableCell>
                      <TableCell className="hidden md:table-cell">
                        {rule.notifyOnApply ? (
                          <Bell className="h-4 w-4 text-green-600 dark:text-green-400" />
                        ) : (
                          <BellOff className="h-4 w-4 text-muted-foreground" />
                        )}
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant="secondary"
                          className={`no-default-active-elevate text-[10px] ${
                            rule.isActive
                              ? "text-green-700 dark:text-green-300 bg-green-50 dark:bg-green-950"
                              : "text-red-700 dark:text-red-300 bg-red-50 dark:bg-red-950"
                          }`}
                          data-testid={`badge-billing-rule-status-${rule.id}`}
                        >
                          {rule.isActive ? (
                            <><CheckCircle className="h-3 w-3 mr-1" />Active</>
                          ) : (
                            <><XCircle className="h-3 w-3 mr-1" />Inactive</>
                          )}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" data-testid={`button-billing-rule-actions-${rule.id}`}>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => openEdit(rule)} data-testid={`button-edit-billing-rule-${rule.id}`}>
                              <Edit className="h-4 w-4 mr-2" />
                              Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              className="text-destructive"
                              onClick={() => deleteMutation.mutate(rule.id)}
                              data-testid={`button-delete-billing-rule-${rule.id}`}
                            >
                              <Trash2 className="h-4 w-4 mr-2" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle data-testid="text-billing-rule-dialog-title">
              {editingRule ? "Edit Billing Rule" : "Add Billing Rule"}
            </DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem className="sm:col-span-2">
                      <FormLabel>Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Rule name" {...field} data-testid="input-billing-rule-name" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Type</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-billing-rule-type">
                            <SelectValue placeholder="Select type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="late_fee">Late Fee</SelectItem>
                          <SelectItem value="suspension">Suspension</SelectItem>
                          <SelectItem value="disconnection">Disconnection</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="graceDays"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Grace Days</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          placeholder="7"
                          {...field}
                          value={field.value ?? ""}
                          onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : undefined)}
                          data-testid="input-billing-rule-grace-days"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="penaltyType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Penalty Type</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value || "fixed"}>
                        <FormControl>
                          <SelectTrigger data-testid="select-billing-rule-penalty-type">
                            <SelectValue placeholder="Select penalty type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="fixed">Fixed</SelectItem>
                          <SelectItem value="percentage">Percentage</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="penaltyAmount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Penalty Amount</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          step="0.01"
                          placeholder="0.00"
                          {...field}
                          value={field.value ?? ""}
                          onChange={(e) => field.onChange(e.target.value || undefined)}
                          data-testid="input-billing-rule-penalty-amount"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="penaltyPercent"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Penalty Percent</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          step="0.01"
                          placeholder="0.00"
                          {...field}
                          value={field.value ?? ""}
                          onChange={(e) => field.onChange(e.target.value || undefined)}
                          data-testid="input-billing-rule-penalty-percent"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="maxPenalty"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Max Penalty</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          step="0.01"
                          placeholder="0.00"
                          {...field}
                          value={field.value ?? ""}
                          onChange={(e) => field.onChange(e.target.value || undefined)}
                          data-testid="input-billing-rule-max-penalty"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="autoSuspendDays"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Auto Suspend Days</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          placeholder="30"
                          {...field}
                          value={field.value ?? ""}
                          onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : undefined)}
                          data-testid="input-billing-rule-auto-suspend-days"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="autoDisconnectDays"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Auto Disconnect Days</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          placeholder="60"
                          {...field}
                          value={field.value ?? ""}
                          onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : undefined)}
                          data-testid="input-billing-rule-auto-disconnect-days"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="notifyOnApply"
                  render={({ field }) => (
                    <FormItem className="flex items-center justify-between rounded-lg border p-3">
                      <FormLabel className="text-sm font-medium">Notify on Apply</FormLabel>
                      <FormControl>
                        <Switch
                          checked={field.value ?? true}
                          onCheckedChange={field.onChange}
                          data-testid="switch-billing-rule-notify"
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="isActive"
                  render={({ field }) => (
                    <FormItem className="flex items-center justify-between rounded-lg border p-3">
                      <FormLabel className="text-sm font-medium">Active</FormLabel>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          data-testid="switch-billing-rule-active"
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem className="sm:col-span-2">
                      <FormLabel>Description</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Rule description..."
                          {...field}
                          value={field.value || ""}
                          data-testid="textarea-billing-rule-description"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <DialogFooter>
                <Button
                  type="submit"
                  disabled={createMutation.isPending || updateMutation.isPending}
                  data-testid="button-submit-billing-rule"
                >
                  {createMutation.isPending || updateMutation.isPending
                    ? "Saving..."
                    : editingRule
                      ? "Update Rule"
                      : "Create Rule"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}