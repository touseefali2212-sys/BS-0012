import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Plus,
  Search,
  MoreHorizontal,
  Edit,
  Trash2,
  Download,
  Activity,
  ArrowDown,
  ArrowUp,
  BarChart3,
  Users,
  Zap,
  Clock,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertBandwidthUsageSchema, type BandwidthUsage, type InsertBandwidthUsage, type Customer } from "@shared/schema";
import { z } from "zod";

const bandwidthFormSchema = insertBandwidthUsageSchema.extend({
  customerId: z.number().min(1, "Customer is required"),
  date: z.string().min(1, "Date is required"),
});

export default function BandwidthUsagePage() {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [dateFilter, setDateFilter] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<BandwidthUsage | null>(null);

  const { data: usageRecords, isLoading } = useQuery<(BandwidthUsage & { customerName?: string })[]>({
    queryKey: ["/api/bandwidth-usage"],
  });

  const { data: customers } = useQuery<Customer[]>({
    queryKey: ["/api/customers"],
  });

  const form = useForm<InsertBandwidthUsage>({
    resolver: zodResolver(bandwidthFormSchema),
    defaultValues: {
      customerId: 0,
      date: "",
      downloadMb: "0",
      uploadMb: "0",
      totalMb: "0",
      peakDownload: "",
      peakUpload: "",
      sessionCount: 1,
      avgLatency: "0",
    },
  });

  const watchDownload = form.watch("downloadMb");
  const watchUpload = form.watch("uploadMb");

  const autoCalcTotal = () => {
    const dl = parseFloat(String(watchDownload) || "0");
    const ul = parseFloat(String(watchUpload) || "0");
    form.setValue("totalMb", String((dl + ul).toFixed(2)));
  };

  const createMutation = useMutation({
    mutationFn: async (data: InsertBandwidthUsage) => {
      const res = await apiRequest("POST", "/api/bandwidth-usage", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bandwidth-usage"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      setDialogOpen(false);
      form.reset();
      toast({ title: "Bandwidth usage record created successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertBandwidthUsage> }) => {
      const res = await apiRequest("PATCH", `/api/bandwidth-usage/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bandwidth-usage"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      setDialogOpen(false);
      setEditingRecord(null);
      form.reset();
      toast({ title: "Bandwidth usage record updated successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/bandwidth-usage/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bandwidth-usage"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({ title: "Bandwidth usage record deleted" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const openCreate = () => {
    setEditingRecord(null);
    form.reset({
      customerId: 0,
      date: "",
      downloadMb: "0",
      uploadMb: "0",
      totalMb: "0",
      peakDownload: "",
      peakUpload: "",
      sessionCount: 1,
      avgLatency: "0",
    });
    setDialogOpen(true);
  };

  const openEdit = (record: BandwidthUsage) => {
    setEditingRecord(record);
    form.reset({
      customerId: record.customerId,
      date: record.date,
      downloadMb: record.downloadMb || "0",
      uploadMb: record.uploadMb || "0",
      totalMb: record.totalMb || "0",
      peakDownload: record.peakDownload || "",
      peakUpload: record.peakUpload || "",
      sessionCount: record.sessionCount ?? 1,
      avgLatency: record.avgLatency || "0",
    });
    setDialogOpen(true);
  };

  const onSubmit = (data: InsertBandwidthUsage) => {
    if (editingRecord) {
      updateMutation.mutate({ id: editingRecord.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleExport = () => {
    const records = filtered;
    if (records.length === 0) return;
    const headers = ["Customer Name", "Date", "Download (MB)", "Upload (MB)", "Total (MB)", "Peak Download", "Peak Upload", "Sessions", "Avg Latency (ms)"];
    const rows = records.map((r) => [
      getCustomerName(r.customerId),
      r.date,
      r.downloadMb || "0",
      r.uploadMb || "0",
      r.totalMb || "0",
      r.peakDownload || "",
      r.peakUpload || "",
      String(r.sessionCount ?? 0),
      r.avgLatency || "0",
    ]);
    const csv = [headers.join(","), ...rows.map((r) => r.map((c) => `"${c}"`).join(","))].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "bandwidth-usage.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  const getCustomerName = (customerId: number) => {
    const customer = (customers || []).find((c) => c.id === customerId);
    return customer ? customer.fullName : `Customer #${customerId}`;
  };

  const getDateRange = () => {
    const now = new Date();
    if (dateFilter === "today") {
      return now.toISOString().split("T")[0];
    } else if (dateFilter === "7days") {
      const d = new Date(now);
      d.setDate(d.getDate() - 7);
      return d.toISOString().split("T")[0];
    } else if (dateFilter === "30days") {
      const d = new Date(now);
      d.setDate(d.getDate() - 30);
      return d.toISOString().split("T")[0];
    }
    return null;
  };

  const filtered = (usageRecords || []).filter((record) => {
    const customerName = record.customerName || getCustomerName(record.customerId);
    const matchSearch = customerName.toLowerCase().includes(search.toLowerCase());

    let matchDate = true;
    const rangeStart = getDateRange();
    if (dateFilter === "today" && rangeStart) {
      matchDate = record.date === rangeStart;
    } else if (rangeStart) {
      matchDate = record.date >= rangeStart;
    }

    return matchSearch && matchDate;
  });

  const allRecords = usageRecords || [];
  const totalUsageGb = allRecords.reduce((sum, r) => sum + parseFloat(r.totalMb || "0"), 0) / 1024;
  const avgPerCustomer = allRecords.length > 0
    ? (allRecords.reduce((sum, r) => sum + parseFloat(r.totalMb || "0"), 0) / new Set(allRecords.map((r) => r.customerId)).size / 1024).toFixed(2)
    : "0";
  const peakDl = allRecords.reduce((max, r) => {
    const val = r.peakDownload || "0";
    return val > max ? val : max;
  }, "0");
  const todayStr = new Date().toISOString().split("T")[0];
  const sessionsToday = allRecords
    .filter((r) => r.date === todayStr)
    .reduce((sum, r) => sum + (r.sessionCount ?? 0), 0);

  const summaryCards = [
    { title: "Total Usage (GB)", value: totalUsageGb.toFixed(2), icon: Activity, color: "text-blue-600 dark:text-blue-400" },
    { title: "Avg Per Customer", value: `${avgPerCustomer} GB`, icon: Users, color: "text-green-600 dark:text-green-400" },
    { title: "Peak Download", value: peakDl, icon: Zap, color: "text-purple-600 dark:text-purple-400" },
    { title: "Sessions Today", value: sessionsToday, icon: Clock, color: "text-amber-600 dark:text-amber-400" },
  ];

  const customerUsageSummary = () => {
    const usageMap: Record<number, { name: string; total: number }> = {};
    allRecords.forEach((r) => {
      if (!usageMap[r.customerId]) {
        usageMap[r.customerId] = { name: getCustomerName(r.customerId), total: 0 };
      }
      usageMap[r.customerId].total += parseFloat(r.totalMb || "0");
    });
    return Object.entries(usageMap)
      .map(([id, data]) => ({ id: Number(id), name: data.name, totalMb: data.total }))
      .sort((a, b) => b.totalMb - a.totalMb)
      .slice(0, 10);
  };

  const topCustomers = customerUsageSummary();
  const maxUsage = topCustomers.length > 0 ? topCustomers[0].totalMb : 1;

  const barColors = [
    "bg-blue-500", "bg-green-500", "bg-purple-500", "bg-amber-500", "bg-red-500",
    "bg-cyan-500", "bg-pink-500", "bg-indigo-500", "bg-teal-500", "bg-orange-500",
  ];

  return (
    <div className="p-6 space-y-6 max-w-[1400px] mx-auto">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight" data-testid="text-bandwidth-title">Bandwidth Usage Reports</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Monitor and manage bandwidth consumption across customers</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button variant="outline" onClick={handleExport} data-testid="button-export-bandwidth">
            <Download className="h-4 w-4 mr-1" />
            Export CSV
          </Button>
          <Button onClick={openCreate} data-testid="button-add-bandwidth">
            <Plus className="h-4 w-4 mr-1" />
            Add Record
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {summaryCards.map((card) => (
          <Card key={card.title} data-testid={`card-summary-${card.title.toLowerCase().replace(/[\s()]/g, "-")}`}>
            <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
              <span className="text-sm font-medium text-muted-foreground">{card.title}</span>
              <card.icon className={`h-4 w-4 ${card.color}`} />
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-8 w-16" />
              ) : (
                <div className="text-2xl font-bold" data-testid={`text-summary-${card.title.toLowerCase().replace(/[\s()]/g, "-")}`}>
                  {card.value}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
            <div className="relative flex-1 w-full sm:max-w-xs">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by customer name..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9"
                data-testid="input-search-bandwidth"
              />
            </div>
            <Select value={dateFilter} onValueChange={setDateFilter}>
              <SelectTrigger className="w-[160px]" data-testid="select-date-filter">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Time</SelectItem>
                <SelectItem value="today">Today</SelectItem>
                <SelectItem value="7days">Last 7 Days</SelectItem>
                <SelectItem value="30days">Last 30 Days</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-5 space-y-3">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-14 w-full" />
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
              <BarChart3 className="h-12 w-12 mb-3 opacity-30" />
              <p className="font-medium">No bandwidth usage records found</p>
              <p className="text-sm mt-1">Add a new record to get started</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Customer Name</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Download (MB)</TableHead>
                    <TableHead>Upload (MB)</TableHead>
                    <TableHead>Total (MB)</TableHead>
                    <TableHead className="hidden md:table-cell">Peak Download</TableHead>
                    <TableHead className="hidden md:table-cell">Peak Upload</TableHead>
                    <TableHead className="hidden lg:table-cell">Sessions</TableHead>
                    <TableHead className="hidden lg:table-cell">Avg Latency (ms)</TableHead>
                    <TableHead className="w-10"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((record) => (
                    <TableRow key={record.id} data-testid={`row-bandwidth-${record.id}`}>
                      <TableCell>
                        <span className="font-medium" data-testid={`text-customer-name-${record.id}`}>
                          {record.customerName || getCustomerName(record.customerId)}
                        </span>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground" data-testid={`text-date-${record.id}`}>
                        {record.date}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <ArrowDown className="h-3 w-3 text-green-500" />
                          <span data-testid={`text-download-${record.id}`}>{record.downloadMb || "0"}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <ArrowUp className="h-3 w-3 text-blue-500" />
                          <span data-testid={`text-upload-${record.id}`}>{record.uploadMb || "0"}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <span className="font-medium" data-testid={`text-total-${record.id}`}>{record.totalMb || "0"}</span>
                      </TableCell>
                      <TableCell className="hidden md:table-cell text-sm text-muted-foreground">
                        {record.peakDownload || "\u2014"}
                      </TableCell>
                      <TableCell className="hidden md:table-cell text-sm text-muted-foreground">
                        {record.peakUpload || "\u2014"}
                      </TableCell>
                      <TableCell className="hidden lg:table-cell text-sm text-muted-foreground">
                        {record.sessionCount ?? 0}
                      </TableCell>
                      <TableCell className="hidden lg:table-cell text-sm text-muted-foreground">
                        {record.avgLatency || "\u2014"}
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" data-testid={`button-bandwidth-actions-${record.id}`}>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => openEdit(record)} data-testid={`button-edit-bandwidth-${record.id}`}>
                              <Edit className="h-4 w-4 mr-2" />
                              Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              className="text-destructive"
                              onClick={() => deleteMutation.mutate(record.id)}
                              data-testid={`button-delete-bandwidth-${record.id}`}
                            >
                              <Trash2 className="h-4 w-4 mr-2" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {!isLoading && topCustomers.length > 0 && (
        <Card data-testid="card-usage-summary">
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5 text-muted-foreground" />
              <span className="text-lg font-semibold">Top 10 Customers by Usage</span>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {topCustomers.map((customer, index) => (
                <div key={customer.id} className="space-y-1" data-testid={`bar-customer-${customer.id}`}>
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-medium">{customer.name}</span>
                    <span className="text-muted-foreground">{(customer.totalMb / 1024).toFixed(2)} GB</span>
                  </div>
                  <div className="h-3 w-full rounded-md bg-muted overflow-hidden">
                    <div
                      className={`h-full rounded-md ${barColors[index % barColors.length]}`}
                      style={{ width: `${Math.max((customer.totalMb / maxUsage) * 100, 2)}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle data-testid="text-dialog-title">
              {editingRecord ? "Edit Bandwidth Usage" : "Add Bandwidth Usage"}
            </DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="customerId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Customer</FormLabel>
                      <Select
                        onValueChange={(v) => field.onChange(parseInt(v))}
                        value={field.value ? String(field.value) : ""}
                      >
                        <FormControl>
                          <SelectTrigger data-testid="select-bandwidth-customer">
                            <SelectValue placeholder="Select customer" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {(customers || []).map((c) => (
                            <SelectItem key={c.id} value={String(c.id)}>
                              {c.fullName} ({c.customerId})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="date"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Date</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} data-testid="input-bandwidth-date" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="downloadMb"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Download (MB)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          step="0.01"
                          placeholder="0"
                          {...field}
                          value={field.value || ""}
                          onChange={(e) => {
                            field.onChange(e.target.value);
                            setTimeout(autoCalcTotal, 0);
                          }}
                          data-testid="input-download-mb"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="uploadMb"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Upload (MB)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          step="0.01"
                          placeholder="0"
                          {...field}
                          value={field.value || ""}
                          onChange={(e) => {
                            field.onChange(e.target.value);
                            setTimeout(autoCalcTotal, 0);
                          }}
                          data-testid="input-upload-mb"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="totalMb"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Total (MB)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          step="0.01"
                          placeholder="Auto-calculated"
                          {...field}
                          value={field.value || ""}
                          readOnly
                          className="bg-muted"
                          data-testid="input-total-mb"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="peakDownload"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Peak Download</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. 50 Mbps" {...field} value={field.value || ""} data-testid="input-peak-download" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="peakUpload"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Peak Upload</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. 20 Mbps" {...field} value={field.value || ""} data-testid="input-peak-upload" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="sessionCount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Session Count</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          placeholder="1"
                          {...field}
                          value={field.value ?? ""}
                          onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : undefined)}
                          data-testid="input-session-count"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="avgLatency"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Avg Latency (ms)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          step="0.01"
                          placeholder="0"
                          {...field}
                          value={field.value || ""}
                          data-testid="input-avg-latency"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <DialogFooter>
                <Button
                  type="submit"
                  disabled={createMutation.isPending || updateMutation.isPending}
                  data-testid="button-submit-bandwidth"
                >
                  {createMutation.isPending || updateMutation.isPending
                    ? "Saving..."
                    : editingRecord
                    ? "Update Record"
                    : "Create Record"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}