import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Plus,
  Search,
  MoreHorizontal,
  Edit,
  Trash2,
  CreditCard,
  FileText,
  DollarSign,
  CheckCircle,
  Clock,
  XCircle,
  Download,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertCreditNoteSchema, type CreditNote, type InsertCreditNote, type Customer, type Invoice } from "@shared/schema";
import { z } from "zod";

const creditNoteFormSchema = insertCreditNoteSchema.extend({
  creditNoteNumber: z.string().min(1, "Credit note number is required"),
  customerId: z.coerce.number().min(1, "Customer is required"),
  amount: z.coerce.string(),
  reason: z.string().min(2, "Reason is required"),
  issueDate: z.string().min(1, "Issue date is required"),
});

export default function CreditNotesPage() {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingNote, setEditingNote] = useState<CreditNote | null>(null);

  const { data: creditNotes, isLoading } = useQuery<CreditNote[]>({
    queryKey: ["/api/credit-notes"],
  });

  const { data: customers } = useQuery<Customer[]>({
    queryKey: ["/api/customers"],
  });

  const { data: invoices } = useQuery<Invoice[]>({
    queryKey: ["/api/invoices"],
  });

  const form = useForm<InsertCreditNote>({
    resolver: zodResolver(creditNoteFormSchema),
    defaultValues: {
      creditNoteNumber: "",
      customerId: 0,
      invoiceId: undefined,
      amount: "",
      reason: "",
      status: "draft",
      issueDate: "",
      appliedDate: "",
      notes: "",
      createdBy: "",
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertCreditNote) => {
      const res = await apiRequest("POST", "/api/credit-notes", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/credit-notes"] });
      setDialogOpen(false);
      form.reset();
      toast({ title: "Credit note created successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertCreditNote> }) => {
      const res = await apiRequest("PATCH", `/api/credit-notes/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/credit-notes"] });
      setDialogOpen(false);
      setEditingNote(null);
      form.reset();
      toast({ title: "Credit note updated successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/credit-notes/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/credit-notes"] });
      toast({ title: "Credit note deleted" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const openCreate = () => {
    setEditingNote(null);
    form.reset({
      creditNoteNumber: "",
      customerId: 0,
      invoiceId: undefined,
      amount: "",
      reason: "",
      status: "draft",
      issueDate: "",
      appliedDate: "",
      notes: "",
      createdBy: "",
    });
    setDialogOpen(true);
  };

  const openEdit = (note: CreditNote) => {
    setEditingNote(note);
    form.reset({
      creditNoteNumber: note.creditNoteNumber,
      customerId: note.customerId,
      invoiceId: note.invoiceId ?? undefined,
      amount: note.amount,
      reason: note.reason,
      status: note.status,
      issueDate: note.issueDate,
      appliedDate: note.appliedDate || "",
      notes: note.notes || "",
      createdBy: note.createdBy || "",
    });
    setDialogOpen(true);
  };

  const onSubmit = (data: InsertCreditNote) => {
    if (editingNote) {
      updateMutation.mutate({ id: editingNote.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleExportCSV = () => {
    window.open("/api/export/credit-notes", "_blank");
  };

  const getCustomerName = (customerId: number) => {
    const customer = (customers || []).find((c) => c.id === customerId);
    return customer ? customer.fullName : `#${customerId}`;
  };

  const getInvoiceNumber = (invoiceId: number | null | undefined) => {
    if (!invoiceId) return "\u2014";
    const invoice = (invoices || []).find((inv) => inv.id === invoiceId);
    return invoice ? invoice.invoiceNumber : `#${invoiceId}`;
  };

  const filtered = (creditNotes || []).filter((cn) => {
    const matchSearch =
      cn.creditNoteNumber.toLowerCase().includes(search.toLowerCase()) ||
      cn.reason.toLowerCase().includes(search.toLowerCase()) ||
      getCustomerName(cn.customerId).toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === "all" || cn.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const statusConfig: Record<string, { icon: any; color: string }> = {
    draft: { icon: Clock, color: "text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950" },
    approved: { icon: CheckCircle, color: "text-green-700 dark:text-green-300 bg-green-50 dark:bg-green-950" },
    applied: { icon: FileText, color: "text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-950" },
    cancelled: { icon: XCircle, color: "text-gray-500 bg-gray-50 dark:bg-gray-900" },
  };

  const allNotes = creditNotes || [];
  const totalNotes = allNotes.length;
  const draftNotes = allNotes.filter((cn) => cn.status === "draft").length;
  const appliedNotes = allNotes.filter((cn) => cn.status === "applied").length;
  const totalValue = allNotes.reduce((sum, cn) => sum + parseFloat(cn.amount || "0"), 0);

  return (
    <div className="p-6 space-y-6 max-w-[1400px] mx-auto">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight" data-testid="text-credit-notes-title">Credit Notes</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Manage credit notes and adjustments</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Button variant="outline" onClick={handleExportCSV} data-testid="button-export-csv">
            <Download className="h-4 w-4 mr-1" />
            Export CSV
          </Button>
          <Button onClick={openCreate} data-testid="button-add-credit-note">
            <Plus className="h-4 w-4 mr-1" />
            Create Credit Note
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card data-testid="card-total-credit-notes">
          <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
            <p className="text-sm text-muted-foreground">Total Credit Notes</p>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold" data-testid="text-total-credit-notes">{totalNotes}</p>
          </CardContent>
        </Card>
        <Card data-testid="card-draft-notes">
          <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
            <p className="text-sm text-muted-foreground">Draft</p>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-blue-600 dark:text-blue-400" data-testid="text-draft-notes">{draftNotes}</p>
          </CardContent>
        </Card>
        <Card data-testid="card-applied-notes">
          <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
            <p className="text-sm text-muted-foreground">Applied</p>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-purple-600 dark:text-purple-400" data-testid="text-applied-notes">{appliedNotes}</p>
          </CardContent>
        </Card>
        <Card data-testid="card-total-value">
          <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
            <p className="text-sm text-muted-foreground">Total Value</p>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-green-600 dark:text-green-400" data-testid="text-total-value">
              {totalValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
            <div className="relative flex-1 w-full sm:max-w-xs">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search credit notes..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9"
                data-testid="input-search-credit-notes"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[160px]" data-testid="select-credit-note-status-filter">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="draft">Draft</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="applied">Applied</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-5 space-y-3">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-14 w-full" />
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
              <CreditCard className="h-12 w-12 mb-3 opacity-30" />
              <p className="font-medium">No credit notes found</p>
              <p className="text-sm mt-1">Create a new credit note to get started</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Credit Note #</TableHead>
                    <TableHead>Customer</TableHead>
                    <TableHead className="hidden md:table-cell">Invoice</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead className="hidden lg:table-cell">Reason</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="hidden lg:table-cell">Issue Date</TableHead>
                    <TableHead className="hidden lg:table-cell">Applied Date</TableHead>
                    <TableHead className="w-10"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((cn) => {
                    const config = statusConfig[cn.status] || statusConfig.draft;
                    const StatusIcon = config.icon;
                    return (
                      <TableRow key={cn.id} data-testid={`row-credit-note-${cn.id}`}>
                        <TableCell>
                          <div className="font-medium" data-testid={`text-credit-note-number-${cn.id}`}>{cn.creditNoteNumber}</div>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground" data-testid={`text-credit-note-customer-${cn.id}`}>
                          {getCustomerName(cn.customerId)}
                        </TableCell>
                        <TableCell className="hidden md:table-cell text-sm text-muted-foreground" data-testid={`text-credit-note-invoice-${cn.id}`}>
                          {getInvoiceNumber(cn.invoiceId)}
                        </TableCell>
                        <TableCell>
                          <span className="font-medium" data-testid={`text-credit-note-amount-${cn.id}`}>
                            {parseFloat(cn.amount || "0").toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                          </span>
                        </TableCell>
                        <TableCell className="hidden lg:table-cell text-sm text-muted-foreground max-w-[200px] truncate" data-testid={`text-credit-note-reason-${cn.id}`}>
                          {cn.reason}
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary" className={`no-default-active-elevate text-[10px] capitalize ${config.color}`} data-testid={`badge-credit-note-status-${cn.id}`}>
                            <StatusIcon className="h-3 w-3 mr-1" />
                            {cn.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="hidden lg:table-cell text-sm text-muted-foreground" data-testid={`text-credit-note-issue-date-${cn.id}`}>
                          {cn.issueDate || "\u2014"}
                        </TableCell>
                        <TableCell className="hidden lg:table-cell text-sm text-muted-foreground" data-testid={`text-credit-note-applied-date-${cn.id}`}>
                          {cn.appliedDate || "\u2014"}
                        </TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" data-testid={`button-credit-note-actions-${cn.id}`}>
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => openEdit(cn)} data-testid={`button-edit-credit-note-${cn.id}`}>
                                <Edit className="h-4 w-4 mr-2" />
                                Edit
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                className="text-destructive"
                                onClick={() => deleteMutation.mutate(cn.id)}
                                data-testid={`button-delete-credit-note-${cn.id}`}
                              >
                                <Trash2 className="h-4 w-4 mr-2" />
                                Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingNote ? "Edit Credit Note" : "Create Credit Note"}</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="creditNoteNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Credit Note Number</FormLabel>
                    <FormControl>
                      <Input placeholder="CN-001" data-testid="input-credit-note-number" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="customerId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Customer</FormLabel>
                      <Select
                        onValueChange={(v) => field.onChange(parseInt(v))}
                        value={field.value ? field.value.toString() : ""}
                      >
                        <FormControl>
                          <SelectTrigger data-testid="select-credit-note-customer">
                            <SelectValue placeholder="Select customer" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {(customers || []).map((c) => (
                            <SelectItem key={c.id} value={c.id.toString()}>
                              {c.fullName}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="invoiceId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Invoice (Optional)</FormLabel>
                      <Select
                        onValueChange={(v) => field.onChange(v === "none" ? undefined : parseInt(v))}
                        value={field.value?.toString() || "none"}
                      >
                        <FormControl>
                          <SelectTrigger data-testid="select-credit-note-invoice">
                            <SelectValue placeholder="Select invoice" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="none">No invoice</SelectItem>
                          {(invoices || []).map((inv) => (
                            <SelectItem key={inv.id} value={inv.id.toString()}>
                              {inv.invoiceNumber}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="amount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Amount</FormLabel>
                      <FormControl>
                        <Input type="number" step="0.01" placeholder="0.00" data-testid="input-credit-note-amount" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Status</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value || "draft"}>
                        <FormControl>
                          <SelectTrigger data-testid="select-credit-note-status">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="draft">Draft</SelectItem>
                          <SelectItem value="approved">Approved</SelectItem>
                          <SelectItem value="applied">Applied</SelectItem>
                          <SelectItem value="cancelled">Cancelled</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={form.control}
                name="reason"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Reason</FormLabel>
                    <FormControl>
                      <Input placeholder="Reason for credit note" data-testid="input-credit-note-reason" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="issueDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Issue Date</FormLabel>
                      <FormControl>
                        <Input type="date" data-testid="input-credit-note-issue-date" {...field} value={field.value || ""} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="appliedDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Applied Date</FormLabel>
                      <FormControl>
                        <Input type="date" data-testid="input-credit-note-applied-date" {...field} value={field.value || ""} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={form.control}
                name="createdBy"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Created By</FormLabel>
                    <FormControl>
                      <Input placeholder="Staff name" data-testid="input-credit-note-created-by" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Additional notes..." data-testid="input-credit-note-notes" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="button" variant="secondary" onClick={() => setDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending} data-testid="button-save-credit-note">
                  {createMutation.isPending || updateMutation.isPending ? "Saving..." : editingNote ? "Update" : "Create"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
