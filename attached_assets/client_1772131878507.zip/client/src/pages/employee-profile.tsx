import { useState } from "react";
import { useParams, Link, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  ArrowLeft,
  User,
  Mail,
  Phone,
  Download,
  Edit,
  Save,
  FileText,
  IdCard,
  Calendar,
  Activity,
  Wallet,
  Building2,
  UserCheck,
  Briefcase,
  Heart,
  Globe,
  AlertCircle,
  Clock,
  CreditCard,
  StickyNote,
  ChevronRight,
  Printer,
  X,
  Check,
  MoreHorizontal,
  BadgeCheck,
  BanknoteIcon,
  History,
  Key,
  Eye,
  EyeOff,
  Plus,
  Trash2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertEmployeeSchema, insertSalaryHistorySchema, type Employee, type InsertEmployee, type SalaryHistory, type InsertSalaryHistory } from "@shared/schema";

const statusColors: Record<string, string> = {
  active: "text-green-700 dark:text-green-300 bg-green-100 dark:bg-green-950 border-green-300 dark:border-green-700",
  on_leave: "text-amber-600 dark:text-amber-400 bg-amber-100 dark:bg-amber-950 border-amber-300 dark:border-amber-700",
  terminated: "text-red-600 dark:text-red-400 bg-red-100 dark:bg-red-950 border-red-300 dark:border-red-700",
};

const departmentLabels: Record<string, string> = {
  engineering: "Engineering", support: "Support", sales: "Sales",
  finance: "Finance", admin: "Admin", management: "Management",
  hr: "HR", it: "IT", operations: "Operations",
};

const tabs = ["Employee Information", "Personal Information", "Salary History", "App Login Detail"] as const;
type Tab = typeof tabs[number];

function InfoRow({ label, value, colSpan }: { label: string; value?: string | null; colSpan?: boolean }) {
  return (
    <div className={`flex gap-2 py-2.5 px-4 items-start ${colSpan ? "col-span-2" : ""} border-b border-border last:border-0`}>
      <span className="text-sm text-muted-foreground font-medium min-w-[140px] flex-shrink-0">{label}</span>
      <span className="text-muted-foreground mx-1">:</span>
      <span className="text-sm font-medium flex-1">{value || <span className="text-muted-foreground italic text-xs">N/A</span>}</span>
    </div>
  );
}

export default function EmployeeProfilePage() {
  const params = useParams<{ id: string }>();
  const id = Number(params.id);
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<Tab>("Employee Information");
  const [editOpen, setEditOpen] = useState(false);
  const [salaryDialogOpen, setSalaryDialogOpen] = useState(false);
  const [editingSalary, setEditingSalary] = useState<SalaryHistory | null>(null);
  const [salaryMonthFilter, setSalaryMonthFilter] = useState("");
  const [salaryFromDate, setSalaryFromDate] = useState("");
  const [salaryToDate, setSalaryToDate] = useState("");
  const [salarySearch, setSalarySearch] = useState("");
  const [salaryPageSize, setSalaryPageSize] = useState(10);
  const [salaryPage, setSalaryPage] = useState(1);

  const { data: employee, isLoading } = useQuery<Employee>({
    queryKey: ["/api/employees", id],
    queryFn: async () => {
      const res = await fetch(`/api/employees/${id}`, { credentials: "include" });
      if (!res.ok) throw new Error("Employee not found");
      return res.json();
    },
    enabled: !!id,
  });

  const updateMutation = useMutation({
    mutationFn: async (data: Partial<InsertEmployee>) => {
      const res = await apiRequest("PATCH", `/api/employees/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/employees", id] });
      queryClient.invalidateQueries({ queryKey: ["/api/employees"] });
      setEditOpen(false);
      toast({ title: "Employee updated successfully" });
    },
    onError: (e: Error) => {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    },
  });

  const { data: salaryHistoryData, isLoading: salaryLoading } = useQuery<SalaryHistory[]>({
    queryKey: ["/api/employees", id, "salary-history"],
    queryFn: async () => {
      const res = await fetch(`/api/employees/${id}/salary-history`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch salary history");
      return res.json();
    },
    enabled: !!id,
  });

  const createSalaryMutation = useMutation({
    mutationFn: async (data: InsertSalaryHistory) => {
      const res = await apiRequest("POST", "/api/salary-history", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/employees", id, "salary-history"] });
      setSalaryDialogOpen(false);
      setEditingSalary(null);
      salaryForm.reset();
      toast({ title: "Salary entry added successfully" });
    },
    onError: (e: Error) => {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    },
  });

  const updateSalaryMutation = useMutation({
    mutationFn: async ({ sid, data }: { sid: number; data: Partial<InsertSalaryHistory> }) => {
      const res = await apiRequest("PATCH", `/api/salary-history/${sid}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/employees", id, "salary-history"] });
      setSalaryDialogOpen(false);
      setEditingSalary(null);
      salaryForm.reset();
      toast({ title: "Salary entry updated" });
    },
    onError: (e: Error) => {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    },
  });

  const deleteSalaryMutation = useMutation({
    mutationFn: async (sid: number) => {
      await apiRequest("DELETE", `/api/salary-history/${sid}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/employees", id, "salary-history"] });
      toast({ title: "Salary entry deleted" });
    },
    onError: (e: Error) => {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    },
  });

  const salaryForm = useForm<InsertSalaryHistory>({
    defaultValues: {
      employeeId: id,
      salaryDate: new Date().toISOString().split("T")[0],
      salaryMonth: "",
      paidAmount: "0",
      overtime: "0",
      incentive: "0",
      bonus: "0",
      overall: "0",
      remarks: "",
      givenBy: "",
    },
  });

  const openAddSalary = () => {
    setEditingSalary(null);
    salaryForm.reset({
      employeeId: id,
      salaryDate: new Date().toISOString().split("T")[0],
      salaryMonth: "",
      paidAmount: employee?.salary || "0",
      overtime: "0",
      incentive: "0",
      bonus: "0",
      overall: "0",
      remarks: "",
      givenBy: "",
    });
    setSalaryDialogOpen(true);
  };

  const openEditSalary = (entry: SalaryHistory) => {
    setEditingSalary(entry);
    salaryForm.reset({
      employeeId: entry.employeeId,
      salaryDate: entry.salaryDate,
      salaryMonth: entry.salaryMonth,
      paidAmount: entry.paidAmount || "0",
      overtime: entry.overtime || "0",
      incentive: entry.incentive || "0",
      bonus: entry.bonus || "0",
      overall: entry.overall || "0",
      remarks: entry.remarks || "",
      givenBy: entry.givenBy || "",
    });
    setSalaryDialogOpen(true);
  };

  const onSalarySubmit = (data: InsertSalaryHistory) => {
    if (editingSalary) {
      updateSalaryMutation.mutate({ sid: editingSalary.id, data });
    } else {
      createSalaryMutation.mutate({ ...data, employeeId: id });
    }
  };

  const editForm = useForm<InsertEmployee>({
    defaultValues: {},
  });

  const openEdit = () => {
    if (!employee) return;
    editForm.reset({
      empCode: employee.empCode,
      fullName: employee.fullName,
      email: employee.email || "",
      phone: employee.phone,
      cnic: employee.cnic || "",
      department: employee.department,
      designation: employee.designation,
      joinDate: employee.joinDate || "",
      salary: employee.salary || "",
      bankAccount: employee.bankAccount || "",
      address: employee.address || "",
      status: employee.status,
      gender: (employee as any).gender || "",
      dateOfBirth: (employee as any).dateOfBirth || "",
      maritalStatus: (employee as any).maritalStatus || "",
      fatherName: (employee as any).fatherName || "",
      guardianPhone: (employee as any).guardianPhone || "",
      bloodGroup: (employee as any).bloodGroup || "",
      religion: (employee as any).religion || "",
      nationality: (employee as any).nationality || "",
      emergencyContact: (employee as any).emergencyContact || "",
      emergencyPhone: (employee as any).emergencyPhone || "",
      city: (employee as any).city || "",
      country: (employee as any).country || "",
      bankName: (employee as any).bankName || "",
      bankBranch: (employee as any).bankBranch || "",
      salaryType: (employee as any).salaryType || "monthly",
      employmentType: (employee as any).employmentType || "full_time",
      shift: (employee as any).shift || "morning",
      workLocation: (employee as any).workLocation || "",
      reportingTo: (employee as any).reportingTo || "",
      probationEndDate: (employee as any).probationEndDate || "",
      confirmationDate: (employee as any).confirmationDate || "",
    });
    setEditOpen(true);
  };

  const onEditSubmit = (data: InsertEmployee) => {
    updateMutation.mutate(data);
  };

  const handleDownload = () => {
    if (!employee) return;
    const content = `EMPLOYEE PROFILE\n================\nName: ${employee.fullName}\nID: ${employee.empCode}\nDepartment: ${departmentLabels[employee.department] || employee.department}\nDesignation: ${employee.designation}\nPhone: ${employee.phone}\nEmail: ${employee.email || "N/A"}\nCNIC: ${employee.cnic || "N/A"}\nStatus: ${employee.status}\nJoin Date: ${employee.joinDate || "N/A"}\nSalary: Rs. ${employee.salary ? Number(employee.salary).toLocaleString() : "N/A"}\nAddress: ${employee.address || "N/A"}`;
    const blob = new Blob([content], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${employee.empCode}-profile.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (isLoading) {
    return (
      <div className="p-6 space-y-4">
        <Skeleton className="h-8 w-48" />
        <div className="flex gap-5">
          <Skeleton className="h-80 w-64 flex-shrink-0" />
          <Skeleton className="h-80 flex-1" />
        </div>
      </div>
    );
  }

  if (!employee) {
    return (
      <div className="p-6 flex flex-col items-center justify-center min-h-[300px] text-muted-foreground">
        <AlertCircle className="h-12 w-12 mb-3 opacity-30" />
        <p className="font-medium">Employee not found</p>
        <Link href="/hr">
          <Button variant="outline" size="sm" className="mt-4 gap-1.5">
            <ArrowLeft className="h-3.5 w-3.5" /> Back to HR
          </Button>
        </Link>
      </div>
    );
  }

  const emp = employee as any;

  return (
    <div className="p-4 md:p-6 space-y-4 min-h-full bg-muted/30" data-testid="employee-profile-page">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <User className="h-3.5 w-3.5 text-primary" />
          <span className="font-semibold text-foreground">Profile</span>
          <ChevronRight className="h-3 w-3" />
          <Link href="/hr"><span className="hover:text-primary cursor-pointer">HR &amp; Payroll</span></Link>
          <ChevronRight className="h-3 w-3" />
          <Link href="/hr"><span className="hover:text-primary cursor-pointer">Employee List</span></Link>
          <ChevronRight className="h-3 w-3" />
          <span className="text-foreground font-medium">Employee Profile</span>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" className="gap-1.5 h-8 text-xs" onClick={handleDownload} data-testid="button-download-profile">
            <Download className="h-3.5 w-3.5" /> Download
          </Button>
          <Button variant="outline" size="sm" className="gap-1.5 h-8 text-xs" onClick={() => window.print()} data-testid="button-print-profile">
            <Printer className="h-3.5 w-3.5" /> Print
          </Button>
          <Button size="sm" className="gap-1.5 h-8 text-xs" onClick={openEdit} data-testid="button-edit-profile">
            <Edit className="h-3.5 w-3.5" /> Edit Employee
          </Button>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-5 items-start">
        <div className="w-full lg:w-64 flex-shrink-0 bg-white dark:bg-card rounded-xl border border-border shadow-sm overflow-hidden" data-testid="profile-sidebar">
          <div className="bg-gradient-to-b from-[#1e293b] to-[#334155] p-5 flex flex-col items-center gap-3">
            {emp.profilePicture ? (
              <img src={emp.profilePicture} alt={employee.fullName} className="w-24 h-24 rounded-full object-cover border-4 border-white/30 shadow-lg" data-testid="profile-photo" />
            ) : (
              <div className="w-24 h-24 rounded-full bg-white/10 border-4 border-white/20 flex items-center justify-center shadow-lg" data-testid="profile-avatar">
                <User className="h-12 w-12 text-white/70" />
              </div>
            )}
            <div className="text-center">
              <h3 className="font-bold text-white text-sm leading-tight">{employee.fullName}</h3>
              <p className="text-white/70 text-[11px] mt-0.5">{employee.designation}</p>
            </div>
          </div>

          <div className="p-4 border-b border-border">
            <div className="grid grid-cols-2 gap-2">
              <button
                className="flex flex-col items-center gap-1 p-2.5 rounded-lg border border-border hover:bg-muted/50 transition-colors text-center"
                onClick={() => toast({ title: "CNIC", description: employee.cnic || "No CNIC on file" })}
                data-testid="button-cnic"
              >
                <IdCard className="h-5 w-5 text-primary" />
                <span className="text-[10px] font-medium text-muted-foreground">CNIC</span>
              </button>
              <button
                className="flex flex-col items-center gap-1 p-2.5 rounded-lg border border-border hover:bg-muted/50 transition-colors text-center"
                onClick={() => toast({ title: "Joining Certificate", description: "No joining certificate on file" })}
                data-testid="button-joining-cert"
              >
                <FileText className="h-5 w-5 text-primary" />
                <span className="text-[10px] font-medium text-muted-foreground leading-tight">Joining Cert.</span>
              </button>
            </div>
          </div>

          <div className="p-4 space-y-3">
            {[
              { icon: User, label: "Employee Name", value: employee.fullName },
              { icon: IdCard, label: "Employee Id", value: employee.empCode },
              { icon: Calendar, label: "Date Of Birth", value: emp.dateOfBirth },
              { icon: Briefcase, label: "Department", value: departmentLabels[employee.department] || employee.department },
              { icon: Clock, label: "Join Date", value: employee.joinDate },
              { icon: Activity, label: "Status", value: null, badge: employee.status },
            ].map(({ icon: Icon, label, value, badge }) => (
              <div key={label} className="flex items-start gap-2.5" data-testid={`sidebar-${label.toLowerCase().replace(/ /g,"-")}`}>
                <Icon className="h-3.5 w-3.5 text-muted-foreground mt-0.5 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-[10px] uppercase tracking-wide text-muted-foreground font-semibold">{label}</p>
                  {badge ? (
                    <Badge variant="secondary" className={`text-[10px] capitalize mt-0.5 border ${statusColors[badge] || ""}`}>
                      {badge.replace("_", " ")}
                    </Badge>
                  ) : (
                    <p className="text-sm font-medium truncate">{value || <span className="text-muted-foreground text-xs italic">N/A</span>}</p>
                  )}
                </div>
              </div>
            ))}
          </div>

          <div className="p-4 pt-0 space-y-2">
            <Button className="w-full gap-1.5 text-xs h-9" onClick={handleDownload} data-testid="button-sidebar-download">
              <Download className="h-3.5 w-3.5" /> Download Information
            </Button>
            <Link href="/hr">
              <Button variant="outline" className="w-full gap-1.5 text-xs h-9" data-testid="button-goto-list">
                <ArrowLeft className="h-3.5 w-3.5" /> Go To Employee List
              </Button>
            </Link>
          </div>
        </div>

        <div className="flex-1 min-w-0 bg-white dark:bg-card rounded-xl border border-border shadow-sm overflow-hidden" data-testid="profile-main">
          <div className="flex items-center border-b border-border overflow-x-auto">
            {tabs.map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`px-5 py-3.5 text-sm font-medium whitespace-nowrap transition-colors border-b-2 ${
                  activeTab === tab
                    ? "border-primary text-primary bg-primary/5"
                    : "border-transparent text-muted-foreground hover:text-foreground hover:bg-muted/30"
                }`}
                data-testid={`tab-${tab.toLowerCase().replace(/ /g, "-")}`}
              >
                {tab}
              </button>
            ))}
          </div>

          {activeTab === "Employee Information" && (
            <div data-testid="tab-content-employee-info">
              <div className="bg-[#1e293b] dark:bg-slate-800 px-5 py-3">
                <h3 className="text-white font-semibold text-sm tracking-wide">Employee Information</h3>
              </div>
              <div className="divide-y divide-border">
                <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-border">
                  <div className="flex items-center px-5 py-3 gap-3">
                    <span className="text-sm text-muted-foreground font-medium min-w-[110px]">Department</span>
                    <span className="text-muted-foreground">:</span>
                    <span className="text-sm font-semibold">{departmentLabels[employee.department] || employee.department}</span>
                  </div>
                  <div className="flex items-center px-5 py-3 gap-3">
                    <span className="text-sm text-muted-foreground font-medium min-w-[110px]">Designation</span>
                    <span className="text-muted-foreground">:</span>
                    <span className="text-sm font-semibold">{employee.designation || <span className="text-muted-foreground italic text-xs">N/A</span>}</span>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-border bg-muted/20">
                  <div className="flex items-center px-5 py-3 gap-3">
                    <span className="text-sm text-muted-foreground font-medium min-w-[110px]">Salary</span>
                    <span className="text-muted-foreground">:</span>
                    <div className="flex items-center gap-3 flex-1">
                      <span className="text-sm font-semibold text-green-600 dark:text-green-400">
                        Rs. {employee.salary ? Number(employee.salary).toLocaleString() : "0.00"}
                      </span>
                      <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded">Balance</span>
                      <span className="text-sm font-medium text-muted-foreground">
                        Rs. {employee.salary ? Number(employee.salary).toLocaleString() : "0.00"}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center px-5 py-3 gap-3">
                    <span className="text-sm text-muted-foreground font-medium min-w-[110px]">Mobile Number</span>
                    <span className="text-muted-foreground">:</span>
                    <span className="text-sm font-semibold">{employee.phone}</span>
                  </div>
                </div>
                <div className="flex items-center px-5 py-3 gap-3">
                  <span className="text-sm text-muted-foreground font-medium min-w-[110px]">Email</span>
                  <span className="text-muted-foreground">:</span>
                  <span className="text-sm font-semibold">{employee.email || <span className="text-muted-foreground italic text-xs">N/A</span>}</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-border bg-muted/20">
                  <div className="flex items-center px-5 py-3 gap-3">
                    <span className="text-sm text-muted-foreground font-medium min-w-[110px]">Employment Type</span>
                    <span className="text-muted-foreground">:</span>
                    <span className="text-sm font-semibold capitalize">{(emp.employmentType || "full_time").replace("_", " ")}</span>
                  </div>
                  <div className="flex items-center px-5 py-3 gap-3">
                    <span className="text-sm text-muted-foreground font-medium min-w-[110px]">Salary Type</span>
                    <span className="text-muted-foreground">:</span>
                    <span className="text-sm font-semibold capitalize">{emp.salaryType || "Monthly"}</span>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-border">
                  <div className="flex items-center px-5 py-3 gap-3">
                    <span className="text-sm text-muted-foreground font-medium min-w-[110px]">Shift</span>
                    <span className="text-muted-foreground">:</span>
                    <span className="text-sm font-semibold capitalize">{emp.shift || <span className="text-muted-foreground italic text-xs">N/A</span>}</span>
                  </div>
                  <div className="flex items-center px-5 py-3 gap-3">
                    <span className="text-sm text-muted-foreground font-medium min-w-[110px]">Work Location</span>
                    <span className="text-muted-foreground">:</span>
                    <span className="text-sm font-semibold">{emp.workLocation || <span className="text-muted-foreground italic text-xs">N/A</span>}</span>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-border bg-muted/20">
                  <div className="flex items-center px-5 py-3 gap-3">
                    <span className="text-sm text-muted-foreground font-medium min-w-[110px]">Reporting To</span>
                    <span className="text-muted-foreground">:</span>
                    <span className="text-sm font-semibold">{emp.reportingTo || <span className="text-muted-foreground italic text-xs">N/A</span>}</span>
                  </div>
                  <div className="flex items-center px-5 py-3 gap-3">
                    <span className="text-sm text-muted-foreground font-medium min-w-[110px]">Status</span>
                    <span className="text-muted-foreground">:</span>
                    <Badge variant="secondary" className={`text-[10px] capitalize border ${statusColors[employee.status] || ""}`}>
                      {employee.status.replace("_", " ")}
                    </Badge>
                  </div>
                </div>
                <div className="flex items-start px-5 py-3 gap-3">
                  <span className="text-sm text-muted-foreground font-medium min-w-[110px] pt-0.5">Note / Remark</span>
                  <span className="text-muted-foreground">:</span>
                  <span className="text-sm text-muted-foreground italic">{employee.address || "N/A"}</span>
                </div>
              </div>
            </div>
          )}

          {activeTab === "Personal Information" && (
            <div data-testid="tab-content-personal-info">
              <div className="bg-[#1e293b] dark:bg-slate-800 px-5 py-3">
                <h3 className="text-white font-semibold text-sm tracking-wide">Personal Information</h3>
              </div>
              <div className="divide-y divide-border">
                <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-border">
                  <div className="flex items-center px-5 py-3 gap-3">
                    <span className="text-sm text-muted-foreground font-medium min-w-[110px]">Full Name</span>
                    <span className="text-muted-foreground">:</span>
                    <span className="text-sm font-semibold">{employee.fullName}</span>
                  </div>
                  <div className="flex items-center px-5 py-3 gap-3">
                    <span className="text-sm text-muted-foreground font-medium min-w-[110px]">Gender</span>
                    <span className="text-muted-foreground">:</span>
                    <span className="text-sm font-semibold capitalize">{emp.gender || <span className="text-muted-foreground italic text-xs">N/A</span>}</span>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-border bg-muted/20">
                  <div className="flex items-center px-5 py-3 gap-3">
                    <span className="text-sm text-muted-foreground font-medium min-w-[110px]">Date of Birth</span>
                    <span className="text-muted-foreground">:</span>
                    <span className="text-sm font-semibold">{emp.dateOfBirth || <span className="text-muted-foreground italic text-xs">N/A</span>}</span>
                  </div>
                  <div className="flex items-center px-5 py-3 gap-3">
                    <span className="text-sm text-muted-foreground font-medium min-w-[110px]">Marital Status</span>
                    <span className="text-muted-foreground">:</span>
                    <span className="text-sm font-semibold capitalize">{emp.maritalStatus || <span className="text-muted-foreground italic text-xs">N/A</span>}</span>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-border">
                  <div className="flex items-center px-5 py-3 gap-3">
                    <span className="text-sm text-muted-foreground font-medium min-w-[110px]">Father's Name</span>
                    <span className="text-muted-foreground">:</span>
                    <span className="text-sm font-semibold">{emp.fatherName || <span className="text-muted-foreground italic text-xs">N/A</span>}</span>
                  </div>
                  <div className="flex items-center px-5 py-3 gap-3">
                    <span className="text-sm text-muted-foreground font-medium min-w-[110px]">CNIC / NIC</span>
                    <span className="text-muted-foreground">:</span>
                    <span className="text-sm font-semibold font-mono">{employee.cnic || <span className="text-muted-foreground italic text-xs">N/A</span>}</span>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-border bg-muted/20">
                  <div className="flex items-center px-5 py-3 gap-3">
                    <span className="text-sm text-muted-foreground font-medium min-w-[110px]">Blood Group</span>
                    <span className="text-muted-foreground">:</span>
                    {emp.bloodGroup ? (
                      <Badge className="bg-red-100 dark:bg-red-950 text-red-700 dark:text-red-300 border border-red-300 text-xs">{emp.bloodGroup}</Badge>
                    ) : <span className="text-muted-foreground italic text-xs">N/A</span>}
                  </div>
                  <div className="flex items-center px-5 py-3 gap-3">
                    <span className="text-sm text-muted-foreground font-medium min-w-[110px]">Religion</span>
                    <span className="text-muted-foreground">:</span>
                    <span className="text-sm font-semibold capitalize">{emp.religion || <span className="text-muted-foreground italic text-xs">N/A</span>}</span>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-border">
                  <div className="flex items-center px-5 py-3 gap-3">
                    <span className="text-sm text-muted-foreground font-medium min-w-[110px]">Nationality</span>
                    <span className="text-muted-foreground">:</span>
                    <span className="text-sm font-semibold">{emp.nationality || <span className="text-muted-foreground italic text-xs">N/A</span>}</span>
                  </div>
                  <div className="flex items-center px-5 py-3 gap-3">
                    <span className="text-sm text-muted-foreground font-medium min-w-[110px]">Guardian Phone</span>
                    <span className="text-muted-foreground">:</span>
                    <span className="text-sm font-semibold">{emp.guardianPhone || <span className="text-muted-foreground italic text-xs">N/A</span>}</span>
                  </div>
                </div>
                <div className="bg-[#1e293b] dark:bg-slate-700 px-5 py-2">
                  <h4 className="text-white/80 font-semibold text-xs tracking-wide uppercase">Emergency Contact</h4>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-border">
                  <div className="flex items-center px-5 py-3 gap-3">
                    <span className="text-sm text-muted-foreground font-medium min-w-[110px]">Contact Name</span>
                    <span className="text-muted-foreground">:</span>
                    <span className="text-sm font-semibold">{emp.emergencyContact || <span className="text-muted-foreground italic text-xs">N/A</span>}</span>
                  </div>
                  <div className="flex items-center px-5 py-3 gap-3">
                    <span className="text-sm text-muted-foreground font-medium min-w-[110px]">Contact Phone</span>
                    <span className="text-muted-foreground">:</span>
                    <span className="text-sm font-semibold">{emp.emergencyPhone || <span className="text-muted-foreground italic text-xs">N/A</span>}</span>
                  </div>
                </div>
                <div className="bg-[#1e293b] dark:bg-slate-700 px-5 py-2">
                  <h4 className="text-white/80 font-semibold text-xs tracking-wide uppercase">Address & Location</h4>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-border">
                  <div className="flex items-center px-5 py-3 gap-3">
                    <span className="text-sm text-muted-foreground font-medium min-w-[110px]">City</span>
                    <span className="text-muted-foreground">:</span>
                    <span className="text-sm font-semibold">{emp.city || <span className="text-muted-foreground italic text-xs">N/A</span>}</span>
                  </div>
                  <div className="flex items-center px-5 py-3 gap-3">
                    <span className="text-sm text-muted-foreground font-medium min-w-[110px]">Country</span>
                    <span className="text-muted-foreground">:</span>
                    <span className="text-sm font-semibold">{emp.country || <span className="text-muted-foreground italic text-xs">N/A</span>}</span>
                  </div>
                </div>
                <div className="flex items-start px-5 py-3 gap-3 bg-muted/20">
                  <span className="text-sm text-muted-foreground font-medium min-w-[110px] pt-0.5">Full Address</span>
                  <span className="text-muted-foreground">:</span>
                  <span className="text-sm">{employee.address || <span className="text-muted-foreground italic text-xs">N/A</span>}</span>
                </div>
                {(emp.qualifications) && (
                  <>
                    <div className="bg-[#1e293b] dark:bg-slate-700 px-5 py-2">
                      <h4 className="text-white/80 font-semibold text-xs tracking-wide uppercase">Qualifications</h4>
                    </div>
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow className="bg-muted/30">
                            <TableHead className="text-xs">Degree</TableHead>
                            <TableHead className="text-xs">Institution</TableHead>
                            <TableHead className="text-xs">Year</TableHead>
                            <TableHead className="text-xs">Grade</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {(() => { try { return JSON.parse(emp.qualifications); } catch { return []; } })().map((q: any, i: number) => (
                            <TableRow key={i} className="text-sm">
                              <TableCell>{q.degree || "—"}</TableCell>
                              <TableCell>{q.institution || "—"}</TableCell>
                              <TableCell>{q.year || "—"}</TableCell>
                              <TableCell>{q.grade || "—"}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </>
                )}
                {(emp.experiences) && (
                  <>
                    <div className="bg-[#1e293b] dark:bg-slate-700 px-5 py-2">
                      <h4 className="text-white/80 font-semibold text-xs tracking-wide uppercase">Experience</h4>
                    </div>
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow className="bg-muted/30">
                            <TableHead className="text-xs">Company</TableHead>
                            <TableHead className="text-xs">Position</TableHead>
                            <TableHead className="text-xs">From</TableHead>
                            <TableHead className="text-xs">To</TableHead>
                            <TableHead className="text-xs">Reason</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {(() => { try { return JSON.parse(emp.experiences); } catch { return []; } })().map((x: any, i: number) => (
                            <TableRow key={i} className="text-sm">
                              <TableCell>{x.company || "—"}</TableCell>
                              <TableCell>{x.position || "—"}</TableCell>
                              <TableCell>{x.from || "—"}</TableCell>
                              <TableCell>{x.to || "—"}</TableCell>
                              <TableCell>{x.reason || "—"}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  </>
                )}
              </div>
            </div>
          )}

          {activeTab === "Salary History" && (() => {
            const allEntries = salaryHistoryData || [];
            const months = [...new Set(allEntries.map(e => e.salaryMonth))].sort().reverse();
            const filtered = allEntries.filter(e => {
              const matchMonth = !salaryMonthFilter || e.salaryMonth === salaryMonthFilter;
              const matchFrom = !salaryFromDate || e.salaryDate >= salaryFromDate;
              const matchTo = !salaryToDate || e.salaryDate <= salaryToDate;
              const matchSearch = !salarySearch || e.salaryMonth.toLowerCase().includes(salarySearch.toLowerCase()) || (e.remarks || "").toLowerCase().includes(salarySearch.toLowerCase()) || (e.givenBy || "").toLowerCase().includes(salarySearch.toLowerCase());
              return matchMonth && matchFrom && matchTo && matchSearch;
            });
            const totalPages = Math.max(1, Math.ceil(filtered.length / salaryPageSize));
            const paginated = filtered.slice((salaryPage - 1) * salaryPageSize, salaryPage * salaryPageSize);
            const totals = {
              paid: filtered.reduce((s, e) => s + Number(e.paidAmount || 0), 0),
              overtime: filtered.reduce((s, e) => s + Number(e.overtime || 0), 0),
              incentive: filtered.reduce((s, e) => s + Number(e.incentive || 0), 0),
              bonus: filtered.reduce((s, e) => s + Number(e.bonus || 0), 0),
              overall: filtered.reduce((s, e) => s + Number(e.overall || 0), 0),
            };
            return (
              <div data-testid="tab-content-salary-history">
                <div className="bg-[#1e293b] dark:bg-slate-800 px-5 py-3 flex items-center justify-between">
                  <h3 className="text-white font-semibold text-sm tracking-wide">Salary History</h3>
                  <Button size="sm" className="h-7 text-xs gap-1.5 bg-white/10 hover:bg-white/20 text-white border-white/20 border" onClick={openAddSalary} data-testid="button-add-salary">
                    <Plus className="h-3.5 w-3.5" /> Add Salary
                  </Button>
                </div>

                <div className="p-4 border-b border-border space-y-3">
                  <div className="flex flex-wrap gap-4">
                    <div className="min-w-[160px]">
                      <p className="text-[10px] uppercase tracking-wide font-semibold text-muted-foreground mb-1">Salary Month</p>
                      <Select value={salaryMonthFilter} onValueChange={v => { setSalaryMonthFilter(v === "all" ? "" : v); setSalaryPage(1); }}>
                        <SelectTrigger className="h-8 text-xs w-[180px]" data-testid="select-salary-month">
                          <SelectValue placeholder="Select" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Months</SelectItem>
                          {months.map(m => <SelectItem key={m} value={m}>{m}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <p className="text-[10px] uppercase tracking-wide font-semibold text-muted-foreground mb-1">From Date</p>
                      <Input type="date" className="h-8 text-xs w-[150px]" value={salaryFromDate} onChange={e => { setSalaryFromDate(e.target.value); setSalaryPage(1); }} data-testid="input-from-date" />
                    </div>
                    <div>
                      <p className="text-[10px] uppercase tracking-wide font-semibold text-muted-foreground mb-1">To Date</p>
                      <Input type="date" className="h-8 text-xs w-[150px]" value={salaryToDate} onChange={e => { setSalaryToDate(e.target.value); setSalaryPage(1); }} data-testid="input-to-date" />
                    </div>
                    <div className="flex-1" />
                    <div className="flex items-end gap-3">
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs text-muted-foreground font-medium">SHOW</span>
                        <Select value={String(salaryPageSize)} onValueChange={v => { setSalaryPageSize(Number(v)); setSalaryPage(1); }}>
                          <SelectTrigger className="h-8 text-xs w-16" data-testid="select-salary-page-size"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="10">10</SelectItem>
                            <SelectItem value="25">25</SelectItem>
                            <SelectItem value="50">50</SelectItem>
                          </SelectContent>
                        </Select>
                        <span className="text-xs text-muted-foreground font-medium">ENTRIES</span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="text-xs text-muted-foreground font-medium">SEARCH:</span>
                        <Input className="h-8 text-xs w-[160px]" placeholder="Search..." value={salarySearch} onChange={e => { setSalarySearch(e.target.value); setSalaryPage(1); }} data-testid="input-salary-search" />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-[#1e293b] hover:bg-[#1e293b] dark:bg-slate-800">
                        <TableHead className="text-white font-semibold text-xs py-3 w-10">S/N</TableHead>
                        <TableHead className="text-white font-semibold text-xs py-3">Salary Date</TableHead>
                        <TableHead className="text-white font-semibold text-xs py-3">Salary Month</TableHead>
                        <TableHead className="text-white font-semibold text-xs py-3 text-right">Paid Amount</TableHead>
                        <TableHead className="text-white font-semibold text-xs py-3 text-right">Overtime</TableHead>
                        <TableHead className="text-white font-semibold text-xs py-3 text-right">Incentive</TableHead>
                        <TableHead className="text-white font-semibold text-xs py-3 text-right">Bonus</TableHead>
                        <TableHead className="text-white font-semibold text-xs py-3 text-right">Overall</TableHead>
                        <TableHead className="text-white font-semibold text-xs py-3">Remarks</TableHead>
                        <TableHead className="text-white font-semibold text-xs py-3">Given By</TableHead>
                        <TableHead className="text-white font-semibold text-xs py-3 text-center">Action</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {salaryLoading ? (
                        <TableRow><TableCell colSpan={11} className="text-center py-8"><Skeleton className="h-4 w-48 mx-auto" /></TableCell></TableRow>
                      ) : paginated.length === 0 ? (
                        <TableRow><TableCell colSpan={11} className="text-center py-8 text-muted-foreground text-sm italic">No data available in table</TableCell></TableRow>
                      ) : (
                        paginated.map((entry, idx) => (
                          <TableRow key={entry.id} className="border-b border-border hover:bg-muted/30" data-testid={`salary-row-${entry.id}`}>
                            <TableCell className="text-xs text-muted-foreground py-2.5">{(salaryPage - 1) * salaryPageSize + idx + 1}</TableCell>
                            <TableCell className="text-sm py-2.5">{entry.salaryDate}</TableCell>
                            <TableCell className="text-sm py-2.5 font-medium">{entry.salaryMonth}</TableCell>
                            <TableCell className="text-sm py-2.5 text-right font-semibold text-green-600 dark:text-green-400 tabular-nums">{Number(entry.paidAmount || 0).toLocaleString()}</TableCell>
                            <TableCell className="text-sm py-2.5 text-right tabular-nums">{Number(entry.overtime || 0).toLocaleString()}</TableCell>
                            <TableCell className="text-sm py-2.5 text-right tabular-nums">{Number(entry.incentive || 0).toLocaleString()}</TableCell>
                            <TableCell className="text-sm py-2.5 text-right tabular-nums">{Number(entry.bonus || 0).toLocaleString()}</TableCell>
                            <TableCell className="text-sm py-2.5 text-right font-medium tabular-nums">{Number(entry.overall || 0).toLocaleString()}</TableCell>
                            <TableCell className="text-sm py-2.5 max-w-[120px] truncate">{entry.remarks || "—"}</TableCell>
                            <TableCell className="text-sm py-2.5">{entry.givenBy || "—"}</TableCell>
                            <TableCell className="py-2.5">
                              <div className="flex items-center justify-center gap-0.5">
                                <Button variant="ghost" size="icon" className="h-6 w-6 text-emerald-600 hover:bg-emerald-50" onClick={() => openEditSalary(entry)} data-testid={`btn-edit-salary-${entry.id}`} title="Edit"><Edit className="h-3 w-3" /></Button>
                                <Button variant="ghost" size="icon" className="h-6 w-6 text-red-500 hover:bg-red-50" onClick={() => { if (confirm("Delete this salary entry?")) deleteSalaryMutation.mutate(entry.id); }} data-testid={`btn-delete-salary-${entry.id}`} title="Delete"><Trash2 className="h-3 w-3" /></Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                      <TableRow className="bg-muted/40 font-semibold border-t-2 border-border">
                        <TableCell colSpan={3} className="text-xs font-bold py-2.5 pl-4 uppercase">TOTAL</TableCell>
                        <TableCell className="text-right text-sm font-bold tabular-nums py-2.5">{totals.paid.toLocaleString()}</TableCell>
                        <TableCell className="text-right text-sm tabular-nums py-2.5">{totals.overtime.toLocaleString()}</TableCell>
                        <TableCell className="text-right text-sm tabular-nums py-2.5">{totals.incentive.toLocaleString()}</TableCell>
                        <TableCell className="text-right text-sm tabular-nums py-2.5">{totals.bonus.toLocaleString()}</TableCell>
                        <TableCell className="text-right text-sm font-bold tabular-nums py-2.5">{totals.overall.toLocaleString()}</TableCell>
                        <TableCell colSpan={3} />
                      </TableRow>
                    </TableBody>
                  </Table>
                </div>

                <div className="flex items-center justify-between px-4 py-3 border-t border-border text-xs text-muted-foreground">
                  <span>Showing {filtered.length === 0 ? 0 : (salaryPage - 1) * salaryPageSize + 1}–{Math.min(salaryPage * salaryPageSize, filtered.length)} of {filtered.length} entries</span>
                  <div className="flex gap-1">
                    <Button variant="outline" size="sm" className="h-7 px-3 text-xs" disabled={salaryPage === 1} onClick={() => setSalaryPage(p => p - 1)} data-testid="btn-salary-prev">Previous</Button>
                    <Button variant="outline" size="sm" className="h-7 px-3 text-xs" disabled={salaryPage >= totalPages} onClick={() => setSalaryPage(p => p + 1)} data-testid="btn-salary-next">Next</Button>
                  </div>
                </div>
              </div>
            );
          })()}

          {activeTab === "App Login Detail" && (
            <div data-testid="tab-content-login-detail">
              <div className="bg-[#1e293b] dark:bg-slate-800 px-5 py-3">
                <h3 className="text-white font-semibold text-sm tracking-wide">App Login Detail</h3>
              </div>
              <div className="divide-y divide-border">
                <div className="grid grid-cols-1 md:grid-cols-2 divide-y md:divide-y-0 md:divide-x divide-border">
                  <div className="flex items-center px-5 py-3 gap-3">
                    <span className="text-sm text-muted-foreground font-medium min-w-[110px]">Username</span>
                    <span className="text-muted-foreground">:</span>
                    <span className="text-sm font-semibold font-mono">{employee.email || employee.empCode}</span>
                  </div>
                  <div className="flex items-center px-5 py-3 gap-3">
                    <span className="text-sm text-muted-foreground font-medium min-w-[110px]">Employee Code</span>
                    <span className="text-muted-foreground">:</span>
                    <span className="text-sm font-semibold font-mono">{employee.empCode}</span>
                  </div>
                </div>
                <div className="flex items-center px-5 py-3 gap-3 bg-muted/20">
                  <span className="text-sm text-muted-foreground font-medium min-w-[110px]">Portal Access</span>
                  <span className="text-muted-foreground">:</span>
                  <Badge variant="secondary" className="text-[10px] text-amber-600 bg-amber-50 dark:bg-amber-950 border border-amber-300">Pending Setup</Badge>
                </div>
                <div className="p-8 text-center text-muted-foreground">
                  <Key className="h-10 w-10 mx-auto mb-2 opacity-20" />
                  <p className="text-sm font-medium">App portal login not configured</p>
                  <p className="text-xs mt-1">Contact system administrator to set up employee portal access</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Edit className="h-4 w-4 text-primary" /> Edit Employee — {employee.fullName}
            </DialogTitle>
          </DialogHeader>
          <Form {...editForm}>
            <form onSubmit={editForm.handleSubmit(onEditSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <FormField control={editForm.control} name="fullName" render={({ field }) => (
                  <FormItem><FormLabel>Full Name</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={editForm.control} name="empCode" render={({ field }) => (
                  <FormItem><FormLabel>Emp Code</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={editForm.control} name="email" render={({ field }) => (
                  <FormItem><FormLabel>Email</FormLabel><FormControl><Input type="email" {...field} value={field.value || ""} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={editForm.control} name="phone" render={({ field }) => (
                  <FormItem><FormLabel>Phone</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={editForm.control} name="cnic" render={({ field }) => (
                  <FormItem><FormLabel>CNIC</FormLabel><FormControl><Input {...field} value={field.value || ""} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={editForm.control} name="department" render={({ field }) => (
                  <FormItem><FormLabel>Department</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent>
                        {Object.entries(departmentLabels).map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}
                      </SelectContent>
                    </Select><FormMessage />
                  </FormItem>
                )} />
                <FormField control={editForm.control} name="designation" render={({ field }) => (
                  <FormItem><FormLabel>Designation</FormLabel><FormControl><Input {...field} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={editForm.control} name="salary" render={({ field }) => (
                  <FormItem><FormLabel>Salary (Rs.)</FormLabel><FormControl><Input type="number" {...field} value={field.value || ""} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={editForm.control} name="joinDate" render={({ field }) => (
                  <FormItem><FormLabel>Join Date</FormLabel><FormControl><Input type="date" {...field} value={field.value || ""} /></FormControl><FormMessage /></FormItem>
                )} />
                <FormField control={editForm.control} name="status" render={({ field }) => (
                  <FormItem><FormLabel>Status</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl><SelectTrigger><SelectValue /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="on_leave">On Leave</SelectItem>
                        <SelectItem value="terminated">Terminated</SelectItem>
                      </SelectContent>
                    </Select><FormMessage />
                  </FormItem>
                )} />
                <FormField control={editForm.control} name="gender" render={({ field }) => (
                  <FormItem><FormLabel>Gender</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value || ""}>
                      <FormControl><SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger></FormControl>
                      <SelectContent>
                        <SelectItem value="male">Male</SelectItem>
                        <SelectItem value="female">Female</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select><FormMessage />
                  </FormItem>
                )} />
                <FormField control={editForm.control} name="dateOfBirth" render={({ field }) => (
                  <FormItem><FormLabel>Date of Birth</FormLabel><FormControl><Input type="date" {...field} value={field.value || ""} /></FormControl><FormMessage /></FormItem>
                )} />
              </div>
              <FormField control={editForm.control} name="address" render={({ field }) => (
                <FormItem><FormLabel>Address</FormLabel><FormControl><Input {...field} value={field.value || ""} /></FormControl><FormMessage /></FormItem>
              )} />
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setEditOpen(false)}>Cancel</Button>
                <Button type="submit" disabled={updateMutation.isPending} className="gap-1.5">
                  <Save className="h-3.5 w-3.5" />
                  {updateMutation.isPending ? "Saving..." : "Save Changes"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <Dialog open={salaryDialogOpen} onOpenChange={open => { if (!open) { setSalaryDialogOpen(false); setEditingSalary(null); } }}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <BanknoteIcon className="h-4 w-4 text-primary" />
              {editingSalary ? "Edit Salary Entry" : "Add Salary Payment"}
            </DialogTitle>
          </DialogHeader>
          <Form {...salaryForm}>
            <form onSubmit={salaryForm.handleSubmit(onSalarySubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <FormField control={salaryForm.control} name="salaryDate" render={({ field }) => (
                  <FormItem><FormLabel>Salary Date <span className="text-destructive">*</span></FormLabel>
                    <FormControl><Input type="date" {...field} /></FormControl><FormMessage />
                  </FormItem>
                )} />
                <FormField control={salaryForm.control} name="salaryMonth" render={({ field }) => (
                  <FormItem><FormLabel>Salary Month <span className="text-destructive">*</span></FormLabel>
                    <FormControl><Input placeholder="e.g. January 2025" {...field} /></FormControl><FormMessage />
                  </FormItem>
                )} />
                <FormField control={salaryForm.control} name="paidAmount" render={({ field }) => (
                  <FormItem><FormLabel>Paid Amount (Rs.)</FormLabel>
                    <FormControl><Input type="number" step="0.01" {...field} value={field.value || "0"} /></FormControl><FormMessage />
                  </FormItem>
                )} />
                <FormField control={salaryForm.control} name="overtime" render={({ field }) => (
                  <FormItem><FormLabel>Overtime (Rs.)</FormLabel>
                    <FormControl><Input type="number" step="0.01" {...field} value={field.value || "0"} /></FormControl><FormMessage />
                  </FormItem>
                )} />
                <FormField control={salaryForm.control} name="incentive" render={({ field }) => (
                  <FormItem><FormLabel>Incentive (Rs.)</FormLabel>
                    <FormControl><Input type="number" step="0.01" {...field} value={field.value || "0"} /></FormControl><FormMessage />
                  </FormItem>
                )} />
                <FormField control={salaryForm.control} name="bonus" render={({ field }) => (
                  <FormItem><FormLabel>Bonus (Rs.)</FormLabel>
                    <FormControl><Input type="number" step="0.01" {...field} value={field.value || "0"} /></FormControl><FormMessage />
                  </FormItem>
                )} />
                <FormField control={salaryForm.control} name="overall" render={({ field }) => (
                  <FormItem><FormLabel>Overall Total (Rs.)</FormLabel>
                    <FormControl><Input type="number" step="0.01" {...field} value={field.value || "0"} /></FormControl><FormMessage />
                  </FormItem>
                )} />
                <FormField control={salaryForm.control} name="givenBy" render={({ field }) => (
                  <FormItem><FormLabel>Given By</FormLabel>
                    <FormControl><Input placeholder="Name of payment giver" {...field} value={field.value || ""} /></FormControl><FormMessage />
                  </FormItem>
                )} />
              </div>
              <FormField control={salaryForm.control} name="remarks" render={({ field }) => (
                <FormItem><FormLabel>Remarks</FormLabel>
                  <FormControl><Input placeholder="Optional notes..." {...field} value={field.value || ""} /></FormControl><FormMessage />
                </FormItem>
              )} />
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setSalaryDialogOpen(false)}>Cancel</Button>
                <Button type="submit" disabled={createSalaryMutation.isPending || updateSalaryMutation.isPending} className="gap-1.5">
                  <Save className="h-3.5 w-3.5" />
                  {(createSalaryMutation.isPending || updateSalaryMutation.isPending) ? "Saving..." : editingSalary ? "Update Entry" : "Add Entry"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
