import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Plus,
  Search,
  MoreHorizontal,
  Edit,
  Trash2,
  FileBarChart,
  Play,
  Download,
  Users,
  FileText,
  LifeBuoy,
  ArrowLeftRight,
  DollarSign,
  Calendar,
  CreditCard,
  Globe,
  Zap,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertReportSchema, type Report, type InsertReport } from "@shared/schema";
import { z } from "zod";

const reportFormSchema = insertReportSchema.extend({
  name: z.string().min(1, "Report name is required"),
  type: z.string().min(1, "Report type is required"),
});

export default function ReportsPage() {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingReport, setEditingReport] = useState<Report | null>(null);

  const { data: reports, isLoading } = useQuery<Report[]>({
    queryKey: ["/api/reports"],
  });

  const form = useForm<InsertReport>({
    resolver: zodResolver(reportFormSchema),
    defaultValues: {
      name: "",
      type: "revenue",
      description: "",
      parameters: "",
      createdBy: "",
      status: "active",
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertReport) => {
      const res = await apiRequest("POST", "/api/reports", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reports"] });
      setDialogOpen(false);
      form.reset();
      toast({ title: "Report created successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertReport> }) => {
      const res = await apiRequest("PATCH", `/api/reports/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reports"] });
      setDialogOpen(false);
      setEditingReport(null);
      form.reset();
      toast({ title: "Report updated successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/reports/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reports"] });
      toast({ title: "Report deleted" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const runReportMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("PATCH", `/api/reports/${id}`, {
        lastRunAt: new Date().toISOString(),
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reports"] });
      toast({ title: "Report executed successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const openCreate = () => {
    setEditingReport(null);
    form.reset({
      name: "",
      type: "revenue",
      description: "",
      parameters: "",
      createdBy: "",
      status: "active",
    });
    setDialogOpen(true);
  };

  const openEdit = (report: Report) => {
    setEditingReport(report);
    form.reset({
      name: report.name,
      type: report.type,
      description: report.description || "",
      parameters: report.parameters || "",
      createdBy: report.createdBy || "",
      status: report.status,
    });
    setDialogOpen(true);
  };

  const onSubmit = (data: InsertReport) => {
    if (editingReport) {
      updateMutation.mutate({ id: editingReport.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const filtered = (reports || []).filter((r) => {
    const matchSearch =
      r.name.toLowerCase().includes(search.toLowerCase()) ||
      r.type.toLowerCase().includes(search.toLowerCase());
    const matchType = typeFilter === "all" || r.type === typeFilter;
    return matchSearch && matchType;
  });

  const typeColors: Record<string, string> = {
    revenue: "text-green-700 dark:text-green-300 bg-green-50 dark:bg-green-950",
    customers: "text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950",
    invoices: "text-purple-700 dark:text-purple-300 bg-purple-50 dark:bg-purple-950",
    tickets: "text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950",
    inventory: "text-cyan-700 dark:text-cyan-300 bg-cyan-50 dark:bg-cyan-950",
    performance: "text-rose-700 dark:text-rose-300 bg-rose-50 dark:bg-rose-950",
  };

  const statusColors: Record<string, string> = {
    active: "text-green-700 dark:text-green-300 bg-green-50 dark:bg-green-950",
    archived: "text-gray-500 bg-gray-50 dark:bg-gray-900",
  };

  return (
    <div className="p-6 space-y-6 max-w-[1400px] mx-auto">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight" data-testid="text-reports-title">Reports</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Manage and run system reports</p>
        </div>
        <Button onClick={openCreate} data-testid="button-add-report">
          <Plus className="h-4 w-4 mr-1" />
          Create Report
        </Button>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Quick Data Export (CSV)</h3>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3">
            {[
              { label: "Customers", entity: "customers", icon: Users, color: "text-blue-500" },
              { label: "Invoices", entity: "invoices", icon: FileText, color: "text-purple-500" },
              { label: "Tickets", entity: "tickets", icon: LifeBuoy, color: "text-amber-500" },
              { label: "Transactions", entity: "transactions", icon: ArrowLeftRight, color: "text-green-500" },
              { label: "Expenses", entity: "expenses", icon: DollarSign, color: "text-red-500" },
              { label: "Attendance", entity: "attendance", icon: Calendar, color: "text-cyan-500" },
              { label: "Credit Notes", entity: "credit-notes", icon: CreditCard, color: "text-orange-500" },
              { label: "IP Addresses", entity: "ip-addresses", icon: Globe, color: "text-indigo-500" },
              { label: "Outages", entity: "outages", icon: Zap, color: "text-rose-500" },
            ].map(({ label, entity, icon: Icon, color }) => (
              <Button
                key={entity}
                variant="outline"
                className="h-auto py-3 flex flex-col items-center gap-1.5"
                data-testid={`button-export-${entity}`}
                onClick={() => window.open(`/api/export/${entity}`, "_blank")}
              >
                <Icon className={`h-5 w-5 ${color}`} />
                <span className="text-xs font-medium">{label}</span>
                <Download className="h-3 w-3 text-muted-foreground" />
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
            <div className="relative flex-1 w-full sm:max-w-xs">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search reports..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9"
                data-testid="input-search-reports"
              />
            </div>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-[160px]" data-testid="select-report-type">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="revenue">Revenue</SelectItem>
                <SelectItem value="customers">Customers</SelectItem>
                <SelectItem value="invoices">Invoices</SelectItem>
                <SelectItem value="tickets">Tickets</SelectItem>
                <SelectItem value="inventory">Inventory</SelectItem>
                <SelectItem value="performance">Performance</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-5 space-y-3">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-14 w-full" />
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
              <FileBarChart className="h-12 w-12 mb-3 opacity-30" />
              <p className="font-medium">No reports found</p>
              <p className="text-sm mt-1">Create a new report to get started</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Report Name</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead className="hidden md:table-cell">Description</TableHead>
                    <TableHead className="hidden lg:table-cell">Last Run</TableHead>
                    <TableHead className="hidden sm:table-cell">Created By</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="w-10"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((report) => (
                    <TableRow key={report.id} data-testid={`row-report-${report.id}`}>
                      <TableCell>
                        <span className="font-medium" data-testid={`text-report-name-${report.id}`}>{report.name}</span>
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary" className={`no-default-active-elevate text-[10px] capitalize ${typeColors[report.type] || ""}`} data-testid={`badge-report-type-${report.id}`}>
                          {report.type}
                        </Badge>
                      </TableCell>
                      <TableCell className="hidden md:table-cell text-sm text-muted-foreground">
                        <span className="max-w-[200px] truncate block" data-testid={`text-report-desc-${report.id}`}>
                          {report.description || "-"}
                        </span>
                      </TableCell>
                      <TableCell className="hidden lg:table-cell text-sm text-muted-foreground" data-testid={`text-report-lastrun-${report.id}`}>
                        {report.lastRunAt ? new Date(report.lastRunAt).toLocaleString() : "Never"}
                      </TableCell>
                      <TableCell className="hidden sm:table-cell text-sm text-muted-foreground" data-testid={`text-report-createdby-${report.id}`}>
                        {report.createdBy || "-"}
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary" className={`no-default-active-elevate text-[10px] capitalize ${statusColors[report.status] || ""}`} data-testid={`badge-report-status-${report.id}`}>
                          {report.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon" data-testid={`button-report-actions-${report.id}`}>
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => runReportMutation.mutate(report.id)} data-testid={`button-run-report-${report.id}`}>
                              <Play className="h-4 w-4 mr-2" />
                              Run Report
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => openEdit(report)} data-testid={`button-edit-report-${report.id}`}>
                              <Edit className="h-4 w-4 mr-2" />
                              Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem
                              className="text-destructive"
                              onClick={() => deleteMutation.mutate(report.id)}
                              data-testid={`button-delete-report-${report.id}`}
                            >
                              <Trash2 className="h-4 w-4 mr-2" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingReport ? "Edit Report" : "Create Report"}</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Report Name</FormLabel>
                    <FormControl>
                      <Input placeholder="Monthly Revenue Report" data-testid="input-report-name" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Type</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value || "revenue"}>
                        <FormControl>
                          <SelectTrigger data-testid="select-form-report-type">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="revenue">Revenue</SelectItem>
                          <SelectItem value="customers">Customers</SelectItem>
                          <SelectItem value="invoices">Invoices</SelectItem>
                          <SelectItem value="tickets">Tickets</SelectItem>
                          <SelectItem value="inventory">Inventory</SelectItem>
                          <SelectItem value="performance">Performance</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Status</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value || "active"}>
                        <FormControl>
                          <SelectTrigger data-testid="select-report-status">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="active">Active</SelectItem>
                          <SelectItem value="archived">Archived</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Report description..." data-testid="input-report-description" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="parameters"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Parameters (JSON)</FormLabel>
                    <FormControl>
                      <Textarea placeholder='{"startDate": "2025-01-01", "endDate": "2025-12-31"}' data-testid="input-report-parameters" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="createdBy"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Created By</FormLabel>
                    <FormControl>
                      <Input placeholder="Admin" data-testid="input-report-createdby" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="button" variant="secondary" onClick={() => setDialogOpen(false)} data-testid="button-cancel-report">
                  Cancel
                </Button>
                <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending} data-testid="button-save-report">
                  {createMutation.isPending || updateMutation.isPending ? "Saving..." : editingReport ? "Update" : "Create"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
