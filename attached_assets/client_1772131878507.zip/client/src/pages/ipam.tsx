import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Plus,
  Search,
  MoreHorizontal,
  Edit,
  Trash2,
  Globe,
  Network,
  Server,
  Wifi,
  Download,
  CheckCircle,
  Clock,
  AlertCircle,
  XCircle,
  Shield,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertIpAddressSchema, type IpAddress, type InsertIpAddress, type Customer } from "@shared/schema";
import { z } from "zod";

const ipFormSchema = insertIpAddressSchema.extend({
  ipAddress: z.string().min(7, "Valid IP required"),
  type: z.string().min(1, "Type is required"),
  status: z.string().min(1, "Status is required"),
});

export default function IpamPage() {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingIp, setEditingIp] = useState<IpAddress | null>(null);

  const { data: ipAddresses, isLoading } = useQuery<(IpAddress & { customerName?: string })[]>({
    queryKey: ["/api/ip-addresses"],
  });

  const { data: customers } = useQuery<Customer[]>({
    queryKey: ["/api/customers"],
  });

  const form = useForm<InsertIpAddress>({
    resolver: zodResolver(ipFormSchema),
    defaultValues: {
      ipAddress: "",
      subnet: "",
      gateway: "",
      type: "dynamic",
      status: "available",
      customerId: undefined,
      assignedDate: "",
      vlan: "",
      pool: "",
      notes: "",
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertIpAddress) => {
      const res = await apiRequest("POST", "/api/ip-addresses", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/ip-addresses"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      setDialogOpen(false);
      form.reset();
      toast({ title: "IP address created successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertIpAddress> }) => {
      const res = await apiRequest("PATCH", `/api/ip-addresses/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/ip-addresses"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      setDialogOpen(false);
      setEditingIp(null);
      form.reset();
      toast({ title: "IP address updated successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/ip-addresses/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/ip-addresses"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({ title: "IP address deleted" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const openCreate = () => {
    setEditingIp(null);
    form.reset({
      ipAddress: "",
      subnet: "",
      gateway: "",
      type: "dynamic",
      status: "available",
      customerId: undefined,
      assignedDate: "",
      vlan: "",
      pool: "",
      notes: "",
    });
    setDialogOpen(true);
  };

  const openEdit = (ip: IpAddress) => {
    setEditingIp(ip);
    form.reset({
      ipAddress: ip.ipAddress,
      subnet: ip.subnet || "",
      gateway: ip.gateway || "",
      type: ip.type,
      status: ip.status,
      customerId: ip.customerId ?? undefined,
      assignedDate: ip.assignedDate || "",
      vlan: ip.vlan || "",
      pool: ip.pool || "",
      notes: ip.notes || "",
    });
    setDialogOpen(true);
  };

  const onSubmit = (data: InsertIpAddress) => {
    if (editingIp) {
      updateMutation.mutate({ id: editingIp.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleExport = () => {
    window.open("/api/export/ip-addresses", "_blank");
  };

  const filtered = (ipAddresses || []).filter((ip) => {
    const matchSearch =
      ip.ipAddress.toLowerCase().includes(search.toLowerCase()) ||
      (ip.subnet || "").toLowerCase().includes(search.toLowerCase()) ||
      (ip.vlan || "").toLowerCase().includes(search.toLowerCase()) ||
      (ip.pool || "").toLowerCase().includes(search.toLowerCase()) ||
      (ip.customerName || "").toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === "all" || ip.status === statusFilter;
    const matchType = typeFilter === "all" || ip.type === typeFilter;
    return matchSearch && matchStatus && matchType;
  });

  const statusConfig: Record<string, { icon: any; color: string }> = {
    available: { icon: CheckCircle, color: "text-green-700 dark:text-green-300 bg-green-50 dark:bg-green-950" },
    assigned: { icon: Globe, color: "text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950" },
    reserved: { icon: Shield, color: "text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950" },
    blocked: { icon: XCircle, color: "text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950" },
  };

  const typeColors: Record<string, string> = {
    static: "text-purple-700 dark:text-purple-300 bg-purple-50 dark:bg-purple-950",
    dynamic: "text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950",
    reserved: "text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950",
  };

  const allIps = ipAddresses || [];
  const totalIps = allIps.length;
  const availableIps = allIps.filter((ip) => ip.status === "available").length;
  const assignedIps = allIps.filter((ip) => ip.status === "assigned").length;
  const reservedIps = allIps.filter((ip) => ip.status === "reserved").length;

  const summaryCards = [
    { title: "Total IPs", value: totalIps, icon: Network, color: "text-blue-600 dark:text-blue-400" },
    { title: "Available", value: availableIps, icon: CheckCircle, color: "text-green-600 dark:text-green-400" },
    { title: "Assigned", value: assignedIps, icon: Globe, color: "text-purple-600 dark:text-purple-400" },
    { title: "Reserved", value: reservedIps, icon: Shield, color: "text-amber-600 dark:text-amber-400" },
  ];

  return (
    <div className="p-6 space-y-6 max-w-[1400px] mx-auto">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight" data-testid="text-ipam-title">IP Address Management</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Manage IP allocations, pools, and assignments</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button variant="outline" onClick={handleExport} data-testid="button-export-ips">
            <Download className="h-4 w-4 mr-1" />
            Export CSV
          </Button>
          <Button onClick={openCreate} data-testid="button-add-ip">
            <Plus className="h-4 w-4 mr-1" />
            Add IP Address
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {summaryCards.map((card) => (
          <Card key={card.title} data-testid={`card-summary-${card.title.toLowerCase().replace(/\s+/g, "-")}`}>
            <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
              <span className="text-sm font-medium text-muted-foreground">{card.title}</span>
              <card.icon className={`h-4 w-4 ${card.color}`} />
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-8 w-16" />
              ) : (
                <div className="text-2xl font-bold" data-testid={`text-summary-${card.title.toLowerCase().replace(/\s+/g, "-")}`}>
                  {card.value}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
            <div className="relative flex-1 w-full sm:max-w-xs">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search IP addresses..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9"
                data-testid="input-search-ips"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[160px]" data-testid="select-ip-status-filter">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="available">Available</SelectItem>
                <SelectItem value="assigned">Assigned</SelectItem>
                <SelectItem value="reserved">Reserved</SelectItem>
                <SelectItem value="blocked">Blocked</SelectItem>
              </SelectContent>
            </Select>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-[160px]" data-testid="select-ip-type-filter">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="static">Static</SelectItem>
                <SelectItem value="dynamic">Dynamic</SelectItem>
                <SelectItem value="reserved">Reserved</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-5 space-y-3">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-14 w-full" />
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
              <Network className="h-12 w-12 mb-3 opacity-30" />
              <p className="font-medium">No IP addresses found</p>
              <p className="text-sm mt-1">Add a new IP address to get started</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>IP Address</TableHead>
                    <TableHead className="hidden md:table-cell">Subnet</TableHead>
                    <TableHead className="hidden lg:table-cell">Gateway</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="hidden md:table-cell">Customer</TableHead>
                    <TableHead className="hidden lg:table-cell">VLAN</TableHead>
                    <TableHead className="hidden lg:table-cell">Pool</TableHead>
                    <TableHead className="hidden xl:table-cell">Assigned Date</TableHead>
                    <TableHead className="w-10"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((ip) => {
                    const config = statusConfig[ip.status] || statusConfig.available;
                    const StatusIcon = config.icon;
                    return (
                      <TableRow key={ip.id} data-testid={`row-ip-${ip.id}`}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Globe className="h-4 w-4 text-muted-foreground" />
                            <span className="font-mono font-medium" data-testid={`text-ip-address-${ip.id}`}>{ip.ipAddress}</span>
                          </div>
                        </TableCell>
                        <TableCell className="hidden md:table-cell text-sm text-muted-foreground font-mono">
                          {ip.subnet || "\u2014"}
                        </TableCell>
                        <TableCell className="hidden lg:table-cell text-sm text-muted-foreground font-mono">
                          {ip.gateway || "\u2014"}
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary" className={`no-default-active-elevate text-[10px] capitalize ${typeColors[ip.type] || ""}`}>
                            {ip.type}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary" className={`no-default-active-elevate text-[10px] capitalize ${config.color}`}>
                            <StatusIcon className="h-3 w-3 mr-1" />
                            {ip.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="hidden md:table-cell text-sm text-muted-foreground">
                          {ip.customerName || (ip.customerId ? `#${ip.customerId}` : "\u2014")}
                        </TableCell>
                        <TableCell className="hidden lg:table-cell text-sm text-muted-foreground">
                          {ip.vlan || "\u2014"}
                        </TableCell>
                        <TableCell className="hidden lg:table-cell text-sm text-muted-foreground">
                          {ip.pool || "\u2014"}
                        </TableCell>
                        <TableCell className="hidden xl:table-cell text-sm text-muted-foreground">
                          {ip.assignedDate || "\u2014"}
                        </TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" data-testid={`button-ip-actions-${ip.id}`}>
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => openEdit(ip)} data-testid={`button-edit-ip-${ip.id}`}>
                                <Edit className="h-4 w-4 mr-2" />
                                Edit
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                className="text-destructive"
                                onClick={() => deleteMutation.mutate(ip.id)}
                                data-testid={`button-delete-ip-${ip.id}`}
                              >
                                <Trash2 className="h-4 w-4 mr-2" />
                                Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle data-testid="text-dialog-title">
              {editingIp ? "Edit IP Address" : "Add IP Address"}
            </DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="ipAddress"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>IP Address</FormLabel>
                      <FormControl>
                        <Input placeholder="192.168.1.1" {...field} data-testid="input-ip-address" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="subnet"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Subnet</FormLabel>
                      <FormControl>
                        <Input placeholder="255.255.255.0" {...field} value={field.value || ""} data-testid="input-subnet" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="gateway"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Gateway</FormLabel>
                      <FormControl>
                        <Input placeholder="192.168.1.1" {...field} value={field.value || ""} data-testid="input-gateway" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Type</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-ip-type">
                            <SelectValue placeholder="Select type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="static">Static</SelectItem>
                          <SelectItem value="dynamic">Dynamic</SelectItem>
                          <SelectItem value="reserved">Reserved</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Status</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-ip-status">
                            <SelectValue placeholder="Select status" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="available">Available</SelectItem>
                          <SelectItem value="assigned">Assigned</SelectItem>
                          <SelectItem value="reserved">Reserved</SelectItem>
                          <SelectItem value="blocked">Blocked</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="customerId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Customer</FormLabel>
                      <Select
                        onValueChange={(v) => field.onChange(v === "none" ? undefined : parseInt(v))}
                        value={field.value ? String(field.value) : "none"}
                      >
                        <FormControl>
                          <SelectTrigger data-testid="select-ip-customer">
                            <SelectValue placeholder="Select customer" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="none">No Customer</SelectItem>
                          {(customers || []).map((c) => (
                            <SelectItem key={c.id} value={String(c.id)}>
                              {c.fullName} ({c.customerId})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="assignedDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Assigned Date</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} value={field.value || ""} data-testid="input-assigned-date" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="vlan"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>VLAN</FormLabel>
                      <FormControl>
                        <Input placeholder="VLAN ID" {...field} value={field.value || ""} data-testid="input-vlan" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="pool"
                  render={({ field }) => (
                    <FormItem className="sm:col-span-2">
                      <FormLabel>Pool</FormLabel>
                      <FormControl>
                        <Input placeholder="IP Pool name" {...field} value={field.value || ""} data-testid="input-pool" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem className="sm:col-span-2">
                      <FormLabel>Notes</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Additional notes..." {...field} value={field.value || ""} data-testid="input-notes" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setDialogOpen(false)}
                  data-testid="button-cancel-ip"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={createMutation.isPending || updateMutation.isPending}
                  data-testid="button-submit-ip"
                >
                  {createMutation.isPending || updateMutation.isPending
                    ? "Saving..."
                    : editingIp
                      ? "Update"
                      : "Create"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
