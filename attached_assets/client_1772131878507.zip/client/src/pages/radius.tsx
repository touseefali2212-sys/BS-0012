import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Plus,
  Search,
  MoreHorizontal,
  Edit,
  Trash2,
  Download,
  CheckCircle,
  XCircle,
  Shield,
  Users,
  Wifi,
  Radio,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertRadiusProfileSchema, type RadiusProfile, type InsertRadiusProfile } from "@shared/schema";
import { z } from "zod";

const profileFormSchema = insertRadiusProfileSchema.extend({
  name: z.string().min(1, "Name is required"),
  downloadRate: z.string().min(1, "Download rate is required"),
  uploadRate: z.string().min(1, "Upload rate is required"),
  status: z.string().min(1, "Status is required"),
});

export default function RadiusPage() {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingProfile, setEditingProfile] = useState<RadiusProfile | null>(null);

  const { data: profiles, isLoading } = useQuery<RadiusProfile[]>({
    queryKey: ["/api/radius-profiles"],
  });

  const form = useForm<InsertRadiusProfile>({
    resolver: zodResolver(profileFormSchema),
    defaultValues: {
      name: "",
      downloadRate: "",
      uploadRate: "",
      burstDownload: "",
      burstUpload: "",
      burstThreshold: "",
      burstTime: "",
      priority: 8,
      dataQuota: "",
      sessionTimeout: undefined,
      idleTimeout: 300,
      addressPool: "",
      sharedUsers: 1,
      status: "active",
      notes: "",
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertRadiusProfile) => {
      const res = await apiRequest("POST", "/api/radius-profiles", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/radius-profiles"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      setDialogOpen(false);
      form.reset();
      toast({ title: "RADIUS profile created successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertRadiusProfile> }) => {
      const res = await apiRequest("PATCH", `/api/radius-profiles/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/radius-profiles"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      setDialogOpen(false);
      setEditingProfile(null);
      form.reset();
      toast({ title: "RADIUS profile updated successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/radius-profiles/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/radius-profiles"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({ title: "RADIUS profile deleted" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const openCreate = () => {
    setEditingProfile(null);
    form.reset({
      name: "",
      downloadRate: "",
      uploadRate: "",
      burstDownload: "",
      burstUpload: "",
      burstThreshold: "",
      burstTime: "",
      priority: 8,
      dataQuota: "",
      sessionTimeout: undefined,
      idleTimeout: 300,
      addressPool: "",
      sharedUsers: 1,
      status: "active",
      notes: "",
    });
    setDialogOpen(true);
  };

  const openEdit = (profile: RadiusProfile) => {
    setEditingProfile(profile);
    form.reset({
      name: profile.name,
      downloadRate: profile.downloadRate,
      uploadRate: profile.uploadRate,
      burstDownload: profile.burstDownload || "",
      burstUpload: profile.burstUpload || "",
      burstThreshold: profile.burstThreshold || "",
      burstTime: profile.burstTime || "",
      priority: profile.priority ?? 8,
      dataQuota: profile.dataQuota || "",
      sessionTimeout: profile.sessionTimeout ?? undefined,
      idleTimeout: profile.idleTimeout ?? 300,
      addressPool: profile.addressPool || "",
      sharedUsers: profile.sharedUsers ?? 1,
      status: profile.status,
      notes: profile.notes || "",
    });
    setDialogOpen(true);
  };

  const onSubmit = (data: InsertRadiusProfile) => {
    if (editingProfile) {
      updateMutation.mutate({ id: editingProfile.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleExport = () => {
    if (!profiles || profiles.length === 0) return;
    const headers = ["Name", "Download Rate", "Upload Rate", "Burst Download", "Burst Upload", "Priority", "Data Quota", "Address Pool", "Session Timeout", "Status"];
    const rows = profiles.map((p) => [
      p.name,
      p.downloadRate,
      p.uploadRate,
      p.burstDownload || "",
      p.burstUpload || "",
      String(p.priority ?? ""),
      p.dataQuota || "",
      p.addressPool || "",
      String(p.sessionTimeout ?? ""),
      p.status,
    ]);
    const csv = [headers.join(","), ...rows.map((r) => r.map((c) => `"${c}"`).join(","))].join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "radius-profiles.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  const filtered = (profiles || []).filter((p) => {
    const matchSearch =
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.downloadRate.toLowerCase().includes(search.toLowerCase()) ||
      p.uploadRate.toLowerCase().includes(search.toLowerCase()) ||
      (p.addressPool || "").toLowerCase().includes(search.toLowerCase()) ||
      (p.dataQuota || "").toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === "all" || p.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const statusConfig: Record<string, { icon: any; color: string }> = {
    active: { icon: CheckCircle, color: "text-green-700 dark:text-green-300 bg-green-50 dark:bg-green-950" },
    inactive: { icon: XCircle, color: "text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950" },
  };

  const allProfiles = profiles || [];
  const totalProfiles = allProfiles.length;
  const activeProfiles = allProfiles.filter((p) => p.status === "active").length;
  const totalPppoeUsers = allProfiles.reduce((sum, p) => sum + (p.sharedUsers ?? 0), 0);
  const onlineUsers = allProfiles.filter((p) => p.status === "active").reduce((sum, p) => sum + (p.sharedUsers ?? 0), 0);

  const summaryCards = [
    { title: "Total Profiles", value: totalProfiles, icon: Shield, color: "text-blue-600 dark:text-blue-400" },
    { title: "Active Profiles", value: activeProfiles, icon: CheckCircle, color: "text-green-600 dark:text-green-400" },
    { title: "Total PPPoE Users", value: totalPppoeUsers, icon: Users, color: "text-purple-600 dark:text-purple-400" },
    { title: "Online Users", value: onlineUsers, icon: Wifi, color: "text-amber-600 dark:text-amber-400" },
  ];

  return (
    <div className="p-6 space-y-6 max-w-[1400px] mx-auto">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight" data-testid="text-radius-title">RADIUS / AAA Integration</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Manage RADIUS profiles, authentication and accounting</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button variant="outline" onClick={handleExport} data-testid="button-export-profiles">
            <Download className="h-4 w-4 mr-1" />
            Export CSV
          </Button>
          <Button onClick={openCreate} data-testid="button-add-profile">
            <Plus className="h-4 w-4 mr-1" />
            Add Profile
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {summaryCards.map((card) => (
          <Card key={card.title} data-testid={`card-summary-${card.title.toLowerCase().replace(/\s+/g, "-")}`}>
            <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
              <span className="text-sm font-medium text-muted-foreground">{card.title}</span>
              <card.icon className={`h-4 w-4 ${card.color}`} />
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-8 w-16" />
              ) : (
                <div className="text-2xl font-bold" data-testid={`text-summary-${card.title.toLowerCase().replace(/\s+/g, "-")}`}>
                  {card.value}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
            <div className="relative flex-1 w-full sm:max-w-xs">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search profiles..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9"
                data-testid="input-search-profiles"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[160px]" data-testid="select-profile-status-filter">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-5 space-y-3">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-14 w-full" />
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
              <Radio className="h-12 w-12 mb-3 opacity-30" />
              <p className="font-medium">No RADIUS profiles found</p>
              <p className="text-sm mt-1">Add a new profile to get started</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Download Rate</TableHead>
                    <TableHead>Upload Rate</TableHead>
                    <TableHead className="hidden md:table-cell">Burst Download</TableHead>
                    <TableHead className="hidden md:table-cell">Burst Upload</TableHead>
                    <TableHead className="hidden lg:table-cell">Priority</TableHead>
                    <TableHead className="hidden lg:table-cell">Data Quota</TableHead>
                    <TableHead className="hidden xl:table-cell">Address Pool</TableHead>
                    <TableHead className="hidden xl:table-cell">Session Timeout</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="w-10"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((profile) => {
                    const config = statusConfig[profile.status] || statusConfig.active;
                    const StatusIcon = config.icon;
                    return (
                      <TableRow key={profile.id} data-testid={`row-profile-${profile.id}`}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Radio className="h-4 w-4 text-muted-foreground" />
                            <span className="font-medium" data-testid={`text-profile-name-${profile.id}`}>{profile.name}</span>
                          </div>
                        </TableCell>
                        <TableCell className="font-mono text-sm" data-testid={`text-download-rate-${profile.id}`}>
                          {profile.downloadRate}
                        </TableCell>
                        <TableCell className="font-mono text-sm" data-testid={`text-upload-rate-${profile.id}`}>
                          {profile.uploadRate}
                        </TableCell>
                        <TableCell className="hidden md:table-cell text-sm text-muted-foreground font-mono">
                          {profile.burstDownload || "\u2014"}
                        </TableCell>
                        <TableCell className="hidden md:table-cell text-sm text-muted-foreground font-mono">
                          {profile.burstUpload || "\u2014"}
                        </TableCell>
                        <TableCell className="hidden lg:table-cell text-sm text-muted-foreground">
                          {profile.priority ?? "\u2014"}
                        </TableCell>
                        <TableCell className="hidden lg:table-cell text-sm text-muted-foreground">
                          {profile.dataQuota || "\u2014"}
                        </TableCell>
                        <TableCell className="hidden xl:table-cell text-sm text-muted-foreground">
                          {profile.addressPool || "\u2014"}
                        </TableCell>
                        <TableCell className="hidden xl:table-cell text-sm text-muted-foreground">
                          {profile.sessionTimeout ? `${profile.sessionTimeout}s` : "\u2014"}
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary" className={`no-default-active-elevate text-[10px] capitalize ${config.color}`}>
                            <StatusIcon className="h-3 w-3 mr-1" />
                            {profile.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" data-testid={`button-profile-actions-${profile.id}`}>
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => openEdit(profile)} data-testid={`button-edit-profile-${profile.id}`}>
                                <Edit className="h-4 w-4 mr-2" />
                                Edit
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                className="text-destructive"
                                onClick={() => deleteMutation.mutate(profile.id)}
                                data-testid={`button-delete-profile-${profile.id}`}
                              >
                                <Trash2 className="h-4 w-4 mr-2" />
                                Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle data-testid="text-dialog-title">
              {editingProfile ? "Edit RADIUS Profile" : "Add RADIUS Profile"}
            </DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Name</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. 10Mbps-Plan" {...field} data-testid="input-profile-name" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="downloadRate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Download Rate</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. 10M" {...field} data-testid="input-download-rate" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="uploadRate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Upload Rate</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. 5M" {...field} data-testid="input-upload-rate" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="burstDownload"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Burst Download</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. 15M" {...field} value={field.value || ""} data-testid="input-burst-download" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="burstUpload"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Burst Upload</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. 8M" {...field} value={field.value || ""} data-testid="input-burst-upload" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="burstThreshold"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Burst Threshold</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. 8M" {...field} value={field.value || ""} data-testid="input-burst-threshold" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="burstTime"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Burst Time</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. 10s" {...field} value={field.value || ""} data-testid="input-burst-time" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="priority"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Priority</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          placeholder="1-8"
                          {...field}
                          value={field.value ?? ""}
                          onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : undefined)}
                          data-testid="input-priority"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="dataQuota"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Data Quota</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. 100GB" {...field} value={field.value || ""} data-testid="input-data-quota" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="sessionTimeout"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Session Timeout (seconds)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          placeholder="e.g. 3600"
                          {...field}
                          value={field.value ?? ""}
                          onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : undefined)}
                          data-testid="input-session-timeout"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="idleTimeout"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Idle Timeout (seconds)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          placeholder="e.g. 300"
                          {...field}
                          value={field.value ?? ""}
                          onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : undefined)}
                          data-testid="input-idle-timeout"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="addressPool"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Address Pool</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. pool-10m" {...field} value={field.value || ""} data-testid="input-address-pool" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="sharedUsers"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Shared Users</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          placeholder="1"
                          {...field}
                          value={field.value ?? ""}
                          onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : undefined)}
                          data-testid="input-shared-users"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Status</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-profile-status">
                            <SelectValue placeholder="Select status" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="active">Active</SelectItem>
                          <SelectItem value="inactive">Inactive</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Additional notes..." {...field} value={field.value || ""} data-testid="textarea-notes" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)} data-testid="button-cancel">
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={createMutation.isPending || updateMutation.isPending}
                  data-testid="button-submit-profile"
                >
                  {createMutation.isPending || updateMutation.isPending
                    ? "Saving..."
                    : editingProfile
                      ? "Update Profile"
                      : "Create Profile"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
