import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Plus,
  Search,
  MoreHorizontal,
  Edit,
  Trash2,
  AlertTriangle,
  Zap,
  WifiOff,
  Clock,
  CheckCircle,
  Shield,
  Download,
  Users,
  Wrench,
  Calendar,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertOutageSchema, type Outage, type InsertOutage } from "@shared/schema";
import { z } from "zod";

const outageFormSchema = insertOutageSchema.extend({
  outageId: z.string().min(1, "Outage ID is required"),
  title: z.string().min(2, "Title is required"),
  severity: z.string().min(1, "Severity is required"),
  startTime: z.string().min(1, "Start time is required"),
});

export default function OutagesPage() {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingOutage, setEditingOutage] = useState<Outage | null>(null);

  const { data: outages, isLoading } = useQuery<Outage[]>({
    queryKey: ["/api/outages"],
  });

  const form = useForm<InsertOutage>({
    resolver: zodResolver(outageFormSchema),
    defaultValues: {
      outageId: "",
      title: "",
      description: "",
      affectedArea: "",
      affectedCustomers: 0,
      severity: "minor",
      type: "unplanned",
      status: "ongoing",
      startTime: "",
      estimatedRestore: "",
      endTime: "",
      rootCause: "",
      resolution: "",
      notifiedCustomers: false,
      createdBy: "",
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertOutage) => {
      const res = await apiRequest("POST", "/api/outages", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/outages"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      setDialogOpen(false);
      form.reset();
      toast({ title: "Outage created successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertOutage> }) => {
      const res = await apiRequest("PATCH", `/api/outages/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/outages"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      setDialogOpen(false);
      setEditingOutage(null);
      form.reset();
      toast({ title: "Outage updated successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/outages/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/outages"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({ title: "Outage deleted" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const resolveMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("PATCH", `/api/outages/${id}`, {
        status: "resolved",
        endTime: new Date().toISOString(),
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/outages"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({ title: "Outage resolved" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const openCreate = () => {
    setEditingOutage(null);
    form.reset({
      outageId: "",
      title: "",
      description: "",
      affectedArea: "",
      affectedCustomers: 0,
      severity: "minor",
      type: "unplanned",
      status: "ongoing",
      startTime: "",
      estimatedRestore: "",
      endTime: "",
      rootCause: "",
      resolution: "",
      notifiedCustomers: false,
      createdBy: "",
    });
    setDialogOpen(true);
  };

  const openEdit = (outage: Outage) => {
    setEditingOutage(outage);
    form.reset({
      outageId: outage.outageId,
      title: outage.title,
      description: outage.description || "",
      affectedArea: outage.affectedArea || "",
      affectedCustomers: outage.affectedCustomers ?? 0,
      severity: outage.severity,
      type: outage.type,
      status: outage.status,
      startTime: outage.startTime,
      estimatedRestore: outage.estimatedRestore || "",
      endTime: outage.endTime || "",
      rootCause: outage.rootCause || "",
      resolution: outage.resolution || "",
      notifiedCustomers: outage.notifiedCustomers ?? false,
      createdBy: outage.createdBy || "",
    });
    setDialogOpen(true);
  };

  const onSubmit = (data: InsertOutage) => {
    if (editingOutage) {
      updateMutation.mutate({ id: editingOutage.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleExport = () => {
    window.open("/api/export/outages", "_blank");
  };

  const filtered = (outages || []).filter((o) => {
    const matchSearch =
      o.title.toLowerCase().includes(search.toLowerCase()) ||
      o.outageId.toLowerCase().includes(search.toLowerCase()) ||
      (o.affectedArea || "").toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === "all" || o.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const severityConfig: Record<string, { color: string }> = {
    critical: { color: "text-red-700 dark:text-red-300 bg-red-100 dark:bg-red-900" },
    major: { color: "text-orange-700 dark:text-orange-300 bg-orange-100 dark:bg-orange-900" },
    minor: { color: "text-yellow-700 dark:text-yellow-300 bg-yellow-100 dark:bg-yellow-900" },
    info: { color: "text-blue-700 dark:text-blue-300 bg-blue-100 dark:bg-blue-900" },
  };

  const statusConfig: Record<string, { icon: any; color: string }> = {
    ongoing: { icon: Zap, color: "text-red-700 dark:text-red-300 bg-red-50 dark:bg-red-950" },
    investigating: { icon: Search, color: "text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950" },
    resolved: { icon: CheckCircle, color: "text-green-700 dark:text-green-300 bg-green-50 dark:bg-green-950" },
    scheduled: { icon: Calendar, color: "text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950" },
  };

  const typeConfig: Record<string, string> = {
    unplanned: "text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950",
    planned: "text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950",
    maintenance: "text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-950",
  };

  const allOutages = outages || [];
  const activeOutages = allOutages.filter((o) => o.status === "ongoing" || o.status === "investigating").length;
  const plannedMaintenance = allOutages.filter((o) => o.type === "maintenance" || o.type === "planned").length;
  const today = new Date().toISOString().split("T")[0];
  const resolvedToday = allOutages.filter((o) => o.status === "resolved" && o.endTime && o.endTime.startsWith(today)).length;
  const totalAffected = allOutages.filter((o) => o.status !== "resolved").reduce((sum, o) => sum + (o.affectedCustomers ?? 0), 0);

  return (
    <div className="p-6 space-y-6 max-w-[1400px] mx-auto">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight" data-testid="text-outages-title">Service Outage Management</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Monitor and manage service outages and maintenance</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Button variant="outline" onClick={handleExport} data-testid="button-export-outages">
            <Download className="h-4 w-4 mr-1" />
            Export CSV
          </Button>
          <Button onClick={openCreate} data-testid="button-add-outage">
            <Plus className="h-4 w-4 mr-1" />
            Report Outage
          </Button>
        </div>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-24 w-full" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card data-testid="card-active-outages">
            <CardContent className="py-4">
              <div className="flex items-center justify-between gap-2">
                <div>
                  <p className="text-sm text-muted-foreground">Active Outages</p>
                  <p className="text-2xl font-bold" data-testid="text-active-outages-count">{activeOutages}</p>
                </div>
                <div className="flex items-center justify-center h-10 w-10 rounded-lg bg-red-100 dark:bg-red-900">
                  <Zap className="h-5 w-5 text-red-600 dark:text-red-400" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card data-testid="card-planned-maintenance">
            <CardContent className="py-4">
              <div className="flex items-center justify-between gap-2">
                <div>
                  <p className="text-sm text-muted-foreground">Planned Maintenance</p>
                  <p className="text-2xl font-bold" data-testid="text-planned-maintenance-count">{plannedMaintenance}</p>
                </div>
                <div className="flex items-center justify-center h-10 w-10 rounded-lg bg-blue-100 dark:bg-blue-900">
                  <Wrench className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card data-testid="card-resolved-today">
            <CardContent className="py-4">
              <div className="flex items-center justify-between gap-2">
                <div>
                  <p className="text-sm text-muted-foreground">Resolved Today</p>
                  <p className="text-2xl font-bold" data-testid="text-resolved-today-count">{resolvedToday}</p>
                </div>
                <div className="flex items-center justify-center h-10 w-10 rounded-lg bg-green-100 dark:bg-green-900">
                  <CheckCircle className="h-5 w-5 text-green-600 dark:text-green-400" />
                </div>
              </div>
            </CardContent>
          </Card>
          <Card data-testid="card-affected-customers">
            <CardContent className="py-4">
              <div className="flex items-center justify-between gap-2">
                <div>
                  <p className="text-sm text-muted-foreground">Affected Customers</p>
                  <p className="text-2xl font-bold" data-testid="text-affected-customers-count">{totalAffected}</p>
                </div>
                <div className="flex items-center justify-center h-10 w-10 rounded-lg bg-amber-100 dark:bg-amber-900">
                  <Users className="h-5 w-5 text-amber-600 dark:text-amber-400" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      <Card>
        <CardHeader className="pb-3">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
            <div className="relative flex-1 w-full sm:max-w-xs">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search outages..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9"
                data-testid="input-search-outages"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[160px]" data-testid="select-outage-status-filter">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="ongoing">Ongoing</SelectItem>
                <SelectItem value="investigating">Investigating</SelectItem>
                <SelectItem value="resolved">Resolved</SelectItem>
                <SelectItem value="scheduled">Scheduled</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-5 space-y-3">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-14 w-full" />
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
              <WifiOff className="h-12 w-12 mb-3 opacity-30" />
              <p className="font-medium">No outages found</p>
              <p className="text-sm mt-1">Report a new outage to get started</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Outage ID</TableHead>
                    <TableHead>Title</TableHead>
                    <TableHead className="hidden md:table-cell">Affected Area</TableHead>
                    <TableHead>Severity</TableHead>
                    <TableHead className="hidden lg:table-cell">Type</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="hidden lg:table-cell">Start Time</TableHead>
                    <TableHead className="hidden xl:table-cell">Est. Restore</TableHead>
                    <TableHead className="hidden xl:table-cell">Affected</TableHead>
                    <TableHead className="w-10"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((outage) => {
                    const sConfig = statusConfig[outage.status] || statusConfig.ongoing;
                    const StatusIcon = sConfig.icon;
                    const sevConfig = severityConfig[outage.severity] || severityConfig.minor;
                    return (
                      <TableRow key={outage.id} data-testid={`row-outage-${outage.id}`}>
                        <TableCell>
                          <span className="font-mono text-sm" data-testid={`text-outage-id-${outage.id}`}>{outage.outageId}</span>
                        </TableCell>
                        <TableCell>
                          <div className="font-medium max-w-[200px] truncate" data-testid={`text-outage-title-${outage.id}`}>{outage.title}</div>
                        </TableCell>
                        <TableCell className="hidden md:table-cell text-sm text-muted-foreground">
                          {outage.affectedArea || "\u2014"}
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary" className={`no-default-active-elevate text-[10px] capitalize ${sevConfig.color}`} data-testid={`badge-severity-${outage.id}`}>
                            {outage.severity}
                          </Badge>
                        </TableCell>
                        <TableCell className="hidden lg:table-cell">
                          <Badge variant="secondary" className={`no-default-active-elevate text-[10px] capitalize ${typeConfig[outage.type] || ""}`} data-testid={`badge-type-${outage.id}`}>
                            {outage.type}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary" className={`no-default-active-elevate text-[10px] capitalize ${sConfig.color}`} data-testid={`badge-status-${outage.id}`}>
                            <StatusIcon className="h-3 w-3 mr-1" />
                            {outage.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="hidden lg:table-cell text-sm text-muted-foreground">
                          {outage.startTime || "\u2014"}
                        </TableCell>
                        <TableCell className="hidden xl:table-cell text-sm text-muted-foreground">
                          {outage.estimatedRestore || "\u2014"}
                        </TableCell>
                        <TableCell className="hidden xl:table-cell text-sm text-muted-foreground">
                          {outage.affectedCustomers ?? 0}
                        </TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" data-testid={`button-outage-actions-${outage.id}`}>
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => openEdit(outage)} data-testid={`button-edit-outage-${outage.id}`}>
                                <Edit className="h-4 w-4 mr-2" />
                                Edit
                              </DropdownMenuItem>
                              {outage.status !== "resolved" && (
                                <DropdownMenuItem onClick={() => resolveMutation.mutate(outage.id)} data-testid={`button-resolve-outage-${outage.id}`}>
                                  <CheckCircle className="h-4 w-4 mr-2" />
                                  Resolve
                                </DropdownMenuItem>
                              )}
                              <DropdownMenuItem
                                className="text-destructive"
                                onClick={() => deleteMutation.mutate(outage.id)}
                                data-testid={`button-delete-outage-${outage.id}`}
                              >
                                <Trash2 className="h-4 w-4 mr-2" />
                                Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle data-testid="text-outage-dialog-title">
              {editingOutage ? "Edit Outage" : "Report Outage"}
            </DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="outageId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Outage ID</FormLabel>
                      <FormControl>
                        <Input placeholder="OUT-001" {...field} data-testid="input-outage-id" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Title</FormLabel>
                      <FormControl>
                        <Input placeholder="Outage title" {...field} data-testid="input-outage-title" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Describe the outage..." {...field} value={field.value || ""} data-testid="input-outage-description" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="affectedArea"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Affected Area</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. Zone A, Downtown" {...field} value={field.value || ""} data-testid="input-outage-affected-area" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="affectedCustomers"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Affected Customers</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          placeholder="0"
                          {...field}
                          value={field.value ?? 0}
                          onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                          data-testid="input-outage-affected-customers"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <FormField
                  control={form.control}
                  name="severity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Severity</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-outage-severity">
                            <SelectValue placeholder="Select severity" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="critical">Critical</SelectItem>
                          <SelectItem value="major">Major</SelectItem>
                          <SelectItem value="minor">Minor</SelectItem>
                          <SelectItem value="info">Info</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Type</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-outage-type">
                            <SelectValue placeholder="Select type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="unplanned">Unplanned</SelectItem>
                          <SelectItem value="planned">Planned</SelectItem>
                          <SelectItem value="maintenance">Maintenance</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Status</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-outage-status">
                            <SelectValue placeholder="Select status" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="ongoing">Ongoing</SelectItem>
                          <SelectItem value="investigating">Investigating</SelectItem>
                          <SelectItem value="resolved">Resolved</SelectItem>
                          <SelectItem value="scheduled">Scheduled</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <FormField
                  control={form.control}
                  name="startTime"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Start Time</FormLabel>
                      <FormControl>
                        <Input type="datetime-local" {...field} data-testid="input-outage-start-time" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="estimatedRestore"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Est. Restore</FormLabel>
                      <FormControl>
                        <Input type="datetime-local" {...field} value={field.value || ""} data-testid="input-outage-estimated-restore" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="endTime"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>End Time</FormLabel>
                      <FormControl>
                        <Input type="datetime-local" {...field} value={field.value || ""} data-testid="input-outage-end-time" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="rootCause"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Root Cause</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Root cause analysis..." {...field} value={field.value || ""} data-testid="input-outage-root-cause" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="resolution"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Resolution</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Resolution details..." {...field} value={field.value || ""} data-testid="input-outage-resolution" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="createdBy"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Created By</FormLabel>
                      <FormControl>
                        <Input placeholder="Reporter name" {...field} value={field.value || ""} data-testid="input-outage-created-by" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="notifiedCustomers"
                  render={({ field }) => (
                    <FormItem className="flex items-center gap-3 pt-8">
                      <FormControl>
                        <Checkbox
                          checked={field.value ?? false}
                          onCheckedChange={field.onChange}
                          data-testid="checkbox-outage-notified"
                        />
                      </FormControl>
                      <FormLabel className="!mt-0">Customers Notified</FormLabel>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setDialogOpen(false)} data-testid="button-cancel-outage">
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={createMutation.isPending || updateMutation.isPending}
                  data-testid="button-submit-outage"
                >
                  {(createMutation.isPending || updateMutation.isPending) ? "Saving..." : editingOutage ? "Update" : "Create"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
