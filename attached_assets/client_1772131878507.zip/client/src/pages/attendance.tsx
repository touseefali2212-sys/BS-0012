import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Plus,
  Search,
  MoreHorizontal,
  Edit,
  Trash2,
  UserCheck,
  Clock,
  Calendar,
  AlertCircle,
  XCircle,
  Download,
  MapPin,
  Timer,
  UserX,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertAttendanceSchema, type Attendance, type InsertAttendance, type Employee } from "@shared/schema";
import { z } from "zod";

const attendanceFormSchema = insertAttendanceSchema.extend({
  employeeId: z.coerce.number().min(1, "Employee is required"),
  date: z.string().min(1, "Date is required"),
  status: z.string().min(1, "Status is required"),
});

type AttendanceWithEmployee = Attendance & { employeeName?: string };

export default function AttendancePage() {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<Attendance | null>(null);

  const { data: attendanceRecords, isLoading } = useQuery<AttendanceWithEmployee[]>({
    queryKey: ["/api/attendance"],
  });

  const { data: employees } = useQuery<Employee[]>({
    queryKey: ["/api/employees"],
  });

  const form = useForm<InsertAttendance>({
    resolver: zodResolver(attendanceFormSchema),
    defaultValues: {
      employeeId: 0,
      date: "",
      checkIn: "",
      checkOut: "",
      status: "present",
      hoursWorked: "",
      overtime: "0",
      notes: "",
      location: "",
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertAttendance) => {
      const res = await apiRequest("POST", "/api/attendance", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/attendance"] });
      setDialogOpen(false);
      form.reset();
      toast({ title: "Attendance record created successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertAttendance> }) => {
      const res = await apiRequest("PATCH", `/api/attendance/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/attendance"] });
      setDialogOpen(false);
      setEditingRecord(null);
      form.reset();
      toast({ title: "Attendance record updated successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/attendance/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/attendance"] });
      toast({ title: "Attendance record deleted" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const openCreate = () => {
    setEditingRecord(null);
    form.reset({
      employeeId: 0,
      date: "",
      checkIn: "",
      checkOut: "",
      status: "present",
      hoursWorked: "",
      overtime: "0",
      notes: "",
      location: "",
    });
    setDialogOpen(true);
  };

  const openEdit = (record: Attendance) => {
    setEditingRecord(record);
    form.reset({
      employeeId: record.employeeId,
      date: record.date,
      checkIn: record.checkIn || "",
      checkOut: record.checkOut || "",
      status: record.status,
      hoursWorked: record.hoursWorked || "",
      overtime: record.overtime || "0",
      notes: record.notes || "",
      location: record.location || "",
    });
    setDialogOpen(true);
  };

  const onSubmit = (data: InsertAttendance) => {
    if (editingRecord) {
      updateMutation.mutate({ id: editingRecord.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleExport = () => {
    window.open("/api/export/attendance", "_blank");
  };

  const filtered = (attendanceRecords || []).filter((r) => {
    const empName = (r.employeeName || "").toLowerCase();
    const matchSearch =
      empName.includes(search.toLowerCase()) ||
      r.date.toLowerCase().includes(search.toLowerCase()) ||
      (r.notes || "").toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === "all" || r.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const statusConfig: Record<string, { icon: any; color: string }> = {
    present: { icon: UserCheck, color: "text-green-700 dark:text-green-300 bg-green-50 dark:bg-green-950" },
    absent: { icon: XCircle, color: "text-red-700 dark:text-red-300 bg-red-50 dark:bg-red-950" },
    late: { icon: Clock, color: "text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950" },
    half_day: { icon: AlertCircle, color: "text-orange-600 dark:text-orange-400 bg-orange-50 dark:bg-orange-950" },
    leave: { icon: Calendar, color: "text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950" },
  };

  const allRecords = attendanceRecords || [];
  const totalRecords = allRecords.length;
  const today = new Date().toISOString().split("T")[0];
  const todayRecords = allRecords.filter((r) => r.date === today);
  const presentToday = todayRecords.filter((r) => r.status === "present" || r.status === "late").length;
  const absentToday = todayRecords.filter((r) => r.status === "absent").length;
  const avgHours =
    allRecords.length > 0
      ? (
          allRecords.reduce((sum, r) => sum + parseFloat(r.hoursWorked || "0"), 0) / allRecords.length
        ).toFixed(1)
      : "0.0";

  return (
    <div className="p-6 space-y-6 max-w-[1400px] mx-auto">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight" data-testid="text-attendance-title">Attendance Tracking</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Monitor employee attendance and work hours</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <Button variant="outline" onClick={handleExport} data-testid="button-export-attendance">
            <Download className="h-4 w-4 mr-1" />
            Export CSV
          </Button>
          <Button onClick={openCreate} data-testid="button-add-attendance">
            <Plus className="h-4 w-4 mr-1" />
            Add Record
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <Card data-testid="card-total-records">
          <CardContent className="py-4">
            <div className="flex items-center justify-between gap-2">
              <div>
                <p className="text-sm text-muted-foreground">Total Records</p>
                <p className="text-2xl font-bold mt-1" data-testid="text-total-records">{totalRecords}</p>
              </div>
              <Calendar className="h-8 w-8 text-muted-foreground opacity-50" />
            </div>
          </CardContent>
        </Card>
        <Card data-testid="card-present-today">
          <CardContent className="py-4">
            <div className="flex items-center justify-between gap-2">
              <div>
                <p className="text-sm text-muted-foreground">Present Today</p>
                <p className="text-2xl font-bold mt-1 text-green-600 dark:text-green-400" data-testid="text-present-today">{presentToday}</p>
              </div>
              <UserCheck className="h-8 w-8 text-green-600 dark:text-green-400 opacity-50" />
            </div>
          </CardContent>
        </Card>
        <Card data-testid="card-absent-today">
          <CardContent className="py-4">
            <div className="flex items-center justify-between gap-2">
              <div>
                <p className="text-sm text-muted-foreground">Absent Today</p>
                <p className="text-2xl font-bold mt-1 text-red-600 dark:text-red-400" data-testid="text-absent-today">{absentToday}</p>
              </div>
              <UserX className="h-8 w-8 text-red-600 dark:text-red-400 opacity-50" />
            </div>
          </CardContent>
        </Card>
        <Card data-testid="card-avg-hours">
          <CardContent className="py-4">
            <div className="flex items-center justify-between gap-2">
              <div>
                <p className="text-sm text-muted-foreground">Average Hours</p>
                <p className="text-2xl font-bold mt-1 text-blue-600 dark:text-blue-400" data-testid="text-avg-hours">{avgHours}h</p>
              </div>
              <Timer className="h-8 w-8 text-blue-600 dark:text-blue-400 opacity-50" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
            <div className="relative flex-1 w-full sm:max-w-xs">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search by employee, date..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9"
                data-testid="input-search-attendance"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[160px]" data-testid="select-attendance-status-filter">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="present">Present</SelectItem>
                <SelectItem value="absent">Absent</SelectItem>
                <SelectItem value="late">Late</SelectItem>
                <SelectItem value="half_day">Half Day</SelectItem>
                <SelectItem value="leave">Leave</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="p-5 space-y-3">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-14 w-full" />
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
              <UserCheck className="h-12 w-12 mb-3 opacity-30" />
              <p className="font-medium">No attendance records found</p>
              <p className="text-sm mt-1">Add a new record to get started</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Employee Name</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead className="hidden md:table-cell">Check In</TableHead>
                    <TableHead className="hidden md:table-cell">Check Out</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="hidden lg:table-cell">Hours Worked</TableHead>
                    <TableHead className="hidden lg:table-cell">Overtime</TableHead>
                    <TableHead className="hidden xl:table-cell">Notes</TableHead>
                    <TableHead className="w-10"></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((record) => {
                    const config = statusConfig[record.status] || statusConfig.present;
                    const StatusIcon = config.icon;
                    return (
                      <TableRow key={record.id} data-testid={`row-attendance-${record.id}`}>
                        <TableCell>
                          <div className="font-medium max-w-[200px] truncate" data-testid={`text-employee-name-${record.id}`}>
                            {record.employeeName || `Employee #${record.employeeId}`}
                          </div>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground" data-testid={`text-date-${record.id}`}>
                          {record.date}
                        </TableCell>
                        <TableCell className="hidden md:table-cell text-sm text-muted-foreground" data-testid={`text-checkin-${record.id}`}>
                          {record.checkIn || "\u2014"}
                        </TableCell>
                        <TableCell className="hidden md:table-cell text-sm text-muted-foreground" data-testid={`text-checkout-${record.id}`}>
                          {record.checkOut || "\u2014"}
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary" className={`no-default-active-elevate text-[10px] capitalize ${config.color}`} data-testid={`badge-status-${record.id}`}>
                            <StatusIcon className="h-3 w-3 mr-1" />
                            {record.status.replace("_", " ")}
                          </Badge>
                        </TableCell>
                        <TableCell className="hidden lg:table-cell text-sm text-muted-foreground" data-testid={`text-hours-${record.id}`}>
                          {record.hoursWorked ? `${record.hoursWorked}h` : "\u2014"}
                        </TableCell>
                        <TableCell className="hidden lg:table-cell text-sm text-muted-foreground" data-testid={`text-overtime-${record.id}`}>
                          {record.overtime && parseFloat(record.overtime) > 0 ? `${record.overtime}h` : "\u2014"}
                        </TableCell>
                        <TableCell className="hidden xl:table-cell text-sm text-muted-foreground">
                          <div className="max-w-[150px] truncate">{record.notes || "\u2014"}</div>
                        </TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" data-testid={`button-attendance-actions-${record.id}`}>
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => openEdit(record)} data-testid={`button-edit-attendance-${record.id}`}>
                                <Edit className="h-4 w-4 mr-2" />
                                Edit
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                className="text-destructive"
                                onClick={() => deleteMutation.mutate(record.id)}
                                data-testid={`button-delete-attendance-${record.id}`}
                              >
                                <Trash2 className="h-4 w-4 mr-2" />
                                Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingRecord ? "Edit Attendance Record" : "Add Attendance Record"}</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="employeeId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Employee</FormLabel>
                    <Select
                      onValueChange={(v) => field.onChange(parseInt(v))}
                      value={field.value?.toString() || ""}
                    >
                      <FormControl>
                        <SelectTrigger data-testid="select-attendance-employee">
                          <SelectValue placeholder="Select employee" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {(employees || []).map((e) => (
                          <SelectItem key={e.id} value={e.id.toString()}>
                            {e.fullName}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="date"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Date</FormLabel>
                      <FormControl>
                        <Input type="date" data-testid="input-attendance-date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Status</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value || "present"}>
                        <FormControl>
                          <SelectTrigger data-testid="select-attendance-status">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="present">Present</SelectItem>
                          <SelectItem value="absent">Absent</SelectItem>
                          <SelectItem value="late">Late</SelectItem>
                          <SelectItem value="half_day">Half Day</SelectItem>
                          <SelectItem value="leave">Leave</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="checkIn"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Check In</FormLabel>
                      <FormControl>
                        <Input type="time" data-testid="input-attendance-checkin" {...field} value={field.value || ""} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="checkOut"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Check Out</FormLabel>
                      <FormControl>
                        <Input type="time" data-testid="input-attendance-checkout" {...field} value={field.value || ""} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="hoursWorked"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Hours Worked</FormLabel>
                      <FormControl>
                        <Input type="number" step="0.5" placeholder="8.0" data-testid="input-attendance-hours" {...field} value={field.value || ""} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="overtime"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Overtime</FormLabel>
                      <FormControl>
                        <Input type="number" step="0.5" placeholder="0" data-testid="input-attendance-overtime" {...field} value={field.value || ""} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={form.control}
                name="location"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Location</FormLabel>
                    <FormControl>
                      <Input placeholder="Office, Remote, Field..." data-testid="input-attendance-location" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Additional notes..." data-testid="input-attendance-notes" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="button" variant="secondary" onClick={() => setDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending} data-testid="button-save-attendance">
                  {createMutation.isPending || updateMutation.isPending ? "Saving..." : editingRecord ? "Update" : "Create"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
