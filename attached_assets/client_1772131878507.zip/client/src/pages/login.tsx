import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { Globe, Eye, EyeOff, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { loginSchema, type LoginData } from "@shared/schema";

export default function LoginPage({ onLogin }: { onLogin: () => void }) {
  const { toast } = useToast();
  const [showPassword, setShowPassword] = useState(false);

  const form = useForm<LoginData>({
    resolver: zodResolver(loginSchema),
    defaultValues: { username: "", password: "" },
  });

  const loginMutation = useMutation({
    mutationFn: async (data: LoginData) => {
      const res = await apiRequest("POST", "/api/auth/login", data);
      return res.json();
    },
    onSuccess: () => {
      onLogin();
    },
    onError: (error: Error) => {
      toast({
        title: "Login Failed",
        description: error.message.includes("401")
          ? "Invalid username or password"
          : "Something went wrong. Please try again.",
        variant: "destructive",
      });
    },
  });

  return (
    <div className="min-h-screen flex">
      <div className="hidden lg:flex lg:w-[55%] relative overflow-hidden gradient-primary">
        <div className="absolute inset-0" style={{
          background: `radial-gradient(circle at 30% 50%, rgba(0,179,255,0.3) 0%, transparent 60%),
                        radial-gradient(circle at 70% 20%, rgba(124,58,237,0.2) 0%, transparent 50%),
                        radial-gradient(circle at 50% 80%, rgba(0,87,255,0.15) 0%, transparent 60%)`
        }} />
        <div className="absolute inset-0" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.03'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }} />
        <div className="relative z-10 flex flex-col justify-center px-16 text-white">
          <div className="flex items-center gap-4 mb-8">
            <div className="flex items-center justify-center w-14 h-14 rounded-2xl bg-white/15 backdrop-blur-sm border border-white/20 shadow-[0_4px_20px_rgba(0,0,0,0.15)]">
              <Globe className="h-7 w-7" />
            </div>
            <div>
              <h1 className="text-3xl font-bold tracking-tight">NetSphere</h1>
              <p className="text-sm font-medium text-blue-100/80 tracking-wide">Enterprise ISP Platform</p>
            </div>
          </div>
          <h2 className="text-4xl font-bold leading-tight mb-4 max-w-md">
            Manage Your ISP <br />
            <span className="text-blue-200">Operations Smarter</span>
          </h2>
          <p className="text-base text-blue-100/70 max-w-lg leading-relaxed mb-10">
            Complete billing, customer management, and network operations platform built for Pakistan's ISP industry.
          </p>
          <div className="flex items-center gap-8">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center">
                <Shield className="h-4 w-4 text-blue-200" />
              </div>
              <span className="text-sm font-medium text-blue-100/80">Enterprise Security</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center">
                <Globe className="h-4 w-4 text-blue-200" />
              </div>
              <span className="text-sm font-medium text-blue-100/80">Multi-Branch</span>
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 flex items-center justify-center bg-background p-6">
        <div className="w-full max-w-[400px] page-fade-in">
          <div className="flex flex-col items-center mb-8 lg:hidden">
            <div className="flex items-center justify-center w-14 h-14 rounded-2xl gradient-primary mb-4 shadow-[0_4px_16px_rgba(0,87,255,0.3)]">
              <Globe className="h-7 w-7 text-white" />
            </div>
            <h1 className="text-2xl font-bold tracking-tight" data-testid="text-login-title">NetSphere</h1>
            <p className="text-sm text-muted-foreground mt-1">Enterprise ISP Management</p>
          </div>
          <div className="hidden lg:block mb-8">
            <h2 className="text-2xl font-bold tracking-tight">Welcome back</h2>
            <p className="text-sm text-muted-foreground mt-1">Sign in to access your dashboard</p>
          </div>
          <div className="bg-card rounded-2xl border border-card-border p-6" style={{ boxShadow: 'var(--shadow-lg)' }}>
            <Form {...form}>
              <form onSubmit={form.handleSubmit((data) => loginMutation.mutate(data))} className="space-y-5">
                <FormField
                  control={form.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Username</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="Enter your username"
                          data-testid="input-username"
                          className="h-11 rounded-xl input-enterprise"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Password</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Input
                            type={showPassword ? "text" : "password"}
                            placeholder="Enter your password"
                            data-testid="input-password"
                            className="h-11 rounded-xl input-enterprise pr-10"
                            {...field}
                          />
                          <button
                            type="button"
                            onClick={() => setShowPassword(!showPassword)}
                            className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                            data-testid="button-toggle-password"
                          >
                            {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                          </button>
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button
                  type="submit"
                  className="w-full h-11 rounded-xl btn-gradient text-sm font-semibold"
                  disabled={loginMutation.isPending}
                  data-testid="button-login"
                >
                  {loginMutation.isPending ? "Signing in..." : "Sign In"}
                </Button>
              </form>
            </Form>
          </div>
          <div className="mt-5 p-3.5 rounded-xl bg-muted/60 border border-border/50">
            <p className="text-xs text-muted-foreground text-center">
              Demo credentials: <span className="font-semibold text-foreground">admin</span> / <span className="font-semibold text-foreground">admin123</span>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
