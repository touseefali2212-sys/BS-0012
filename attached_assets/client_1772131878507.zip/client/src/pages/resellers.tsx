import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Plus,
  Search,
  MoreHorizontal,
  Edit,
  Trash2,
  Handshake,
  Phone,
  Mail,
  MapPin,
  Users,
  Percent,
  Shield,
  Network,
  Store,
  Tag,
  Wallet,
  ArrowUpCircle,
  ArrowDownCircle,
  BarChart3,
  CreditCard,
  RefreshCw,
  FileText,
  DollarSign,
  TrendingUp,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useTab } from "@/hooks/use-tab";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  insertResellerSchema,
  type Reseller,
  type InsertReseller,
  type Vendor,
  type ResellerWalletTransaction,
} from "@shared/schema";
import { z } from "zod";

const formatPKR = (value: string | number | null | undefined) => {
  const num = parseFloat(String(value || "0"));
  return new Intl.NumberFormat("en-PK", {
    style: "currency",
    currency: "PKR",
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(num);
};

const resellerFormSchema = insertResellerSchema.extend({
  name: z.string().min(2, "Name must be at least 2 characters"),
  phone: z.string().min(10, "Phone number is required"),
});

const resellerTypes = [
  {
    title: "Authorized Dealer",
    icon: Shield,
    description:
      "Official partners authorized to sell and distribute services in designated territories. They receive full brand support and priority commission rates.",
    features: ["Territory exclusivity", "Brand support", "Priority commission", "Direct support line"],
  },
  {
    title: "Sub-Reseller",
    icon: Network,
    description:
      "Partners operating under an authorized dealer, extending the sales network to smaller regions or communities.",
    features: ["Flexible territory", "Dealer support", "Standard commission", "Training provided"],
  },
  {
    title: "Franchise",
    icon: Store,
    description:
      "Independent operators using the brand name and business model under a franchise agreement with fixed operational guidelines.",
    features: ["Brand licensing", "Operational guidelines", "Fixed commission", "Marketing support"],
  },
  {
    title: "White Label",
    icon: Tag,
    description:
      "Partners who rebrand and sell services under their own company name, ideal for established businesses wanting to expand offerings.",
    features: ["Custom branding", "Own pricing", "Bulk rates", "API access"],
  },
];

const statusColors: Record<string, string> = {
  active: "text-green-700 dark:text-green-300 bg-green-50 dark:bg-green-950",
  inactive: "text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950",
};

export default function ResellersPage() {
  const { toast } = useToast();
  const [tab, changeTab] = useTab("list");
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [editingReseller, setEditingReseller] = useState<Reseller | null>(null);
  const [rechargeDialogOpen, setRechargeDialogOpen] = useState(false);
  const [rechargeReseller, setRechargeReseller] = useState<Reseller | null>(null);
  const [rechargeAmount, setRechargeAmount] = useState("");
  const [rechargeReference, setRechargeReference] = useState("");
  const [selectedWalletResellerId, setSelectedWalletResellerId] = useState<string>("");

  const { data: resellers, isLoading } = useQuery<Reseller[]>({
    queryKey: ["/api/resellers"],
  });

  const { data: vendors } = useQuery<Vendor[]>({
    queryKey: ["/api/vendors"],
  });

  const { data: walletTransactions, isLoading: isLoadingTransactions } =
    useQuery<ResellerWalletTransaction[]>({
      queryKey: ["/api/reseller-wallet-transactions", selectedWalletResellerId],
      enabled: !!selectedWalletResellerId,
    });

  const editForm = useForm<InsertReseller>({
    resolver: zodResolver(resellerFormSchema),
    defaultValues: {
      name: "",
      contactName: "",
      phone: "",
      email: "",
      address: "",
      area: "",
      vendorId: undefined,
      commissionRate: "10",
      walletBalance: "0",
      totalCustomers: 0,
      status: "active",
    },
  });

  const addForm = useForm<InsertReseller>({
    resolver: zodResolver(resellerFormSchema),
    defaultValues: {
      name: "",
      contactName: "",
      phone: "",
      email: "",
      address: "",
      area: "",
      vendorId: undefined,
      commissionRate: "10",
      walletBalance: "0",
      totalCustomers: 0,
      status: "active",
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertReseller) => {
      const res = await apiRequest("POST", "/api/resellers", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/resellers"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      addForm.reset();
      toast({ title: "Reseller created successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertReseller> }) => {
      const res = await apiRequest("PATCH", `/api/resellers/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/resellers"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      setEditDialogOpen(false);
      setEditingReseller(null);
      editForm.reset();
      toast({ title: "Reseller updated successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/resellers/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/resellers"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({ title: "Reseller deleted successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const rechargeMutation = useMutation({
    mutationFn: async (data: { resellerId: number; amount: number; reference: string }) => {
      const res = await apiRequest("POST", "/api/reseller-wallet/recharge", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/resellers"] });
      queryClient.invalidateQueries({
        queryKey: ["/api/reseller-wallet-transactions", selectedWalletResellerId],
      });
      setRechargeDialogOpen(false);
      setRechargeReseller(null);
      setRechargeAmount("");
      setRechargeReference("");
      toast({ title: "Wallet recharged successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const openEdit = (reseller: Reseller) => {
    setEditingReseller(reseller);
    editForm.reset({
      name: reseller.name,
      contactName: reseller.contactName || "",
      phone: reseller.phone,
      email: reseller.email || "",
      address: reseller.address || "",
      area: reseller.area || "",
      vendorId: reseller.vendorId ?? undefined,
      commissionRate: reseller.commissionRate || "10",
      walletBalance: reseller.walletBalance || "0",
      totalCustomers: reseller.totalCustomers || 0,
      status: reseller.status,
    });
    setEditDialogOpen(true);
  };

  const onEditSubmit = (data: InsertReseller) => {
    if (editingReseller) {
      updateMutation.mutate({ id: editingReseller.id, data });
    }
  };

  const onAddSubmit = (data: InsertReseller) => {
    createMutation.mutate(data);
  };

  const handleRecharge = () => {
    if (!rechargeReseller || !rechargeAmount) return;
    rechargeMutation.mutate({
      resellerId: rechargeReseller.id,
      amount: parseFloat(rechargeAmount),
      reference: rechargeReference,
    });
  };

  const filtered = (resellers || []).filter((r) => {
    const matchSearch =
      r.name.toLowerCase().includes(search.toLowerCase()) ||
      r.phone.includes(search) ||
      (r.contactName || "").toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === "all" || r.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const getVendorName = (vendorId: number | null) => {
    if (!vendorId || !vendors) return "N/A";
    const vendor = vendors.find((v) => v.id === vendorId);
    return vendor ? vendor.name : "N/A";
  };

  return (
    <div className="p-6 space-y-6 max-w-[1400px] mx-auto">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold tracking-tight" data-testid="text-resellers-title">
            Resellers
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            Manage reseller and partner relationships
          </p>
        </div>
        {tab === "list" && (
          <Button onClick={() => changeTab("add")} data-testid="button-add-reseller">
            <Plus className="h-4 w-4 mr-1" />
            Add Reseller
          </Button>
        )}
      </div>

      {tab === "types" && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {resellerTypes.map((type) => (
              <Card
                key={type.title}
                data-testid={`card-reseller-type-${type.title.toLowerCase().replace(/\s+/g, "-")}`}
              >
                <CardHeader>
                  <div className="flex items-center gap-3 flex-wrap">
                    <div className="p-2 rounded-md bg-muted">
                      <type.icon className="h-5 w-5 text-muted-foreground" />
                    </div>
                    <div>
                      <CardTitle className="text-base">{type.title}</CardTitle>
                    </div>
                  </div>
                  <CardDescription className="mt-2">{type.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-1.5">
                    {type.features.map((feature) => (
                      <li
                        key={feature}
                        className="text-sm text-muted-foreground flex items-center gap-2"
                      >
                        <div className="h-1.5 w-1.5 rounded-full bg-muted-foreground/50" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {tab === "add" && (
        <Card>
          <CardHeader>
            <CardTitle>Add New Reseller</CardTitle>
            <CardDescription>Fill in the details to register a new reseller partner</CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...addForm}>
              <form onSubmit={addForm.handleSubmit(onAddSubmit)} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={addForm.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Name</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Reseller/Partner name"
                            data-testid="input-add-reseller-name"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={addForm.control}
                    name="contactName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Contact Name</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Contact person name"
                            data-testid="input-add-reseller-contact-name"
                            {...field}
                            value={field.value || ""}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={addForm.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Phone</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="03XX-XXXXXXX"
                            data-testid="input-add-reseller-phone"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={addForm.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="email@example.com"
                            data-testid="input-add-reseller-email"
                            {...field}
                            value={field.value || ""}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <FormField
                  control={addForm.control}
                  name="address"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Address</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Full address"
                          data-testid="input-add-reseller-address"
                          {...field}
                          value={field.value || ""}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={addForm.control}
                    name="area"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Area</FormLabel>
                        <FormControl>
                          <Input
                            placeholder="Service area"
                            data-testid="input-add-reseller-area"
                            {...field}
                            value={field.value || ""}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={addForm.control}
                    name="vendorId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Vendor</FormLabel>
                        <Select
                          onValueChange={(val) => field.onChange(parseInt(val))}
                          value={field.value ? String(field.value) : ""}
                        >
                          <FormControl>
                            <SelectTrigger data-testid="select-add-reseller-vendor">
                              <SelectValue placeholder="Select vendor" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {(vendors || []).map((v) => (
                              <SelectItem key={v.id} value={String(v.id)}>
                                {v.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <FormField
                    control={addForm.control}
                    name="commissionRate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Commission Rate (%)</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            step="0.01"
                            placeholder="10.00"
                            data-testid="input-add-reseller-commission-rate"
                            {...field}
                            value={field.value || "10"}
                            onChange={(e) => field.onChange(e.target.value)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={addForm.control}
                    name="walletBalance"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Initial Wallet Balance</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            step="0.01"
                            placeholder="0.00"
                            data-testid="input-add-reseller-wallet-balance"
                            {...field}
                            value={field.value || "0"}
                            onChange={(e) => field.onChange(e.target.value)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={addForm.control}
                    name="totalCustomers"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Total Customers</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            placeholder="0"
                            data-testid="input-add-reseller-total-customers"
                            {...field}
                            value={field.value ?? 0}
                            onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <FormField
                  control={addForm.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Status</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value || "active"}>
                        <FormControl>
                          <SelectTrigger data-testid="select-add-reseller-status">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="active">Active</SelectItem>
                          <SelectItem value="inactive">Inactive</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="flex justify-end gap-3 pt-2 flex-wrap">
                  <Button
                    type="button"
                    variant="secondary"
                    onClick={() => addForm.reset()}
                    data-testid="button-reset-add-form"
                  >
                    Reset
                  </Button>
                  <Button
                    type="submit"
                    disabled={createMutation.isPending}
                    data-testid="button-submit-add-reseller"
                  >
                    {createMutation.isPending ? "Creating..." : "Create Reseller"}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      )}

      {tab === "list" && (
        <Card>
          <CardHeader className="pb-3">
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 flex-wrap">
              <div className="relative flex-1 w-full sm:max-w-xs">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search by name, contact or phone..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  className="pl-9"
                  data-testid="input-search-resellers"
                />
              </div>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-[140px]" data-testid="select-status-filter">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            {isLoading ? (
              <div className="p-5 space-y-3">
                {[1, 2, 3].map((i) => (
                  <Skeleton key={i} className="h-14 w-full" />
                ))}
              </div>
            ) : filtered.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                <Handshake className="h-12 w-12 mb-3 opacity-30" />
                <p className="font-medium">No resellers found</p>
                <p className="text-sm mt-1">Add your first reseller to get started</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead className="hidden md:table-cell">Contact</TableHead>
                      <TableHead>Phone</TableHead>
                      <TableHead className="hidden md:table-cell">Area</TableHead>
                      <TableHead className="hidden lg:table-cell">Vendor</TableHead>
                      <TableHead className="hidden lg:table-cell">Commission %</TableHead>
                      <TableHead className="hidden lg:table-cell">Wallet Balance</TableHead>
                      <TableHead className="hidden lg:table-cell">Customers</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="w-10"></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filtered.map((reseller) => (
                      <TableRow key={reseller.id} data-testid={`row-reseller-${reseller.id}`}>
                        <TableCell>
                          <div className="font-medium">{reseller.name}</div>
                        </TableCell>
                        <TableCell className="hidden md:table-cell">
                          <span className="text-sm text-muted-foreground">
                            {reseller.contactName || "N/A"}
                          </span>
                        </TableCell>
                        <TableCell>
                          <span className="text-xs flex items-center gap-1">
                            <Phone className="h-3 w-3 text-muted-foreground" />
                            {reseller.phone}
                          </span>
                        </TableCell>
                        <TableCell className="hidden md:table-cell">
                          <span className="text-xs flex items-center gap-1">
                            <MapPin className="h-3 w-3 text-muted-foreground" />
                            {reseller.area || "N/A"}
                          </span>
                        </TableCell>
                        <TableCell className="hidden lg:table-cell">
                          <span className="text-sm text-muted-foreground">
                            {getVendorName(reseller.vendorId)}
                          </span>
                        </TableCell>
                        <TableCell className="hidden lg:table-cell">
                          <span className="text-sm flex items-center gap-1">
                            <Percent className="h-3 w-3 text-muted-foreground" />
                            {reseller.commissionRate || "10"}
                          </span>
                        </TableCell>
                        <TableCell className="hidden lg:table-cell">
                          <span className="text-sm font-medium" data-testid={`text-wallet-${reseller.id}`}>
                            {formatPKR(reseller.walletBalance)}
                          </span>
                        </TableCell>
                        <TableCell className="hidden lg:table-cell">
                          <span className="text-sm flex items-center gap-1">
                            <Users className="h-3 w-3 text-muted-foreground" />
                            {reseller.totalCustomers || 0}
                          </span>
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant="secondary"
                            className={`no-default-active-elevate text-[10px] capitalize ${statusColors[reseller.status] || ""}`}
                          >
                            {reseller.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                data-testid={`button-actions-${reseller.id}`}
                              >
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem
                                onClick={() => openEdit(reseller)}
                                data-testid={`button-edit-${reseller.id}`}
                              >
                                <Edit className="h-4 w-4 mr-2" />
                                Edit
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={() => deleteMutation.mutate(reseller.id)}
                                className="text-destructive"
                                data-testid={`button-delete-${reseller.id}`}
                              >
                                <Trash2 className="h-4 w-4 mr-2" />
                                Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {tab === "wallet" && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {isLoading ? (
              [1, 2, 3].map((i) => <Skeleton key={i} className="h-32 w-full" />)
            ) : (resellers || []).length === 0 ? (
              <div className="col-span-full flex flex-col items-center justify-center py-12 text-muted-foreground">
                <Wallet className="h-12 w-12 mb-3 opacity-30" />
                <p className="font-medium">No resellers found</p>
              </div>
            ) : (
              (resellers || []).map((reseller) => (
                <Card key={reseller.id} data-testid={`card-wallet-${reseller.id}`}>
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between gap-2 flex-wrap">
                      <CardTitle className="text-sm font-medium">{reseller.name}</CardTitle>
                      <Badge
                        variant="secondary"
                        className={`no-default-active-elevate text-[10px] capitalize ${statusColors[reseller.status] || ""}`}
                      >
                        {reseller.status}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between gap-2 flex-wrap">
                      <div>
                        <p className="text-xs text-muted-foreground">Wallet Balance</p>
                        <p
                          className="text-lg font-bold"
                          data-testid={`text-wallet-balance-${reseller.id}`}
                        >
                          {formatPKR(reseller.walletBalance)}
                        </p>
                      </div>
                      <Button
                        size="sm"
                        onClick={() => {
                          setRechargeReseller(reseller);
                          setRechargeAmount("");
                          setRechargeReference("");
                          setRechargeDialogOpen(true);
                        }}
                        data-testid={`button-recharge-${reseller.id}`}
                      >
                        <CreditCard className="h-4 w-4 mr-1" />
                        Recharge
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>

          <Card>
            <CardHeader>
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 flex-wrap">
                <CardTitle className="text-base">Transaction History</CardTitle>
                <Select
                  value={selectedWalletResellerId}
                  onValueChange={setSelectedWalletResellerId}
                >
                  <SelectTrigger className="w-[220px]" data-testid="select-wallet-reseller">
                    <SelectValue placeholder="Select reseller" />
                  </SelectTrigger>
                  <SelectContent>
                    {(resellers || []).map((r) => (
                      <SelectItem key={r.id} value={String(r.id)}>
                        {r.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              {!selectedWalletResellerId ? (
                <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                  <FileText className="h-12 w-12 mb-3 opacity-30" />
                  <p className="font-medium">Select a reseller to view transactions</p>
                </div>
              ) : isLoadingTransactions ? (
                <div className="p-5 space-y-3">
                  {[1, 2, 3].map((i) => (
                    <Skeleton key={i} className="h-10 w-full" />
                  ))}
                </div>
              ) : !walletTransactions || walletTransactions.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                  <FileText className="h-12 w-12 mb-3 opacity-30" />
                  <p className="font-medium">No transactions found</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Date</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Balance After</TableHead>
                        <TableHead className="hidden md:table-cell">Reference</TableHead>
                        <TableHead className="hidden md:table-cell">Description</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {walletTransactions.map((txn) => (
                        <TableRow key={txn.id} data-testid={`row-transaction-${txn.id}`}>
                          <TableCell className="text-sm">
                            {txn.createdAt
                              ? new Date(txn.createdAt).toLocaleDateString()
                              : "N/A"}
                          </TableCell>
                          <TableCell>
                            <Badge
                              variant="secondary"
                              className={`no-default-active-elevate text-[10px] capitalize ${
                                txn.type === "credit"
                                  ? "text-green-700 dark:text-green-300 bg-green-50 dark:bg-green-950"
                                  : "text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950"
                              }`}
                            >
                              {txn.type === "credit" ? (
                                <ArrowUpCircle className="h-3 w-3 mr-1" />
                              ) : (
                                <ArrowDownCircle className="h-3 w-3 mr-1" />
                              )}
                              {txn.type}
                            </Badge>
                          </TableCell>
                          <TableCell className="font-medium">{formatPKR(txn.amount)}</TableCell>
                          <TableCell>{formatPKR(txn.balanceAfter)}</TableCell>
                          <TableCell className="hidden md:table-cell text-sm text-muted-foreground">
                            {txn.reference || "N/A"}
                          </TableCell>
                          <TableCell className="hidden md:table-cell text-sm text-muted-foreground">
                            {txn.description || "N/A"}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {tab === "commission" && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {isLoading ? (
              [1, 2, 3].map((i) => <Skeleton key={i} className="h-36 w-full" />)
            ) : (resellers || []).length === 0 ? (
              <div className="col-span-full flex flex-col items-center justify-center py-12 text-muted-foreground">
                <BarChart3 className="h-12 w-12 mb-3 opacity-30" />
                <p className="font-medium">No resellers found</p>
              </div>
            ) : (
              (resellers || []).map((reseller) => {
                const rate = parseFloat(reseller.commissionRate || "10");
                const customers = reseller.totalCustomers || 0;
                const estimatedCommission = customers * rate * 10;
                return (
                  <Card key={reseller.id} data-testid={`card-commission-${reseller.id}`}>
                    <CardHeader className="pb-2">
                      <div className="flex items-center justify-between gap-2 flex-wrap">
                        <CardTitle className="text-sm font-medium">{reseller.name}</CardTitle>
                        <Badge
                          variant="secondary"
                          className={`no-default-active-elevate text-[10px] capitalize ${statusColors[reseller.status] || ""}`}
                        >
                          {reseller.status}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-2">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs text-muted-foreground flex items-center gap-1">
                          <Percent className="h-3 w-3" />
                          Commission Rate
                        </span>
                        <span className="text-sm font-medium">{rate}%</span>
                      </div>
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs text-muted-foreground flex items-center gap-1">
                          <Users className="h-3 w-3" />
                          Customers
                        </span>
                        <span className="text-sm font-medium">{customers}</span>
                      </div>
                      <div className="flex items-center justify-between gap-2 pt-1 border-t">
                        <span className="text-xs text-muted-foreground flex items-center gap-1">
                          <TrendingUp className="h-3 w-3" />
                          Est. Commission
                        </span>
                        <span className="text-sm font-bold" data-testid={`text-est-commission-${reseller.id}`}>
                          {formatPKR(estimatedCommission)}
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                );
              })
            )}
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Commission Overview</CardTitle>
              <CardDescription>Summary of reseller commission calculations</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              {isLoading ? (
                <div className="p-5 space-y-3">
                  {[1, 2, 3].map((i) => (
                    <Skeleton key={i} className="h-10 w-full" />
                  ))}
                </div>
              ) : (resellers || []).length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                  <BarChart3 className="h-12 w-12 mb-3 opacity-30" />
                  <p className="font-medium">No resellers found</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Reseller</TableHead>
                        <TableHead>Area</TableHead>
                        <TableHead>Commission Rate</TableHead>
                        <TableHead>Total Customers</TableHead>
                        <TableHead>Wallet Balance</TableHead>
                        <TableHead>Est. Commission</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {(resellers || []).map((reseller) => {
                        const rate = parseFloat(reseller.commissionRate || "10");
                        const customers = reseller.totalCustomers || 0;
                        const estimatedCommission = customers * rate * 10;
                        return (
                          <TableRow
                            key={reseller.id}
                            data-testid={`row-commission-${reseller.id}`}
                          >
                            <TableCell className="font-medium">{reseller.name}</TableCell>
                            <TableCell className="text-sm text-muted-foreground">
                              {reseller.area || "N/A"}
                            </TableCell>
                            <TableCell>
                              <span className="flex items-center gap-1">
                                <Percent className="h-3 w-3 text-muted-foreground" />
                                {rate}%
                              </span>
                            </TableCell>
                            <TableCell>{customers}</TableCell>
                            <TableCell>{formatPKR(reseller.walletBalance)}</TableCell>
                            <TableCell className="font-medium">
                              {formatPKR(estimatedCommission)}
                            </TableCell>
                            <TableCell>
                              <Badge
                                variant="secondary"
                                className={`no-default-active-elevate text-[10px] capitalize ${statusColors[reseller.status] || ""}`}
                              >
                                {reseller.status}
                              </Badge>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Reseller</DialogTitle>
          </DialogHeader>
          <Form {...editForm}>
            <form onSubmit={editForm.handleSubmit(onEditSubmit)} className="space-y-4">
              <FormField
                control={editForm.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Name</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="Reseller name"
                        data-testid="input-edit-reseller-name"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={editForm.control}
                name="contactName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Contact Name</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="Contact person"
                        data-testid="input-edit-reseller-contact-name"
                        {...field}
                        value={field.value || ""}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={editForm.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Phone</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="03XX-XXXXXXX"
                          data-testid="input-edit-reseller-phone"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={editForm.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="email@example.com"
                          data-testid="input-edit-reseller-email"
                          {...field}
                          value={field.value || ""}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={editForm.control}
                name="address"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Address</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Full address"
                        data-testid="input-edit-reseller-address"
                        {...field}
                        value={field.value || ""}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={editForm.control}
                  name="area"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Area</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="Service area"
                          data-testid="input-edit-reseller-area"
                          {...field}
                          value={field.value || ""}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={editForm.control}
                  name="vendorId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Vendor</FormLabel>
                      <Select
                        onValueChange={(val) => field.onChange(parseInt(val))}
                        value={field.value ? String(field.value) : ""}
                      >
                        <FormControl>
                          <SelectTrigger data-testid="select-edit-reseller-vendor">
                            <SelectValue placeholder="Select vendor" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {(vendors || []).map((v) => (
                            <SelectItem key={v.id} value={String(v.id)}>
                              {v.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={editForm.control}
                  name="commissionRate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Commission Rate (%)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          step="0.01"
                          placeholder="10.00"
                          data-testid="input-edit-reseller-commission-rate"
                          {...field}
                          value={field.value || "10"}
                          onChange={(e) => field.onChange(e.target.value)}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={editForm.control}
                  name="totalCustomers"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Total Customers</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          placeholder="0"
                          data-testid="input-edit-reseller-total-customers"
                          {...field}
                          value={field.value ?? 0}
                          onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={editForm.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value || "active"}>
                      <FormControl>
                        <SelectTrigger data-testid="select-edit-reseller-status">
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="inactive">Inactive</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter className="gap-2">
                <Button
                  type="button"
                  variant="secondary"
                  onClick={() => setEditDialogOpen(false)}
                  data-testid="button-cancel-edit"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={updateMutation.isPending}
                  data-testid="button-submit-edit-reseller"
                >
                  {updateMutation.isPending ? "Saving..." : "Save Changes"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <Dialog open={rechargeDialogOpen} onOpenChange={setRechargeDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              Recharge Wallet {rechargeReseller ? `- ${rechargeReseller.name}` : ""}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {rechargeReseller && (
              <div className="text-sm text-muted-foreground">
                Current Balance:{" "}
                <span className="font-medium text-foreground">
                  {formatPKR(rechargeReseller.walletBalance)}
                </span>
              </div>
            )}
            <div className="space-y-2">
              <label className="text-sm font-medium">Amount</label>
              <Input
                type="number"
                step="0.01"
                placeholder="Enter amount"
                value={rechargeAmount}
                onChange={(e) => setRechargeAmount(e.target.value)}
                data-testid="input-recharge-amount"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Reference</label>
              <Input
                placeholder="Payment reference (optional)"
                value={rechargeReference}
                onChange={(e) => setRechargeReference(e.target.value)}
                data-testid="input-recharge-reference"
              />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button
              variant="secondary"
              onClick={() => setRechargeDialogOpen(false)}
              data-testid="button-cancel-recharge"
            >
              Cancel
            </Button>
            <Button
              onClick={handleRecharge}
              disabled={!rechargeAmount || rechargeMutation.isPending}
              data-testid="button-submit-recharge"
            >
              {rechargeMutation.isPending ? "Processing..." : "Recharge"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
