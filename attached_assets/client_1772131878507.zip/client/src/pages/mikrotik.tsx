import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Plus,
  Search,
  MoreHorizontal,
  Edit,
  Trash2,
  Download,
  Server,
  Wifi,
  WifiOff,
  AlertTriangle,
  Users,
  Cpu,
  HardDrive,
  Router,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  insertNetworkDeviceSchema,
  type NetworkDevice,
  type InsertNetworkDevice,
  insertPppoeUserSchema,
  type PppoeUser,
  type InsertPppoeUser,
  type Customer,
} from "@shared/schema";
import { z } from "zod";

const deviceFormSchema = insertNetworkDeviceSchema.extend({
  name: z.string().min(1, "Name is required"),
  ipAddress: z.string().min(7, "Valid IP required"),
});

const pppoeFormSchema = insertPppoeUserSchema.extend({
  username: z.string().min(1, "Username is required"),
});

export default function MikroTikPage() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("devices");
  const [deviceSearch, setDeviceSearch] = useState("");
  const [pppoeSearch, setPppoeSearch] = useState("");
  const [deviceStatusFilter, setDeviceStatusFilter] = useState("all");
  const [pppoeStatusFilter, setPppoeStatusFilter] = useState("all");
  const [deviceDialogOpen, setDeviceDialogOpen] = useState(false);
  const [pppoeDialogOpen, setPppoeDialogOpen] = useState(false);
  const [editingDevice, setEditingDevice] = useState<NetworkDevice | null>(null);
  const [editingPppoe, setEditingPppoe] = useState<PppoeUser | null>(null);

  const { data: networkDevices, isLoading: devicesLoading } = useQuery<NetworkDevice[]>({
    queryKey: ["/api/network-devices"],
  });

  const { data: pppoeUsers, isLoading: pppoeLoading } = useQuery<(PppoeUser & { customerName?: string })[]>({
    queryKey: ["/api/pppoe-users"],
  });

  const { data: customers } = useQuery<Customer[]>({
    queryKey: ["/api/customers"],
  });

  const deviceForm = useForm<InsertNetworkDevice>({
    resolver: zodResolver(deviceFormSchema),
    defaultValues: {
      name: "",
      type: "router",
      vendor: "mikrotik",
      ipAddress: "",
      macAddress: "",
      location: "",
      area: "",
      status: "online",
      lastSeen: "",
      uptime: "",
      cpuUsage: undefined,
      memoryUsage: undefined,
      firmware: "",
      model: "",
      serialNumber: "",
      notes: "",
      monitoringEnabled: true,
      alertThreshold: 80,
    },
  });

  const pppoeForm = useForm<InsertPppoeUser>({
    resolver: zodResolver(pppoeFormSchema),
    defaultValues: {
      username: "",
      password: "",
      customerId: undefined,
      profileName: "",
      serviceType: "pppoe",
      status: "active",
      ipAddress: "",
      macAddress: "",
      uploadSpeed: "",
      downloadSpeed: "",
      dataLimit: "",
      bytesIn: "0",
      bytesOut: "0",
      lastOnline: "",
      nasDevice: "",
      callerStationId: "",
      sessionTimeout: undefined,
      idleTimeout: undefined,
      createdAt: "",
    },
  });

  const createDeviceMutation = useMutation({
    mutationFn: async (data: InsertNetworkDevice) => {
      const res = await apiRequest("POST", "/api/network-devices", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/network-devices"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      setDeviceDialogOpen(false);
      deviceForm.reset();
      toast({ title: "Device created successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const updateDeviceMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertNetworkDevice> }) => {
      const res = await apiRequest("PATCH", `/api/network-devices/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/network-devices"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      setDeviceDialogOpen(false);
      setEditingDevice(null);
      deviceForm.reset();
      toast({ title: "Device updated successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const deleteDeviceMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/network-devices/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/network-devices"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({ title: "Device deleted" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const createPppoeMutation = useMutation({
    mutationFn: async (data: InsertPppoeUser) => {
      const res = await apiRequest("POST", "/api/pppoe-users", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/pppoe-users"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      setPppoeDialogOpen(false);
      pppoeForm.reset();
      toast({ title: "PPPoE user created successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const updatePppoeMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertPppoeUser> }) => {
      const res = await apiRequest("PATCH", `/api/pppoe-users/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/pppoe-users"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      setPppoeDialogOpen(false);
      setEditingPppoe(null);
      pppoeForm.reset();
      toast({ title: "PPPoE user updated successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const deletePppoeMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/pppoe-users/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/pppoe-users"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({ title: "PPPoE user deleted" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const openCreateDevice = () => {
    setEditingDevice(null);
    deviceForm.reset({
      name: "",
      type: "router",
      vendor: "mikrotik",
      ipAddress: "",
      macAddress: "",
      location: "",
      area: "",
      status: "online",
      lastSeen: "",
      uptime: "",
      cpuUsage: undefined,
      memoryUsage: undefined,
      firmware: "",
      model: "",
      serialNumber: "",
      notes: "",
      monitoringEnabled: true,
      alertThreshold: 80,
    });
    setDeviceDialogOpen(true);
  };

  const openEditDevice = (device: NetworkDevice) => {
    setEditingDevice(device);
    deviceForm.reset({
      name: device.name,
      type: device.type,
      vendor: device.vendor || "mikrotik",
      ipAddress: device.ipAddress,
      macAddress: device.macAddress || "",
      location: device.location || "",
      area: device.area || "",
      status: device.status,
      lastSeen: device.lastSeen || "",
      uptime: device.uptime || "",
      cpuUsage: device.cpuUsage ?? undefined,
      memoryUsage: device.memoryUsage ?? undefined,
      firmware: device.firmware || "",
      model: device.model || "",
      serialNumber: device.serialNumber || "",
      notes: device.notes || "",
      monitoringEnabled: device.monitoringEnabled ?? true,
      alertThreshold: device.alertThreshold ?? 80,
    });
    setDeviceDialogOpen(true);
  };

  const openCreatePppoe = () => {
    setEditingPppoe(null);
    pppoeForm.reset({
      username: "",
      password: "",
      customerId: undefined,
      profileName: "",
      serviceType: "pppoe",
      status: "active",
      ipAddress: "",
      macAddress: "",
      uploadSpeed: "",
      downloadSpeed: "",
      dataLimit: "",
      bytesIn: "0",
      bytesOut: "0",
      lastOnline: "",
      nasDevice: "",
      callerStationId: "",
      sessionTimeout: undefined,
      idleTimeout: undefined,
      createdAt: "",
    });
    setPppoeDialogOpen(true);
  };

  const openEditPppoe = (user: PppoeUser) => {
    setEditingPppoe(user);
    pppoeForm.reset({
      username: user.username,
      password: user.password || "",
      customerId: user.customerId ?? undefined,
      profileName: user.profileName || "",
      serviceType: user.serviceType || "pppoe",
      status: user.status,
      ipAddress: user.ipAddress || "",
      macAddress: user.macAddress || "",
      uploadSpeed: user.uploadSpeed || "",
      downloadSpeed: user.downloadSpeed || "",
      dataLimit: user.dataLimit || "",
      bytesIn: user.bytesIn || "0",
      bytesOut: user.bytesOut || "0",
      lastOnline: user.lastOnline || "",
      nasDevice: user.nasDevice || "",
      callerStationId: user.callerStationId || "",
      sessionTimeout: user.sessionTimeout ?? undefined,
      idleTimeout: user.idleTimeout ?? undefined,
      createdAt: user.createdAt || "",
    });
    setPppoeDialogOpen(true);
  };

  const onSubmitDevice = (data: InsertNetworkDevice) => {
    if (editingDevice) {
      updateDeviceMutation.mutate({ id: editingDevice.id, data });
    } else {
      createDeviceMutation.mutate(data);
    }
  };

  const onSubmitPppoe = (data: InsertPppoeUser) => {
    if (editingPppoe) {
      updatePppoeMutation.mutate({ id: editingPppoe.id, data });
    } else {
      createPppoeMutation.mutate(data);
    }
  };

  const handleExport = () => {
    window.open("/api/export/network-devices", "_blank");
  };

  const mikrotikDevices = (networkDevices || []).filter(
    (d) => (d.vendor || "").toLowerCase() === "mikrotik"
  );

  const filteredDevices = mikrotikDevices.filter((d) => {
    const matchSearch =
      d.name.toLowerCase().includes(deviceSearch.toLowerCase()) ||
      d.ipAddress.toLowerCase().includes(deviceSearch.toLowerCase()) ||
      (d.model || "").toLowerCase().includes(deviceSearch.toLowerCase()) ||
      (d.location || "").toLowerCase().includes(deviceSearch.toLowerCase());
    const matchStatus = deviceStatusFilter === "all" || d.status === deviceStatusFilter;
    return matchSearch && matchStatus;
  });

  const filteredPppoe = (pppoeUsers || []).filter((u) => {
    const matchSearch =
      u.username.toLowerCase().includes(pppoeSearch.toLowerCase()) ||
      (u.ipAddress || "").toLowerCase().includes(pppoeSearch.toLowerCase()) ||
      (u.profileName || "").toLowerCase().includes(pppoeSearch.toLowerCase()) ||
      (u.nasDevice || "").toLowerCase().includes(pppoeSearch.toLowerCase()) ||
      ((u as any).customerName || "").toLowerCase().includes(pppoeSearch.toLowerCase());
    const matchStatus = pppoeStatusFilter === "all" || u.status === pppoeStatusFilter;
    return matchSearch && matchStatus;
  });

  const deviceStatusConfig: Record<string, { color: string }> = {
    online: { color: "text-green-700 dark:text-green-300 bg-green-50 dark:bg-green-950" },
    offline: { color: "text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950" },
    warning: { color: "text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950" },
  };

  const pppoeStatusConfig: Record<string, { color: string }> = {
    active: { color: "text-green-700 dark:text-green-300 bg-green-50 dark:bg-green-950" },
    disabled: { color: "text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950" },
    suspended: { color: "text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950" },
  };

  const totalDevices = mikrotikDevices.length;
  const onlineDevices = mikrotikDevices.filter((d) => d.status === "online").length;
  const offlineDevices = mikrotikDevices.filter((d) => d.status === "offline").length;
  const totalPppoeUsers = (pppoeUsers || []).length;

  const summaryCards = [
    { title: "Total Devices", value: totalDevices, icon: Server, color: "text-blue-600 dark:text-blue-400" },
    { title: "Online", value: onlineDevices, icon: Wifi, color: "text-green-600 dark:text-green-400" },
    { title: "Offline", value: offlineDevices, icon: WifiOff, color: "text-red-600 dark:text-red-400" },
    { title: "PPPoE Users", value: totalPppoeUsers, icon: Users, color: "text-purple-600 dark:text-purple-400" },
  ];

  const isLoadingSummary = devicesLoading || pppoeLoading;

  return (
    <div className="p-6 space-y-6 max-w-[1400px] mx-auto">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight" data-testid="text-mikrotik-title">MikroTik Integration</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Manage MikroTik devices and PPPoE users</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button variant="outline" onClick={handleExport} data-testid="button-export-devices">
            <Download className="h-4 w-4 mr-1" />
            Export CSV
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {summaryCards.map((card) => (
          <Card key={card.title} data-testid={`card-summary-${card.title.toLowerCase().replace(/\s+/g, "-")}`}>
            <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
              <span className="text-sm font-medium text-muted-foreground">{card.title}</span>
              <card.icon className={`h-4 w-4 ${card.color}`} />
            </CardHeader>
            <CardContent>
              {isLoadingSummary ? (
                <Skeleton className="h-8 w-16" />
              ) : (
                <div className="text-2xl font-bold" data-testid={`text-summary-${card.title.toLowerCase().replace(/\s+/g, "-")}`}>
                  {card.value}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList data-testid="tabs-mikrotik">
          <TabsTrigger value="devices" data-testid="tab-devices">Devices</TabsTrigger>
          <TabsTrigger value="pppoe" data-testid="tab-pppoe">PPPoE Users</TabsTrigger>
        </TabsList>

        <TabsContent value="devices" className="mt-4">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
                <div className="relative flex-1 w-full sm:max-w-xs">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search devices..."
                    value={deviceSearch}
                    onChange={(e) => setDeviceSearch(e.target.value)}
                    className="pl-9"
                    data-testid="input-search-devices"
                  />
                </div>
                <Select value={deviceStatusFilter} onValueChange={setDeviceStatusFilter}>
                  <SelectTrigger className="w-[160px]" data-testid="select-device-status-filter">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="online">Online</SelectItem>
                    <SelectItem value="offline">Offline</SelectItem>
                    <SelectItem value="warning">Warning</SelectItem>
                  </SelectContent>
                </Select>
                <Button onClick={openCreateDevice} data-testid="button-add-device">
                  <Plus className="h-4 w-4 mr-1" />
                  Add Device
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              {devicesLoading ? (
                <div className="p-5 space-y-3">
                  {[1, 2, 3].map((i) => (
                    <Skeleton key={i} className="h-14 w-full" />
                  ))}
                </div>
              ) : filteredDevices.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                  <Server className="h-12 w-12 mb-3 opacity-30" />
                  <p className="font-medium">No devices found</p>
                  <p className="text-sm mt-1">Add a MikroTik device to get started</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Name</TableHead>
                        <TableHead className="hidden md:table-cell">Model</TableHead>
                        <TableHead>IP Address</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="hidden lg:table-cell">CPU%</TableHead>
                        <TableHead className="hidden lg:table-cell">Memory%</TableHead>
                        <TableHead className="hidden md:table-cell">Uptime</TableHead>
                        <TableHead className="hidden lg:table-cell">Location</TableHead>
                        <TableHead className="hidden xl:table-cell">Firmware</TableHead>
                        <TableHead className="w-10"></TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredDevices.map((device) => {
                        const config = deviceStatusConfig[device.status] || deviceStatusConfig.online;
                        return (
                          <TableRow key={device.id} data-testid={`row-device-${device.id}`}>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                <Router className="h-4 w-4 text-muted-foreground" />
                                <span className="font-medium" data-testid={`text-device-name-${device.id}`}>{device.name}</span>
                              </div>
                            </TableCell>
                            <TableCell className="hidden md:table-cell text-sm text-muted-foreground">
                              {device.model || "\u2014"}
                            </TableCell>
                            <TableCell>
                              <span className="font-mono text-sm" data-testid={`text-device-ip-${device.id}`}>{device.ipAddress}</span>
                            </TableCell>
                            <TableCell>
                              <Badge variant="secondary" className={`no-default-active-elevate text-[10px] capitalize ${config.color}`}>
                                {device.status}
                              </Badge>
                            </TableCell>
                            <TableCell className="hidden lg:table-cell text-sm text-muted-foreground">
                              {device.cpuUsage != null ? `${device.cpuUsage}%` : "\u2014"}
                            </TableCell>
                            <TableCell className="hidden lg:table-cell text-sm text-muted-foreground">
                              {device.memoryUsage != null ? `${device.memoryUsage}%` : "\u2014"}
                            </TableCell>
                            <TableCell className="hidden md:table-cell text-sm text-muted-foreground">
                              {device.uptime || "\u2014"}
                            </TableCell>
                            <TableCell className="hidden lg:table-cell text-sm text-muted-foreground">
                              {device.location || "\u2014"}
                            </TableCell>
                            <TableCell className="hidden xl:table-cell text-sm text-muted-foreground">
                              {device.firmware || "\u2014"}
                            </TableCell>
                            <TableCell>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon" data-testid={`button-device-actions-${device.id}`}>
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem onClick={() => openEditDevice(device)} data-testid={`button-edit-device-${device.id}`}>
                                    <Edit className="h-4 w-4 mr-2" />
                                    Edit
                                  </DropdownMenuItem>
                                  <DropdownMenuItem
                                    className="text-destructive"
                                    onClick={() => deleteDeviceMutation.mutate(device.id)}
                                    data-testid={`button-delete-device-${device.id}`}
                                  >
                                    <Trash2 className="h-4 w-4 mr-2" />
                                    Delete
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="pppoe" className="mt-4">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
                <div className="relative flex-1 w-full sm:max-w-xs">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search PPPoE users..."
                    value={pppoeSearch}
                    onChange={(e) => setPppoeSearch(e.target.value)}
                    className="pl-9"
                    data-testid="input-search-pppoe"
                  />
                </div>
                <Select value={pppoeStatusFilter} onValueChange={setPppoeStatusFilter}>
                  <SelectTrigger className="w-[160px]" data-testid="select-pppoe-status-filter">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="disabled">Disabled</SelectItem>
                    <SelectItem value="suspended">Suspended</SelectItem>
                  </SelectContent>
                </Select>
                <Button onClick={openCreatePppoe} data-testid="button-add-pppoe">
                  <Plus className="h-4 w-4 mr-1" />
                  Add PPPoE User
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              {pppoeLoading ? (
                <div className="p-5 space-y-3">
                  {[1, 2, 3].map((i) => (
                    <Skeleton key={i} className="h-14 w-full" />
                  ))}
                </div>
              ) : filteredPppoe.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                  <Users className="h-12 w-12 mb-3 opacity-30" />
                  <p className="font-medium">No PPPoE users found</p>
                  <p className="text-sm mt-1">Add a PPPoE user to get started</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Username</TableHead>
                        <TableHead className="hidden md:table-cell">Customer</TableHead>
                        <TableHead className="hidden md:table-cell">Profile</TableHead>
                        <TableHead>IP Address</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="hidden lg:table-cell">Download Speed</TableHead>
                        <TableHead className="hidden lg:table-cell">Upload Speed</TableHead>
                        <TableHead className="hidden xl:table-cell">Last Online</TableHead>
                        <TableHead className="hidden xl:table-cell">NAS Device</TableHead>
                        <TableHead className="w-10"></TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredPppoe.map((user) => {
                        const config = pppoeStatusConfig[user.status] || pppoeStatusConfig.active;
                        return (
                          <TableRow key={user.id} data-testid={`row-pppoe-${user.id}`}>
                            <TableCell>
                              <span className="font-medium" data-testid={`text-pppoe-username-${user.id}`}>{user.username}</span>
                            </TableCell>
                            <TableCell className="hidden md:table-cell text-sm text-muted-foreground">
                              {(user as any).customerName || (user.customerId ? `#${user.customerId}` : "\u2014")}
                            </TableCell>
                            <TableCell className="hidden md:table-cell text-sm text-muted-foreground">
                              {user.profileName || "\u2014"}
                            </TableCell>
                            <TableCell>
                              <span className="font-mono text-sm">{user.ipAddress || "\u2014"}</span>
                            </TableCell>
                            <TableCell>
                              <Badge variant="secondary" className={`no-default-active-elevate text-[10px] capitalize ${config.color}`}>
                                {user.status}
                              </Badge>
                            </TableCell>
                            <TableCell className="hidden lg:table-cell text-sm text-muted-foreground">
                              {user.downloadSpeed || "\u2014"}
                            </TableCell>
                            <TableCell className="hidden lg:table-cell text-sm text-muted-foreground">
                              {user.uploadSpeed || "\u2014"}
                            </TableCell>
                            <TableCell className="hidden xl:table-cell text-sm text-muted-foreground">
                              {user.lastOnline || "\u2014"}
                            </TableCell>
                            <TableCell className="hidden xl:table-cell text-sm text-muted-foreground">
                              {user.nasDevice || "\u2014"}
                            </TableCell>
                            <TableCell>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon" data-testid={`button-pppoe-actions-${user.id}`}>
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem onClick={() => openEditPppoe(user)} data-testid={`button-edit-pppoe-${user.id}`}>
                                    <Edit className="h-4 w-4 mr-2" />
                                    Edit
                                  </DropdownMenuItem>
                                  <DropdownMenuItem
                                    className="text-destructive"
                                    onClick={() => deletePppoeMutation.mutate(user.id)}
                                    data-testid={`button-delete-pppoe-${user.id}`}
                                  >
                                    <Trash2 className="h-4 w-4 mr-2" />
                                    Delete
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog open={deviceDialogOpen} onOpenChange={setDeviceDialogOpen}>
        <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle data-testid="text-device-dialog-title">
              {editingDevice ? "Edit Device" : "Add Device"}
            </DialogTitle>
          </DialogHeader>
          <Form {...deviceForm}>
            <form onSubmit={deviceForm.handleSubmit(onSubmitDevice)} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <FormField
                  control={deviceForm.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Main Router" {...field} data-testid="input-device-name" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={deviceForm.control}
                  name="model"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Model</FormLabel>
                      <FormControl>
                        <Input placeholder="CCR1036-8G-2S+" {...field} value={field.value || ""} data-testid="input-device-model" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={deviceForm.control}
                  name="ipAddress"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>IP Address</FormLabel>
                      <FormControl>
                        <Input placeholder="192.168.1.1" {...field} data-testid="input-device-ip" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={deviceForm.control}
                  name="macAddress"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>MAC Address</FormLabel>
                      <FormControl>
                        <Input placeholder="AA:BB:CC:DD:EE:FF" {...field} value={field.value || ""} data-testid="input-device-mac" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={deviceForm.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Type</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-device-type">
                            <SelectValue placeholder="Select type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="router">Router</SelectItem>
                          <SelectItem value="switch">Switch</SelectItem>
                          <SelectItem value="access_point">Access Point</SelectItem>
                          <SelectItem value="olt">OLT</SelectItem>
                          <SelectItem value="onu">ONU</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={deviceForm.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Status</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-device-status">
                            <SelectValue placeholder="Select status" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="online">Online</SelectItem>
                          <SelectItem value="offline">Offline</SelectItem>
                          <SelectItem value="warning">Warning</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={deviceForm.control}
                  name="location"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Location</FormLabel>
                      <FormControl>
                        <Input placeholder="Server Room A" {...field} value={field.value || ""} data-testid="input-device-location" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={deviceForm.control}
                  name="area"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Area</FormLabel>
                      <FormControl>
                        <Input placeholder="Downtown" {...field} value={field.value || ""} data-testid="input-device-area" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={deviceForm.control}
                  name="firmware"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Firmware</FormLabel>
                      <FormControl>
                        <Input placeholder="RouterOS 7.x" {...field} value={field.value || ""} data-testid="input-device-firmware" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={deviceForm.control}
                  name="serialNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Serial Number</FormLabel>
                      <FormControl>
                        <Input placeholder="SN-123456" {...field} value={field.value || ""} data-testid="input-device-serial" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={deviceForm.control}
                  name="uptime"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Uptime</FormLabel>
                      <FormControl>
                        <Input placeholder="30d 5h 12m" {...field} value={field.value || ""} data-testid="input-device-uptime" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={deviceForm.control}
                  name="alertThreshold"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Alert Threshold (%)</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          placeholder="80"
                          {...field}
                          value={field.value ?? ""}
                          onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : undefined)}
                          data-testid="input-device-threshold"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={deviceForm.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Additional notes..." {...field} value={field.value || ""} data-testid="input-device-notes" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="submit" disabled={createDeviceMutation.isPending || updateDeviceMutation.isPending} data-testid="button-submit-device">
                  {createDeviceMutation.isPending || updateDeviceMutation.isPending ? "Saving..." : editingDevice ? "Update Device" : "Add Device"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <Dialog open={pppoeDialogOpen} onOpenChange={setPppoeDialogOpen}>
        <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle data-testid="text-pppoe-dialog-title">
              {editingPppoe ? "Edit PPPoE User" : "Add PPPoE User"}
            </DialogTitle>
          </DialogHeader>
          <Form {...pppoeForm}>
            <form onSubmit={pppoeForm.handleSubmit(onSubmitPppoe)} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <FormField
                  control={pppoeForm.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Username</FormLabel>
                      <FormControl>
                        <Input placeholder="pppoe_user1" {...field} data-testid="input-pppoe-username" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={pppoeForm.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Password</FormLabel>
                      <FormControl>
                        <Input type="password" placeholder="Password" {...field} value={field.value || ""} data-testid="input-pppoe-password" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={pppoeForm.control}
                  name="customerId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Customer</FormLabel>
                      <Select
                        onValueChange={(v) => field.onChange(v === "none" ? undefined : parseInt(v))}
                        value={field.value ? String(field.value) : "none"}
                      >
                        <FormControl>
                          <SelectTrigger data-testid="select-pppoe-customer">
                            <SelectValue placeholder="Select customer" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="none">No Customer</SelectItem>
                          {(customers || []).map((c) => (
                            <SelectItem key={c.id} value={String(c.id)}>
                              {c.fullName} ({c.customerId})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={pppoeForm.control}
                  name="profileName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Profile</FormLabel>
                      <FormControl>
                        <Input placeholder="10Mbps" {...field} value={field.value || ""} data-testid="input-pppoe-profile" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={pppoeForm.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Status</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-pppoe-status">
                            <SelectValue placeholder="Select status" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="active">Active</SelectItem>
                          <SelectItem value="disabled">Disabled</SelectItem>
                          <SelectItem value="suspended">Suspended</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={pppoeForm.control}
                  name="ipAddress"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>IP Address</FormLabel>
                      <FormControl>
                        <Input placeholder="10.0.0.1" {...field} value={field.value || ""} data-testid="input-pppoe-ip" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={pppoeForm.control}
                  name="downloadSpeed"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Download Speed</FormLabel>
                      <FormControl>
                        <Input placeholder="10M" {...field} value={field.value || ""} data-testid="input-pppoe-download" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={pppoeForm.control}
                  name="uploadSpeed"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Upload Speed</FormLabel>
                      <FormControl>
                        <Input placeholder="5M" {...field} value={field.value || ""} data-testid="input-pppoe-upload" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={pppoeForm.control}
                  name="macAddress"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>MAC Address</FormLabel>
                      <FormControl>
                        <Input placeholder="AA:BB:CC:DD:EE:FF" {...field} value={field.value || ""} data-testid="input-pppoe-mac" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={pppoeForm.control}
                  name="nasDevice"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>NAS Device</FormLabel>
                      <FormControl>
                        <Input placeholder="NAS-01" {...field} value={field.value || ""} data-testid="input-pppoe-nas" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={pppoeForm.control}
                  name="dataLimit"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Data Limit</FormLabel>
                      <FormControl>
                        <Input placeholder="100GB" {...field} value={field.value || ""} data-testid="input-pppoe-data-limit" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={pppoeForm.control}
                  name="serviceType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Service Type</FormLabel>
                      <FormControl>
                        <Input placeholder="pppoe" {...field} value={field.value || ""} data-testid="input-pppoe-service-type" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <DialogFooter>
                <Button type="submit" disabled={createPppoeMutation.isPending || updatePppoeMutation.isPending} data-testid="button-submit-pppoe">
                  {createPppoeMutation.isPending || updatePppoeMutation.isPending ? "Saving..." : editingPppoe ? "Update User" : "Add User"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}