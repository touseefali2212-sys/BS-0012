import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Plus,
  Search,
  MoreHorizontal,
  Edit,
  Trash2,
  BookOpen,
  CheckCircle,
  XCircle,
  DollarSign,
  TrendingUp,
  TrendingDown,
  PiggyBank,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useTab } from "@/hooks/use-tab";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  insertAccountSchema,
  insertTransactionSchema,
  type Account,
  type InsertAccount,
  type Transaction,
  type InsertTransaction,
} from "@shared/schema";
import { z } from "zod";

const accountFormSchema = insertAccountSchema.extend({
  code: z.string().min(1, "Code is required"),
  name: z.string().min(1, "Account name is required"),
  type: z.string().min(1, "Account type is required"),
  balance: z.string().optional(),
});

const incomeFormSchema = insertTransactionSchema.extend({
  txnId: z.string().min(1, "Transaction ID is required"),
  amount: z.string().min(1, "Amount is required"),
  date: z.string().min(1, "Date is required"),
  description: z.string().optional(),
});

const expenseFormSchema = insertTransactionSchema.extend({
  txnId: z.string().min(1, "Transaction ID is required"),
  amount: z.string().min(1, "Amount is required"),
  date: z.string().min(1, "Date is required"),
  description: z.string().optional(),
});

export default function AccountingPage() {
  const { toast } = useToast();
  const [tab, changeTab] = useTab("types");
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingAccount, setEditingAccount] = useState<Account | null>(null);
  const [incomeDialogOpen, setIncomeDialogOpen] = useState(false);
  const [expenseDialogOpen, setExpenseDialogOpen] = useState(false);

  const { data: accounts, isLoading } = useQuery<Account[]>({
    queryKey: ["/api/accounts"],
  });

  const { data: transactions, isLoading: txnLoading } = useQuery<Transaction[]>({
    queryKey: ["/api/transactions"],
  });

  const form = useForm<InsertAccount>({
    resolver: zodResolver(accountFormSchema),
    defaultValues: {
      code: "",
      name: "",
      type: "asset",
      parentId: null,
      balance: "0",
      description: "",
      isActive: true,
    },
  });

  const addAccountForm = useForm<InsertAccount>({
    resolver: zodResolver(accountFormSchema),
    defaultValues: {
      code: "",
      name: "",
      type: "asset",
      parentId: null,
      balance: "0",
      description: "",
      isActive: true,
    },
  });

  const incomeForm = useForm<InsertTransaction>({
    resolver: zodResolver(incomeFormSchema),
    defaultValues: {
      txnId: "",
      type: "payment",
      amount: "0",
      accountId: null,
      customerId: null,
      invoiceId: null,
      paymentMethod: "",
      reference: "",
      description: "",
      date: new Date().toISOString().split("T")[0],
      status: "completed",
    },
  });

  const expenseForm = useForm<InsertTransaction>({
    resolver: zodResolver(expenseFormSchema),
    defaultValues: {
      txnId: "",
      type: "expense",
      amount: "0",
      accountId: null,
      customerId: null,
      invoiceId: null,
      paymentMethod: "",
      reference: "",
      description: "",
      date: new Date().toISOString().split("T")[0],
      status: "completed",
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertAccount) => {
      const res = await apiRequest("POST", "/api/accounts", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
      setDialogOpen(false);
      form.reset();
      toast({ title: "Account created successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const addAccountMutation = useMutation({
    mutationFn: async (data: InsertAccount) => {
      const res = await apiRequest("POST", "/api/accounts", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
      addAccountForm.reset();
      toast({ title: "Account created successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertAccount> }) => {
      const res = await apiRequest("PATCH", `/api/accounts/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
      setDialogOpen(false);
      setEditingAccount(null);
      form.reset();
      toast({ title: "Account updated successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/accounts/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/accounts"] });
      toast({ title: "Account deleted successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const createTransactionMutation = useMutation({
    mutationFn: async (data: InsertTransaction) => {
      const res = await apiRequest("POST", "/api/transactions", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      setIncomeDialogOpen(false);
      setExpenseDialogOpen(false);
      incomeForm.reset();
      expenseForm.reset();
      toast({ title: "Transaction created successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const openCreate = () => {
    setEditingAccount(null);
    form.reset({
      code: "",
      name: "",
      type: "asset",
      parentId: null,
      balance: "0",
      description: "",
      isActive: true,
    });
    setDialogOpen(true);
  };

  const openEdit = (account: Account) => {
    setEditingAccount(account);
    form.reset({
      code: account.code,
      name: account.name,
      type: account.type,
      parentId: account.parentId,
      balance: account.balance || "0",
      description: account.description || "",
      isActive: account.isActive,
    });
    setDialogOpen(true);
  };

  const onSubmit = (data: InsertAccount) => {
    if (editingAccount) {
      updateMutation.mutate({ id: editingAccount.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const filtered = (accounts || []).filter((acc) => {
    const matchSearch =
      acc.code.toLowerCase().includes(search.toLowerCase()) ||
      acc.name.toLowerCase().includes(search.toLowerCase());
    const matchType = typeFilter === "all" || acc.type === typeFilter;
    return matchSearch && matchType;
  });

  const incomeTransactions = (transactions || []).filter(
    (t) => t.type === "income" || t.type === "payment"
  );

  const expenseTransactions = (transactions || []).filter(
    (t) => t.type === "expense"
  );

  const typeConfig: Record<string, string> = {
    asset: "text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950",
    liability: "text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950",
    income: "text-green-700 dark:text-green-300 bg-green-50 dark:bg-green-950",
    expense: "text-orange-600 dark:text-orange-400 bg-orange-50 dark:bg-orange-950",
    equity: "text-purple-700 dark:text-purple-300 bg-purple-50 dark:bg-purple-950",
  };

  return (
    <div className="p-6 space-y-6 max-w-[1400px] mx-auto">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight" data-testid="text-accounting-title">Accounting</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Manage accounts, income, expenses, and budgets</p>
        </div>
      </div>

        {tab === "types" && (<div className="mt-5">
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <h2 className="text-lg font-semibold" data-testid="text-chart-of-accounts-title">Chart of Accounts</h2>
              <Button onClick={openCreate} data-testid="button-add-account">
                <Plus className="h-4 w-4 mr-1" />
                Add Account
              </Button>
            </div>

            <Card>
              <CardHeader className="pb-3">
                <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
                  <div className="relative flex-1 w-full sm:max-w-xs">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search by code or name..."
                      value={search}
                      onChange={(e) => setSearch(e.target.value)}
                      className="pl-9"
                      data-testid="input-search-accounts"
                    />
                  </div>
                  <Select value={typeFilter} onValueChange={setTypeFilter}>
                    <SelectTrigger className="w-[140px]" data-testid="select-account-type-filter">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="asset">Asset</SelectItem>
                      <SelectItem value="liability">Liability</SelectItem>
                      <SelectItem value="income">Income</SelectItem>
                      <SelectItem value="expense">Expense</SelectItem>
                      <SelectItem value="equity">Equity</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                {isLoading ? (
                  <div className="p-5 space-y-3">
                    {[1, 2, 3].map((i) => (
                      <Skeleton key={i} className="h-14 w-full" />
                    ))}
                  </div>
                ) : filtered.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                    <BookOpen className="h-12 w-12 mb-3 opacity-30" />
                    <p className="font-medium">No accounts found</p>
                    <p className="text-sm mt-1">Create your first account</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Code</TableHead>
                          <TableHead>Account Name</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Balance (Rs.)</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead className="w-10"></TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filtered.map((acc) => (
                          <TableRow key={acc.id} data-testid={`row-account-${acc.id}`}>
                            <TableCell className="font-mono text-xs" data-testid={`text-account-code-${acc.id}`}>{acc.code}</TableCell>
                            <TableCell className="font-medium" data-testid={`text-account-name-${acc.id}`}>{acc.name}</TableCell>
                            <TableCell>
                              <Badge variant="secondary" className={`no-default-active-elevate text-[10px] capitalize ${typeConfig[acc.type] || ""}`} data-testid={`badge-account-type-${acc.id}`}>
                                {acc.type}
                              </Badge>
                            </TableCell>
                            <TableCell className="font-semibold" data-testid={`text-account-balance-${acc.id}`}>
                              Rs. {Number(acc.balance || 0).toLocaleString()}
                            </TableCell>
                            <TableCell>
                              <Badge
                                variant="secondary"
                                className={`no-default-active-elevate text-[10px] ${
                                  acc.isActive
                                    ? "text-green-700 dark:text-green-300 bg-green-50 dark:bg-green-950"
                                    : "text-gray-500 bg-gray-50 dark:bg-gray-900"
                                }`}
                                data-testid={`badge-account-status-${acc.id}`}
                              >
                                {acc.isActive ? (
                                  <><CheckCircle className="h-3 w-3 mr-1" />Active</>
                                ) : (
                                  <><XCircle className="h-3 w-3 mr-1" />Inactive</>
                                )}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon" data-testid={`button-account-actions-${acc.id}`}>
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem onClick={() => openEdit(acc)} data-testid={`button-edit-account-${acc.id}`}>
                                    <Edit className="h-4 w-4 mr-2" />
                                    Edit
                                  </DropdownMenuItem>
                                  <DropdownMenuItem
                                    className="text-destructive"
                                    onClick={() => deleteMutation.mutate(acc.id)}
                                    data-testid={`button-delete-account-${acc.id}`}
                                  >
                                    <Trash2 className="h-4 w-4 mr-2" />
                                    Delete
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>)}

        {tab === "add" && (<div className="mt-5">
          <Card>
            <CardHeader>
              <CardTitle data-testid="text-new-account-title">Create New Account</CardTitle>
              <CardDescription>Add a new account to your chart of accounts</CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...addAccountForm}>
                <form onSubmit={addAccountForm.handleSubmit((data) => addAccountMutation.mutate(data))} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <FormField
                      control={addAccountForm.control}
                      name="code"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Code</FormLabel>
                          <FormControl>
                            <Input placeholder="1001" data-testid="input-new-account-code" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={addAccountForm.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Account Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Cash in Hand" data-testid="input-new-account-name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <FormField
                      control={addAccountForm.control}
                      name="type"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Type</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value || "asset"}>
                            <FormControl>
                              <SelectTrigger data-testid="select-new-account-type">
                                <SelectValue />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="asset">Asset</SelectItem>
                              <SelectItem value="liability">Liability</SelectItem>
                              <SelectItem value="income">Income</SelectItem>
                              <SelectItem value="expense">Expense</SelectItem>
                              <SelectItem value="equity">Equity</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={addAccountForm.control}
                      name="parentId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Parent Account</FormLabel>
                          <Select
                            onValueChange={(v) => field.onChange(v === "none" ? null : parseInt(v))}
                            value={field.value?.toString() || "none"}
                          >
                            <FormControl>
                              <SelectTrigger data-testid="select-new-account-parent">
                                <SelectValue placeholder="None" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="none">None</SelectItem>
                              {(accounts || []).map((a) => (
                                <SelectItem key={a.id} value={a.id.toString()}>
                                  {a.code} - {a.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <FormField
                    control={addAccountForm.control}
                    name="balance"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Opening Balance (Rs.)</FormLabel>
                        <FormControl>
                          <Input type="number" placeholder="0" data-testid="input-new-account-balance" {...field} value={field.value || "0"} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={addAccountForm.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea placeholder="Account description..." data-testid="input-new-account-description" {...field} value={field.value || ""} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={addAccountForm.control}
                    name="isActive"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Status</FormLabel>
                        <Select
                          onValueChange={(v) => field.onChange(v === "true")}
                          value={field.value ? "true" : "false"}
                        >
                          <FormControl>
                            <SelectTrigger data-testid="select-new-account-active">
                              <SelectValue />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="true">Active</SelectItem>
                            <SelectItem value="false">Inactive</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <div className="flex justify-end gap-3">
                    <Button type="button" variant="secondary" onClick={() => addAccountForm.reset()} data-testid="button-reset-new-account">
                      Reset
                    </Button>
                    <Button type="submit" disabled={addAccountMutation.isPending} data-testid="button-create-new-account">
                      {addAccountMutation.isPending ? "Creating..." : "Create Account"}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>)}

        {tab === "income" && (<div className="mt-5">
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <h2 className="text-lg font-semibold" data-testid="text-income-title">Income Entries</h2>
              <Button onClick={() => {
                incomeForm.reset({
                  txnId: `INC-${Date.now()}`,
                  type: "payment",
                  amount: "0",
                  accountId: null,
                  customerId: null,
                  invoiceId: null,
                  paymentMethod: "",
                  reference: "",
                  description: "",
                  date: new Date().toISOString().split("T")[0],
                  status: "completed",
                });
                setIncomeDialogOpen(true);
              }} data-testid="button-add-income">
                <Plus className="h-4 w-4 mr-1" />
                Add Income
              </Button>
            </div>

            <Card>
              <CardContent className="p-0">
                {txnLoading ? (
                  <div className="p-5 space-y-3">
                    {[1, 2, 3].map((i) => (
                      <Skeleton key={i} className="h-14 w-full" />
                    ))}
                  </div>
                ) : incomeTransactions.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                    <TrendingUp className="h-12 w-12 mb-3 opacity-30" />
                    <p className="font-medium">No income entries found</p>
                    <p className="text-sm mt-1">Add your first income entry</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Txn ID</TableHead>
                          <TableHead>Date</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Description</TableHead>
                          <TableHead>Method</TableHead>
                          <TableHead>Amount (Rs.)</TableHead>
                          <TableHead>Status</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {incomeTransactions.map((txn) => (
                          <TableRow key={txn.id} data-testid={`row-income-${txn.id}`}>
                            <TableCell className="font-mono text-xs" data-testid={`text-income-txnid-${txn.id}`}>{txn.txnId}</TableCell>
                            <TableCell data-testid={`text-income-date-${txn.id}`}>{txn.date}</TableCell>
                            <TableCell>
                              <Badge variant="secondary" className="no-default-active-elevate text-[10px] capitalize text-green-700 dark:text-green-300 bg-green-50 dark:bg-green-950" data-testid={`badge-income-type-${txn.id}`}>
                                {txn.type}
                              </Badge>
                            </TableCell>
                            <TableCell data-testid={`text-income-desc-${txn.id}`}>{txn.description || "-"}</TableCell>
                            <TableCell data-testid={`text-income-method-${txn.id}`}>{txn.paymentMethod || "-"}</TableCell>
                            <TableCell className="font-semibold text-green-700 dark:text-green-300" data-testid={`text-income-amount-${txn.id}`}>
                              + Rs. {Number(txn.amount).toLocaleString()}
                            </TableCell>
                            <TableCell>
                              <Badge variant="secondary" className="no-default-active-elevate text-[10px] capitalize" data-testid={`badge-income-status-${txn.id}`}>
                                {txn.status}
                              </Badge>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <Dialog open={incomeDialogOpen} onOpenChange={setIncomeDialogOpen}>
            <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Add Income Entry</DialogTitle>
              </DialogHeader>
              <Form {...incomeForm}>
                <form onSubmit={incomeForm.handleSubmit((data) => createTransactionMutation.mutate(data))} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={incomeForm.control}
                      name="txnId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Transaction ID</FormLabel>
                          <FormControl>
                            <Input data-testid="input-income-txnid" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={incomeForm.control}
                      name="date"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Date</FormLabel>
                          <FormControl>
                            <Input type="date" data-testid="input-income-date" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={incomeForm.control}
                      name="amount"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Amount (Rs.)</FormLabel>
                          <FormControl>
                            <Input type="number" placeholder="0" data-testid="input-income-amount" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={incomeForm.control}
                      name="paymentMethod"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Payment Method</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value || ""}>
                            <FormControl>
                              <SelectTrigger data-testid="select-income-method">
                                <SelectValue placeholder="Select method" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="cash">Cash</SelectItem>
                              <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
                              <SelectItem value="card">Card</SelectItem>
                              <SelectItem value="cheque">Cheque</SelectItem>
                              <SelectItem value="online">Online</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <FormField
                    control={incomeForm.control}
                    name="accountId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Account</FormLabel>
                        <Select
                          onValueChange={(v) => field.onChange(v === "none" ? null : parseInt(v))}
                          value={field.value?.toString() || "none"}
                        >
                          <FormControl>
                            <SelectTrigger data-testid="select-income-account">
                              <SelectValue placeholder="Select account" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="none">None</SelectItem>
                            {(accounts || []).map((a) => (
                              <SelectItem key={a.id} value={a.id.toString()}>
                                {a.code} - {a.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={incomeForm.control}
                    name="reference"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Reference</FormLabel>
                        <FormControl>
                          <Input placeholder="Reference number" data-testid="input-income-reference" {...field} value={field.value || ""} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={incomeForm.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea placeholder="Income description..." data-testid="input-income-description" {...field} value={field.value || ""} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <DialogFooter>
                    <Button type="button" variant="secondary" onClick={() => setIncomeDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button type="submit" disabled={createTransactionMutation.isPending} data-testid="button-save-income">
                      {createTransactionMutation.isPending ? "Saving..." : "Add Income"}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>)}

        {tab === "expense" && (<div className="mt-5">
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <h2 className="text-lg font-semibold" data-testid="text-expense-title">Expense Entries</h2>
              <Button onClick={() => {
                expenseForm.reset({
                  txnId: `EXP-${Date.now()}`,
                  type: "expense",
                  amount: "0",
                  accountId: null,
                  customerId: null,
                  invoiceId: null,
                  paymentMethod: "",
                  reference: "",
                  description: "",
                  date: new Date().toISOString().split("T")[0],
                  status: "completed",
                });
                setExpenseDialogOpen(true);
              }} data-testid="button-add-expense">
                <Plus className="h-4 w-4 mr-1" />
                Add Expense
              </Button>
            </div>

            <Card>
              <CardContent className="p-0">
                {txnLoading ? (
                  <div className="p-5 space-y-3">
                    {[1, 2, 3].map((i) => (
                      <Skeleton key={i} className="h-14 w-full" />
                    ))}
                  </div>
                ) : expenseTransactions.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                    <TrendingDown className="h-12 w-12 mb-3 opacity-30" />
                    <p className="font-medium">No expense entries found</p>
                    <p className="text-sm mt-1">Add your first expense entry</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Txn ID</TableHead>
                          <TableHead>Date</TableHead>
                          <TableHead>Description</TableHead>
                          <TableHead>Method</TableHead>
                          <TableHead>Amount (Rs.)</TableHead>
                          <TableHead>Status</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {expenseTransactions.map((txn) => (
                          <TableRow key={txn.id} data-testid={`row-expense-${txn.id}`}>
                            <TableCell className="font-mono text-xs" data-testid={`text-expense-txnid-${txn.id}`}>{txn.txnId}</TableCell>
                            <TableCell data-testid={`text-expense-date-${txn.id}`}>{txn.date}</TableCell>
                            <TableCell data-testid={`text-expense-desc-${txn.id}`}>{txn.description || "-"}</TableCell>
                            <TableCell data-testid={`text-expense-method-${txn.id}`}>{txn.paymentMethod || "-"}</TableCell>
                            <TableCell className="font-semibold text-red-600 dark:text-red-400" data-testid={`text-expense-amount-${txn.id}`}>
                              - Rs. {Number(txn.amount).toLocaleString()}
                            </TableCell>
                            <TableCell>
                              <Badge variant="secondary" className="no-default-active-elevate text-[10px] capitalize" data-testid={`badge-expense-status-${txn.id}`}>
                                {txn.status}
                              </Badge>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <Dialog open={expenseDialogOpen} onOpenChange={setExpenseDialogOpen}>
            <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Add Expense Entry</DialogTitle>
              </DialogHeader>
              <Form {...expenseForm}>
                <form onSubmit={expenseForm.handleSubmit((data) => createTransactionMutation.mutate(data))} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={expenseForm.control}
                      name="txnId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Transaction ID</FormLabel>
                          <FormControl>
                            <Input data-testid="input-expense-txnid" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={expenseForm.control}
                      name="date"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Date</FormLabel>
                          <FormControl>
                            <Input type="date" data-testid="input-expense-date" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <FormField
                      control={expenseForm.control}
                      name="amount"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Amount (Rs.)</FormLabel>
                          <FormControl>
                            <Input type="number" placeholder="0" data-testid="input-expense-amount" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={expenseForm.control}
                      name="paymentMethod"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Payment Method</FormLabel>
                          <Select onValueChange={field.onChange} value={field.value || ""}>
                            <FormControl>
                              <SelectTrigger data-testid="select-expense-method">
                                <SelectValue placeholder="Select method" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="cash">Cash</SelectItem>
                              <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
                              <SelectItem value="card">Card</SelectItem>
                              <SelectItem value="cheque">Cheque</SelectItem>
                              <SelectItem value="online">Online</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <FormField
                    control={expenseForm.control}
                    name="accountId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Account</FormLabel>
                        <Select
                          onValueChange={(v) => field.onChange(v === "none" ? null : parseInt(v))}
                          value={field.value?.toString() || "none"}
                        >
                          <FormControl>
                            <SelectTrigger data-testid="select-expense-account">
                              <SelectValue placeholder="Select account" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="none">None</SelectItem>
                            {(accounts || []).map((a) => (
                              <SelectItem key={a.id} value={a.id.toString()}>
                                {a.code} - {a.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={expenseForm.control}
                    name="reference"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Reference</FormLabel>
                        <FormControl>
                          <Input placeholder="Reference number" data-testid="input-expense-reference" {...field} value={field.value || ""} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={expenseForm.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea placeholder="Expense description..." data-testid="input-expense-description" {...field} value={field.value || ""} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <DialogFooter>
                    <Button type="button" variant="secondary" onClick={() => setExpenseDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button type="submit" disabled={createTransactionMutation.isPending} data-testid="button-save-expense">
                      {createTransactionMutation.isPending ? "Saving..." : "Add Expense"}
                    </Button>
                  </DialogFooter>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
        </div>)}

        {tab === "budget" && (<div className="mt-5">
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <h2 className="text-lg font-semibold" data-testid="text-budget-title">Budget Allocation</h2>
                <p className="text-sm text-muted-foreground mt-0.5">View allocated budgets and spending per account</p>
              </div>
            </div>

            {isLoading ? (
              <div className="space-y-3">
                {[1, 2, 3].map((i) => (
                  <Skeleton key={i} className="h-24 w-full" />
                ))}
              </div>
            ) : (accounts || []).length === 0 ? (
              <Card>
                <CardContent className="py-12">
                  <div className="flex flex-col items-center justify-center text-muted-foreground">
                    <PiggyBank className="h-12 w-12 mb-3 opacity-30" />
                    <p className="font-medium">No accounts found</p>
                    <p className="text-sm mt-1">Create accounts first to allocate budgets</p>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardContent className="p-0">
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Code</TableHead>
                          <TableHead>Account Name</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Allocated Budget (Rs.)</TableHead>
                          <TableHead>Spent (Rs.)</TableHead>
                          <TableHead>Remaining (Rs.)</TableHead>
                          <TableHead>Usage</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {(accounts || []).map((acc) => {
                          const allocated = Number(acc.balance || 0);
                          const spent = (transactions || [])
                            .filter((t) => t.accountId === acc.id && t.type === "expense")
                            .reduce((sum, t) => sum + Number(t.amount), 0);
                          const remaining = allocated - spent;
                          const usagePercent = allocated > 0 ? Math.min(100, Math.round((spent / allocated) * 100)) : 0;

                          return (
                            <TableRow key={acc.id} data-testid={`row-budget-${acc.id}`}>
                              <TableCell className="font-mono text-xs" data-testid={`text-budget-code-${acc.id}`}>{acc.code}</TableCell>
                              <TableCell className="font-medium" data-testid={`text-budget-name-${acc.id}`}>{acc.name}</TableCell>
                              <TableCell>
                                <Badge variant="secondary" className={`no-default-active-elevate text-[10px] capitalize ${typeConfig[acc.type] || ""}`} data-testid={`badge-budget-type-${acc.id}`}>
                                  {acc.type}
                                </Badge>
                              </TableCell>
                              <TableCell className="font-semibold" data-testid={`text-budget-allocated-${acc.id}`}>
                                Rs. {allocated.toLocaleString()}
                              </TableCell>
                              <TableCell className="text-red-600 dark:text-red-400" data-testid={`text-budget-spent-${acc.id}`}>
                                Rs. {spent.toLocaleString()}
                              </TableCell>
                              <TableCell className={remaining >= 0 ? "text-green-700 dark:text-green-300" : "text-red-600 dark:text-red-400"} data-testid={`text-budget-remaining-${acc.id}`}>
                                Rs. {remaining.toLocaleString()}
                              </TableCell>
                              <TableCell data-testid={`text-budget-usage-${acc.id}`}>
                                <div className="flex items-center gap-2">
                                  <div className="w-16 h-2 rounded-full bg-muted overflow-hidden">
                                    <div
                                      className={`h-full rounded-full ${usagePercent > 90 ? "bg-red-500" : usagePercent > 60 ? "bg-yellow-500" : "bg-green-500"}`}
                                      style={{ width: `${usagePercent}%` }}
                                    />
                                  </div>
                                  <span className="text-xs text-muted-foreground">{usagePercent}%</span>
                                </div>
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>)}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingAccount ? "Edit Account" : "Add Account"}</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="code"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Code</FormLabel>
                      <FormControl>
                        <Input placeholder="1001" data-testid="input-account-code" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Account Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Cash in Hand" data-testid="input-account-name" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Type</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value || "asset"}>
                        <FormControl>
                          <SelectTrigger data-testid="select-account-type">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="asset">Asset</SelectItem>
                          <SelectItem value="liability">Liability</SelectItem>
                          <SelectItem value="income">Income</SelectItem>
                          <SelectItem value="expense">Expense</SelectItem>
                          <SelectItem value="equity">Equity</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="parentId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Parent Account</FormLabel>
                      <Select
                        onValueChange={(v) => field.onChange(v === "none" ? null : parseInt(v))}
                        value={field.value?.toString() || "none"}
                      >
                        <FormControl>
                          <SelectTrigger data-testid="select-account-parent">
                            <SelectValue placeholder="None" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="none">None</SelectItem>
                          {(accounts || [])
                            .filter((a) => !editingAccount || a.id !== editingAccount.id)
                            .map((a) => (
                              <SelectItem key={a.id} value={a.id.toString()}>
                                {a.code} - {a.name}
                              </SelectItem>
                            ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={form.control}
                name="balance"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Balance (Rs.)</FormLabel>
                    <FormControl>
                      <Input type="number" placeholder="0" data-testid="input-account-balance" {...field} value={field.value || "0"} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Account description..." data-testid="input-account-description" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="isActive"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Status</FormLabel>
                    <Select
                      onValueChange={(v) => field.onChange(v === "true")}
                      value={field.value ? "true" : "false"}
                    >
                      <FormControl>
                        <SelectTrigger data-testid="select-account-active">
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="true">Active</SelectItem>
                        <SelectItem value="false">Inactive</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="button" variant="secondary" onClick={() => setDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending} data-testid="button-save-account">
                  {createMutation.isPending || updateMutation.isPending ? "Saving..." : editingAccount ? "Update" : "Create"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}