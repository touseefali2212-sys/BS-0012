import { useState, useRef } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Plus,
  Search,
  MoreHorizontal,
  Edit,
  Trash2,
  Users,
  Phone,
  IdCard,
  Clock,
  Calendar,
  DollarSign,
  Gift,
  Wallet,
  CalendarDays,
  Briefcase,
  Settings,
  UserPlus,
  ChevronRight,
  ChevronLeft,
  GraduationCap,
  Building2,
  CreditCard,
  Info,
  Paperclip,
  Upload,
  X,
  Check,
  Eye,
  Printer,
  ChevronDown,
  Filter,
  Download,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { useTab } from "@/hooks/use-tab";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertEmployeeSchema, type Employee, type InsertEmployee } from "@shared/schema";
import { z } from "zod";

const employeeFormSchema = insertEmployeeSchema.extend({
  empCode: z.string().min(1, "Employee code is required"),
  fullName: z.string().min(2, "Name must be at least 2 characters"),
  phone: z.string().min(10, "Phone number is required"),
  department: z.string().min(1, "Department is required"),
  designation: z.string().min(1, "Designation is required"),
});

export default function HRPage() {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useTab("list");
  const [search, setSearch] = useState("");
  const [departmentFilter, setDepartmentFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
  const [wizardStep, setWizardStep] = useState(1);
  const [qualRows, setQualRows] = useState([{ degree: "", institution: "", year: "", grade: "", major: "" }]);
  const [expRows, setExpRows] = useState([{ company: "", position: "", from: "", to: "", reason: "" }]);
  const [allowRows, setAllowRows] = useState([{ type: "House Rent", amount: "" }]);
  const [deductRows, setDeductRows] = useState([{ type: "Income Tax", amount: "" }]);
  const [profilePicUrl, setProfilePicUrl] = useState("");
  const [docList, setDocList] = useState<{ label: string; url: string }[]>([]);
  const [uploading, setUploading] = useState(false);
  const [pageSize, setPageSize] = useState(25);
  const [currentPage, setCurrentPage] = useState(1);
  const [viewEmployee, setViewEmployee] = useState<Employee | null>(null);
  const picInputRef = useRef<HTMLInputElement>(null);
  const docInputRef = useRef<HTMLInputElement>(null);

  const { data: employees, isLoading } = useQuery<Employee[]>({
    queryKey: ["/api/employees"],
  });

  const form = useForm<InsertEmployee>({
    resolver: zodResolver(employeeFormSchema),
    defaultValues: {
      empCode: "",
      fullName: "",
      email: "",
      phone: "",
      cnic: "",
      department: "engineering",
      designation: "",
      joinDate: new Date().toISOString().split("T")[0],
      salary: "",
      bankAccount: "",
      address: "",
      status: "active",
    },
  });

  const today = new Date().toISOString().split("T")[0];
  const addForm = useForm<InsertEmployee>({
    defaultValues: {
      empCode: "",
      fullName: "",
      email: "",
      phone: "",
      cnic: "",
      department: "engineering",
      designation: "",
      joinDate: today,
      salary: "",
      bankAccount: "",
      address: "",
      status: "active",
      gender: "",
      dateOfBirth: "",
      maritalStatus: "",
      fatherName: "",
      guardianPhone: "",
      bloodGroup: "",
      religion: "",
      nationality: "Pakistani",
      emergencyContact: "",
      emergencyPhone: "",
      city: "",
      country: "Pakistan",
      bankName: "",
      bankBranch: "",
      salaryType: "monthly",
      employmentType: "full_time",
      shift: "morning",
      workLocation: "",
      reportingTo: "",
      probationEndDate: "",
      confirmationDate: "",
      profilePicture: "",
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertEmployee) => {
      const res = await apiRequest("POST", "/api/employees", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/employees"] });
      setDialogOpen(false);
      form.reset();
      addForm.reset();
      setWizardStep(1);
      setQualRows([{ degree: "", institution: "", year: "", grade: "", major: "" }]);
      setExpRows([{ company: "", position: "", from: "", to: "", reason: "" }]);
      setAllowRows([{ type: "House Rent", amount: "" }]);
      setDeductRows([{ type: "Income Tax", amount: "" }]);
      setProfilePicUrl("");
      setDocList([]);
      toast({ title: "Employee created successfully", description: "New employee has been added to the system." });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertEmployee> }) => {
      const res = await apiRequest("PATCH", `/api/employees/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/employees"] });
      setDialogOpen(false);
      setEditingEmployee(null);
      form.reset();
      toast({ title: "Employee updated successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/employees/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/employees"] });
      toast({ title: "Employee deleted successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const openCreate = () => {
    setEditingEmployee(null);
    form.reset({
      empCode: "",
      fullName: "",
      email: "",
      phone: "",
      cnic: "",
      department: "engineering",
      designation: "",
      joinDate: new Date().toISOString().split("T")[0],
      salary: "",
      bankAccount: "",
      address: "",
      status: "active",
    });
    setDialogOpen(true);
  };

  const openEdit = (employee: Employee) => {
    setEditingEmployee(employee);
    form.reset({
      empCode: employee.empCode,
      fullName: employee.fullName,
      email: employee.email || "",
      phone: employee.phone,
      cnic: employee.cnic || "",
      department: employee.department,
      designation: employee.designation,
      joinDate: employee.joinDate || "",
      salary: employee.salary || "",
      bankAccount: employee.bankAccount || "",
      address: employee.address || "",
      status: employee.status,
    });
    setDialogOpen(true);
  };

  const onSubmit = (data: InsertEmployee) => {
    if (editingEmployee) {
      updateMutation.mutate({ id: editingEmployee.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const onAddSubmit = (data: InsertEmployee) => {
    createMutation.mutate(data);
  };

  const wizardStepFields: Record<number, (keyof InsertEmployee)[]> = {
    1: ["fullName", "phone"],
    2: [],
    3: [],
    4: ["empCode", "department", "designation"],
    5: [],
    6: [],
  };

  const handleWizardNext = async () => {
    const fields = wizardStepFields[wizardStep];
    if (fields.length > 0) {
      const valid = await addForm.trigger(fields);
      if (!valid) return;
    }
    setWizardStep(s => Math.min(s + 1, 6));
  };

  const handleWizardPrev = () => setWizardStep(s => Math.max(s - 1, 1));

  const handleWizardSubmit = () => {
    const vals = addForm.getValues();
    createMutation.mutate({
      ...vals,
      qualifications: JSON.stringify(qualRows.filter(r => r.degree || r.institution)),
      experiences: JSON.stringify(expRows.filter(r => r.company || r.position)),
      allowances: JSON.stringify(allowRows.filter(r => r.type && r.amount)),
      deductions: JSON.stringify(deductRows.filter(r => r.type && r.amount)),
      profilePicture: profilePicUrl,
      documents: JSON.stringify(docList),
    });
  };

  const uploadFile = async (file: File, onDone: (url: string) => void) => {
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch("/api/upload/document", {
        method: "POST",
        credentials: "include",
        body: fd,
      });
      const data = await res.json();
      onDone(data.url || "");
    } catch {
      toast({ title: "Upload failed", variant: "destructive" });
    } finally {
      setUploading(false);
    }
  };

  const wizardStepInfo = [
    { label: "Personal Info", icon: Users },
    { label: "Qualification", icon: GraduationCap },
    { label: "Experience", icon: Briefcase },
    { label: "Accounts/Salary", icon: CreditCard },
    { label: "Other Info", icon: Info },
    { label: "Attachments", icon: Paperclip },
  ];

  const filtered = (employees || []).filter((e) => {
    const matchSearch =
      e.fullName.toLowerCase().includes(search.toLowerCase()) ||
      e.empCode.toLowerCase().includes(search.toLowerCase()) ||
      e.phone.includes(search);
    const matchDepartment = departmentFilter === "all" || e.department === departmentFilter;
    const matchStatus = statusFilter === "all" || e.status === statusFilter;
    return matchSearch && matchDepartment && matchStatus;
  });

  const statusColors: Record<string, string> = {
    active: "text-green-700 dark:text-green-300 bg-green-50 dark:bg-green-950",
    on_leave: "text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950",
    terminated: "text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950",
  };

  const departmentLabels: Record<string, string> = {
    engineering: "Engineering",
    support: "Support",
    sales: "Sales",
    finance: "Finance",
    admin: "Admin",
    management: "Management",
  };

  const roleData = [
    { role: "Network Engineer", department: "Engineering", type: "Full-time", count: filtered.filter(e => e.designation === "Network Engineer").length },
    { role: "Support Agent", department: "Support", type: "Full-time", count: filtered.filter(e => e.designation === "Support Agent").length },
    { role: "Sales Executive", department: "Sales", type: "Full-time", count: filtered.filter(e => e.designation === "Sales Executive").length },
    { role: "Finance Officer", department: "Finance", type: "Full-time", count: filtered.filter(e => e.designation === "Finance Officer").length },
    { role: "Admin Assistant", department: "Admin", type: "Full-time", count: filtered.filter(e => e.designation === "Admin Assistant").length },
    { role: "Manager", department: "Management", type: "Full-time", count: filtered.filter(e => e.designation === "Manager").length },
  ];

  const shiftData = [
    { name: "Morning Shift", startTime: "08:00 AM", endTime: "04:00 PM", days: "Mon - Fri" },
    { name: "Evening Shift", startTime: "04:00 PM", endTime: "12:00 AM", days: "Mon - Fri" },
    { name: "Night Shift", startTime: "12:00 AM", endTime: "08:00 AM", days: "Mon - Fri" },
    { name: "Weekend Shift", startTime: "09:00 AM", endTime: "05:00 PM", days: "Sat - Sun" },
  ];

  const renderEmployeeFormFields = (formInstance: typeof form) => (
    <>
      <div className="grid grid-cols-2 gap-4">
        <FormField
          control={formInstance.control}
          name="empCode"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Emp Code</FormLabel>
              <FormControl>
                <Input placeholder="e.g. EMP-001" data-testid="input-emp-code" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={formInstance.control}
          name="designation"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Designation</FormLabel>
              <FormControl>
                <Input placeholder="e.g. Network Engineer" data-testid="input-designation" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
      </div>
      <FormField
        control={formInstance.control}
        name="fullName"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Full Name</FormLabel>
            <FormControl>
              <Input placeholder="Employee name" data-testid="input-full-name" {...field} />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />
      <div className="grid grid-cols-2 gap-4">
        <FormField
          control={formInstance.control}
          name="phone"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Phone</FormLabel>
              <FormControl>
                <Input placeholder="03XX-XXXXXXX" data-testid="input-phone" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={formInstance.control}
          name="email"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Email</FormLabel>
              <FormControl>
                <Input placeholder="email@example.com" data-testid="input-email" {...field} value={field.value || ""} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
      </div>
      <FormField
        control={formInstance.control}
        name="cnic"
        render={({ field }) => (
          <FormItem>
            <FormLabel>CNIC</FormLabel>
            <FormControl>
              <Input placeholder="XXXXX-XXXXXXX-X" data-testid="input-cnic" {...field} value={field.value || ""} />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />
      <div className="grid grid-cols-2 gap-4">
        <FormField
          control={formInstance.control}
          name="department"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Department</FormLabel>
              <Select onValueChange={field.onChange} value={field.value || "engineering"}>
                <FormControl>
                  <SelectTrigger data-testid="select-department">
                    <SelectValue />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="engineering">Engineering</SelectItem>
                  <SelectItem value="support">Support</SelectItem>
                  <SelectItem value="sales">Sales</SelectItem>
                  <SelectItem value="finance">Finance</SelectItem>
                  <SelectItem value="admin">Admin</SelectItem>
                  <SelectItem value="management">Management</SelectItem>
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={formInstance.control}
          name="status"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Status</FormLabel>
              <Select onValueChange={field.onChange} value={field.value || "active"}>
                <FormControl>
                  <SelectTrigger data-testid="select-status">
                    <SelectValue />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="on_leave">On Leave</SelectItem>
                  <SelectItem value="terminated">Terminated</SelectItem>
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <FormField
          control={formInstance.control}
          name="joinDate"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Join Date</FormLabel>
              <FormControl>
                <Input type="date" data-testid="input-join-date" {...field} value={field.value || ""} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        <FormField
          control={formInstance.control}
          name="salary"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Salary (Rs.)</FormLabel>
              <FormControl>
                <Input placeholder="e.g. 50000" data-testid="input-salary" {...field} value={field.value || ""} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
      </div>
      <FormField
        control={formInstance.control}
        name="bankAccount"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Bank Account</FormLabel>
            <FormControl>
              <Input placeholder="Bank account number" data-testid="input-bank-account" {...field} value={field.value || ""} />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />
      <FormField
        control={formInstance.control}
        name="address"
        render={({ field }) => (
          <FormItem>
            <FormLabel>Address</FormLabel>
            <FormControl>
              <Textarea placeholder="Full address" data-testid="input-address" {...field} value={field.value || ""} />
            </FormControl>
            <FormMessage />
          </FormItem>
        )}
      />
    </>
  );

  const emptyState = (icon: React.ReactNode, title: string, description: string) => (
    <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
      <div className="mb-4 opacity-30">{icon}</div>
      <p className="font-medium text-base">{title}</p>
      <p className="text-sm mt-1">{description}</p>
    </div>
  );

  return (
    <div className="p-6 space-y-6 max-w-[1400px] mx-auto">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight" data-testid="text-hr-title">HR & Payroll</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Manage employees and payroll</p>
        </div>
      </div>

      {activeTab === "add" && (
        <div className="mt-5" data-testid="tab-content-add">
          <Card className="max-w-4xl mx-auto shadow-md">
            <CardHeader className="border-b pb-4">
              <CardTitle className="flex items-center gap-2 text-lg">
                <UserPlus className="h-5 w-5 text-primary" />
                ADD NEW EMPLOYEE
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between mb-8 relative">
                <div className="absolute top-5 left-0 right-0 h-0.5 bg-border z-0" />
                {wizardStepInfo.map(({ label, icon: Icon }, idx) => {
                  const step = idx + 1;
                  const done = wizardStep > step;
                  const active = wizardStep === step;
                  return (
                    <div key={step} className="flex flex-col items-center gap-1.5 z-10 flex-1">
                      <button
                        type="button"
                        onClick={() => setWizardStep(step)}
                        className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm border-2 transition-all ${
                          done ? "bg-primary border-primary text-primary-foreground" :
                          active ? "bg-primary border-primary text-primary-foreground ring-4 ring-primary/20" :
                          "bg-background border-border text-muted-foreground"
                        }`}
                        data-testid={`wizard-step-${step}`}
                      >
                        {done ? <Check className="h-4 w-4" /> : step}
                      </button>
                      <span className={`text-[10px] font-medium text-center leading-tight hidden sm:block ${active ? "text-primary" : done ? "text-primary/70" : "text-muted-foreground"}`}>
                        {label}
                      </span>
                    </div>
                  );
                })}
              </div>

              <Form {...addForm}>
                <div className="min-h-[360px]">

                  {wizardStep === 1 && (
                    <div className="space-y-4 animate-in fade-in-0" data-testid="wizard-step-content-1">
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                        <FormField control={addForm.control} name="fullName" render={({ field }) => (
                          <FormItem className="lg:col-span-2">
                            <FormLabel>Full Name <span className="text-destructive">*</span></FormLabel>
                            <FormControl><Input placeholder="e.g. Muhammad Ali" data-testid="input-wizard-fullname" {...field} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                        <FormField control={addForm.control} name="gender" render={({ field }) => (
                          <FormItem>
                            <FormLabel>Gender</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value || ""}>
                              <FormControl><SelectTrigger data-testid="select-wizard-gender"><SelectValue placeholder="Select" /></SelectTrigger></FormControl>
                              <SelectContent>
                                <SelectItem value="male">Male</SelectItem>
                                <SelectItem value="female">Female</SelectItem>
                                <SelectItem value="other">Other</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )} />
                        <FormField control={addForm.control} name="dateOfBirth" render={({ field }) => (
                          <FormItem>
                            <FormLabel>Date of Birth</FormLabel>
                            <FormControl><Input type="date" data-testid="input-wizard-dob" {...field} value={field.value || ""} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                        <FormField control={addForm.control} name="maritalStatus" render={({ field }) => (
                          <FormItem>
                            <FormLabel>Marital Status</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value || ""}>
                              <FormControl><SelectTrigger data-testid="select-wizard-marital"><SelectValue placeholder="Select" /></SelectTrigger></FormControl>
                              <SelectContent>
                                <SelectItem value="single">Single</SelectItem>
                                <SelectItem value="married">Married</SelectItem>
                                <SelectItem value="divorced">Divorced</SelectItem>
                                <SelectItem value="widowed">Widowed</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )} />
                        <FormField control={addForm.control} name="fatherName" render={({ field }) => (
                          <FormItem className="lg:col-span-2">
                            <FormLabel>Father's Name</FormLabel>
                            <FormControl><Input placeholder="Father's full name" data-testid="input-wizard-father" {...field} value={field.value || ""} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                        <FormField control={addForm.control} name="email" render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email</FormLabel>
                            <FormControl><Input type="email" placeholder="email@company.com" data-testid="input-wizard-email" {...field} value={field.value || ""} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                        <FormField control={addForm.control} name="cnic" render={({ field }) => (
                          <FormItem>
                            <FormLabel>CNIC / NIC</FormLabel>
                            <FormControl><Input placeholder="35201-XXXXXXX-X" data-testid="input-wizard-cnic" {...field} value={field.value || ""} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                        <FormField control={addForm.control} name="phone" render={({ field }) => (
                          <FormItem>
                            <FormLabel>Mobile No <span className="text-destructive">*</span></FormLabel>
                            <FormControl><Input placeholder="03XX-XXXXXXX" data-testid="input-wizard-phone" {...field} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                        <FormField control={addForm.control} name="guardianPhone" render={({ field }) => (
                          <FormItem>
                            <FormLabel>Guardian Mobile No</FormLabel>
                            <FormControl><Input placeholder="03XX-XXXXXXX" data-testid="input-wizard-guardian-phone" {...field} value={field.value || ""} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                      </div>
                      <FormField control={addForm.control} name="address" render={({ field }) => (
                        <FormItem>
                          <FormLabel>Address</FormLabel>
                          <FormControl><Input placeholder="Full residential address" data-testid="input-wizard-address" {...field} value={field.value || ""} /></FormControl>
                          <FormMessage />
                        </FormItem>
                      )} />
                      <div className="grid grid-cols-2 gap-3">
                        <FormField control={addForm.control} name="city" render={({ field }) => (
                          <FormItem>
                            <FormLabel>City</FormLabel>
                            <FormControl><Input placeholder="e.g. Lahore" data-testid="input-wizard-city" {...field} value={field.value || ""} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                        <FormField control={addForm.control} name="country" render={({ field }) => (
                          <FormItem>
                            <FormLabel>Country</FormLabel>
                            <FormControl><Input placeholder="e.g. Pakistan" data-testid="input-wizard-country" {...field} value={field.value || ""} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                      </div>
                    </div>
                  )}

                  {wizardStep === 2 && (
                    <div className="space-y-4 animate-in fade-in-0" data-testid="wizard-step-content-2">
                      <p className="text-sm text-muted-foreground">Add educational qualifications of the employee.</p>
                      <div className="space-y-3">
                        {qualRows.map((row, i) => (
                          <div key={i} className="grid grid-cols-5 gap-2 items-start p-3 rounded-lg border border-border bg-muted/20" data-testid={`qual-row-${i}`}>
                            <div>
                              <label className="text-xs font-medium text-muted-foreground">Degree / Certificate</label>
                              <Input value={row.degree} onChange={e => setQualRows(r => r.map((x,j) => j===i ? {...x, degree: e.target.value} : x))} placeholder="BSc, MSc, B.Com..." className="mt-1 text-sm" data-testid={`input-qual-degree-${i}`} />
                            </div>
                            <div className="col-span-2">
                              <label className="text-xs font-medium text-muted-foreground">Institution / University</label>
                              <Input value={row.institution} onChange={e => setQualRows(r => r.map((x,j) => j===i ? {...x, institution: e.target.value} : x))} placeholder="University / College name" className="mt-1 text-sm" data-testid={`input-qual-institution-${i}`} />
                            </div>
                            <div>
                              <label className="text-xs font-medium text-muted-foreground">Passing Year</label>
                              <Input value={row.year} onChange={e => setQualRows(r => r.map((x,j) => j===i ? {...x, year: e.target.value} : x))} placeholder="2020" className="mt-1 text-sm" data-testid={`input-qual-year-${i}`} />
                            </div>
                            <div className="flex gap-1.5 items-end">
                              <div className="flex-1">
                                <label className="text-xs font-medium text-muted-foreground">Grade / CGPA</label>
                                <Input value={row.grade} onChange={e => setQualRows(r => r.map((x,j) => j===i ? {...x, grade: e.target.value} : x))} placeholder="A / 3.8" className="mt-1 text-sm" data-testid={`input-qual-grade-${i}`} />
                              </div>
                              {qualRows.length > 1 && (
                                <Button type="button" variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive mt-5" onClick={() => setQualRows(r => r.filter((_,j) => j!==i))} data-testid={`button-remove-qual-${i}`}><X className="h-3.5 w-3.5" /></Button>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                      <Button type="button" variant="outline" size="sm" className="gap-1.5" onClick={() => setQualRows(r => [...r, { degree: "", institution: "", year: "", grade: "", major: "" }])} data-testid="button-add-qual">
                        <Plus className="h-3.5 w-3.5" /> Add Another Qualification
                      </Button>
                    </div>
                  )}

                  {wizardStep === 3 && (
                    <div className="space-y-4 animate-in fade-in-0" data-testid="wizard-step-content-3">
                      <p className="text-sm text-muted-foreground">Add previous work experience of the employee.</p>
                      <div className="space-y-3">
                        {expRows.map((row, i) => (
                          <div key={i} className="grid grid-cols-5 gap-2 items-start p-3 rounded-lg border border-border bg-muted/20" data-testid={`exp-row-${i}`}>
                            <div className="col-span-2">
                              <label className="text-xs font-medium text-muted-foreground">Company / Organization</label>
                              <Input value={row.company} onChange={e => setExpRows(r => r.map((x,j) => j===i ? {...x, company: e.target.value} : x))} placeholder="Company name" className="mt-1 text-sm" data-testid={`input-exp-company-${i}`} />
                            </div>
                            <div>
                              <label className="text-xs font-medium text-muted-foreground">Position / Designation</label>
                              <Input value={row.position} onChange={e => setExpRows(r => r.map((x,j) => j===i ? {...x, position: e.target.value} : x))} placeholder="Job title" className="mt-1 text-sm" data-testid={`input-exp-position-${i}`} />
                            </div>
                            <div>
                              <label className="text-xs font-medium text-muted-foreground">From — To</label>
                              <div className="flex gap-1 mt-1">
                                <Input value={row.from} onChange={e => setExpRows(r => r.map((x,j) => j===i ? {...x, from: e.target.value} : x))} placeholder="2020" className="text-sm" data-testid={`input-exp-from-${i}`} />
                                <Input value={row.to} onChange={e => setExpRows(r => r.map((x,j) => j===i ? {...x, to: e.target.value} : x))} placeholder="2023" className="text-sm" data-testid={`input-exp-to-${i}`} />
                              </div>
                            </div>
                            <div className="flex gap-1.5 items-end">
                              <div className="flex-1">
                                <label className="text-xs font-medium text-muted-foreground">Reason for Leaving</label>
                                <Input value={row.reason} onChange={e => setExpRows(r => r.map((x,j) => j===i ? {...x, reason: e.target.value} : x))} placeholder="Resign / Better opp." className="mt-1 text-sm" data-testid={`input-exp-reason-${i}`} />
                              </div>
                              {expRows.length > 1 && (
                                <Button type="button" variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive mt-5" onClick={() => setExpRows(r => r.filter((_,j) => j!==i))} data-testid={`button-remove-exp-${i}`}><X className="h-3.5 w-3.5" /></Button>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                      <Button type="button" variant="outline" size="sm" className="gap-1.5" onClick={() => setExpRows(r => [...r, { company: "", position: "", from: "", to: "", reason: "" }])} data-testid="button-add-exp">
                        <Plus className="h-3.5 w-3.5" /> Add Another Experience
                      </Button>
                    </div>
                  )}

                  {wizardStep === 4 && (
                    <div className="space-y-4 animate-in fade-in-0" data-testid="wizard-step-content-4">
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                        <FormField control={addForm.control} name="empCode" render={({ field }) => (
                          <FormItem>
                            <FormLabel>Emp Code <span className="text-destructive">*</span></FormLabel>
                            <FormControl><Input placeholder="EMP-001" data-testid="input-wizard-empcode" {...field} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                        <FormField control={addForm.control} name="department" render={({ field }) => (
                          <FormItem>
                            <FormLabel>Department <span className="text-destructive">*</span></FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl><SelectTrigger data-testid="select-wizard-dept"><SelectValue /></SelectTrigger></FormControl>
                              <SelectContent>
                                {["engineering","support","sales","finance","admin","management","hr","it","operations"].map(d => (
                                  <SelectItem key={d} value={d} className="capitalize">{d.charAt(0).toUpperCase()+d.slice(1)}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )} />
                        <FormField control={addForm.control} name="designation" render={({ field }) => (
                          <FormItem>
                            <FormLabel>Designation <span className="text-destructive">*</span></FormLabel>
                            <FormControl><Input placeholder="e.g. Network Engineer" data-testid="input-wizard-designation" {...field} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                        <FormField control={addForm.control} name="employmentType" render={({ field }) => (
                          <FormItem>
                            <FormLabel>Employment Type</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value || "full_time"}>
                              <FormControl><SelectTrigger data-testid="select-wizard-emptype"><SelectValue /></SelectTrigger></FormControl>
                              <SelectContent>
                                <SelectItem value="full_time">Full-Time</SelectItem>
                                <SelectItem value="part_time">Part-Time</SelectItem>
                                <SelectItem value="contract">Contract</SelectItem>
                                <SelectItem value="intern">Intern</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )} />
                        <FormField control={addForm.control} name="joinDate" render={({ field }) => (
                          <FormItem>
                            <FormLabel>Join Date</FormLabel>
                            <FormControl><Input type="date" data-testid="input-wizard-joindate" {...field} value={field.value || ""} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                        <FormField control={addForm.control} name="shift" render={({ field }) => (
                          <FormItem>
                            <FormLabel>Shift</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value || "morning"}>
                              <FormControl><SelectTrigger data-testid="select-wizard-shift"><SelectValue /></SelectTrigger></FormControl>
                              <SelectContent>
                                <SelectItem value="morning">Morning (8AM–4PM)</SelectItem>
                                <SelectItem value="evening">Evening (4PM–12AM)</SelectItem>
                                <SelectItem value="night">Night (12AM–8AM)</SelectItem>
                                <SelectItem value="flexible">Flexible</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )} />
                        <FormField control={addForm.control} name="workLocation" render={({ field }) => (
                          <FormItem>
                            <FormLabel>Work Location</FormLabel>
                            <FormControl><Input placeholder="Office / Remote / Branch" data-testid="input-wizard-worklocation" {...field} value={field.value || ""} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                        <FormField control={addForm.control} name="reportingTo" render={({ field }) => (
                          <FormItem>
                            <FormLabel>Reporting To</FormLabel>
                            <FormControl><Input placeholder="Manager / HOD name" data-testid="input-wizard-reportingto" {...field} value={field.value || ""} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                        <FormField control={addForm.control} name="salaryType" render={({ field }) => (
                          <FormItem>
                            <FormLabel>Salary Type</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value || "monthly"}>
                              <FormControl><SelectTrigger data-testid="select-wizard-saltype"><SelectValue /></SelectTrigger></FormControl>
                              <SelectContent>
                                <SelectItem value="monthly">Monthly</SelectItem>
                                <SelectItem value="daily">Daily</SelectItem>
                                <SelectItem value="hourly">Hourly</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )} />
                        <FormField control={addForm.control} name="salary" render={({ field }) => (
                          <FormItem>
                            <FormLabel>Basic Salary (Rs.)</FormLabel>
                            <FormControl><Input type="number" placeholder="e.g. 50000" data-testid="input-wizard-salary" {...field} value={field.value || ""} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                        <FormField control={addForm.control} name="bankName" render={({ field }) => (
                          <FormItem>
                            <FormLabel>Bank Name</FormLabel>
                            <FormControl><Input placeholder="HBL / MCB / UBL..." data-testid="input-wizard-bankname" {...field} value={field.value || ""} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                        <FormField control={addForm.control} name="bankBranch" render={({ field }) => (
                          <FormItem>
                            <FormLabel>Bank Branch</FormLabel>
                            <FormControl><Input placeholder="Branch name" data-testid="input-wizard-bankbranch" {...field} value={field.value || ""} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                        <FormField control={addForm.control} name="bankAccount" render={({ field }) => (
                          <FormItem className="sm:col-span-2">
                            <FormLabel>Bank Account Number</FormLabel>
                            <FormControl><Input placeholder="Account number / IBAN" data-testid="input-wizard-bankaccount" {...field} value={field.value || ""} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Allowances</p>
                          {allowRows.map((row, i) => (
                            <div key={i} className="flex gap-2 items-center" data-testid={`allow-row-${i}`}>
                              <Input value={row.type} onChange={e => setAllowRows(r => r.map((x,j) => j===i ? {...x, type: e.target.value} : x))} placeholder="Type (e.g. HRA)" className="text-sm" data-testid={`input-allow-type-${i}`} />
                              <Input value={row.amount} onChange={e => setAllowRows(r => r.map((x,j) => j===i ? {...x, amount: e.target.value} : x))} placeholder="Rs." type="number" className="text-sm w-28" data-testid={`input-allow-amount-${i}`} />
                              {allowRows.length > 1 && <Button type="button" variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => setAllowRows(r => r.filter((_,j)=>j!==i))} data-testid={`btn-rm-allow-${i}`}><X className="h-3 w-3" /></Button>}
                            </div>
                          ))}
                          <Button type="button" variant="outline" size="sm" className="gap-1 text-xs h-7" onClick={() => setAllowRows(r => [...r, { type: "", amount: "" }])} data-testid="button-add-allow"><Plus className="h-3 w-3" /> Add</Button>
                        </div>
                        <div className="space-y-2">
                          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Deductions</p>
                          {deductRows.map((row, i) => (
                            <div key={i} className="flex gap-2 items-center" data-testid={`deduct-row-${i}`}>
                              <Input value={row.type} onChange={e => setDeductRows(r => r.map((x,j) => j===i ? {...x, type: e.target.value} : x))} placeholder="Type (e.g. Tax)" className="text-sm" data-testid={`input-deduct-type-${i}`} />
                              <Input value={row.amount} onChange={e => setDeductRows(r => r.map((x,j) => j===i ? {...x, amount: e.target.value} : x))} placeholder="Rs." type="number" className="text-sm w-28" data-testid={`input-deduct-amount-${i}`} />
                              {deductRows.length > 1 && <Button type="button" variant="ghost" size="icon" className="h-7 w-7 text-destructive" onClick={() => setDeductRows(r => r.filter((_,j)=>j!==i))} data-testid={`btn-rm-deduct-${i}`}><X className="h-3 w-3" /></Button>}
                            </div>
                          ))}
                          <Button type="button" variant="outline" size="sm" className="gap-1 text-xs h-7" onClick={() => setDeductRows(r => [...r, { type: "", amount: "" }])} data-testid="button-add-deduct"><Plus className="h-3 w-3" /> Add</Button>
                        </div>
                      </div>
                    </div>
                  )}

                  {wizardStep === 5 && (
                    <div className="space-y-4 animate-in fade-in-0" data-testid="wizard-step-content-5">
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                        <FormField control={addForm.control} name="bloodGroup" render={({ field }) => (
                          <FormItem>
                            <FormLabel>Blood Group</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value || ""}>
                              <FormControl><SelectTrigger data-testid="select-wizard-bloodgroup"><SelectValue placeholder="Select" /></SelectTrigger></FormControl>
                              <SelectContent>
                                {["A+","A-","B+","B-","O+","O-","AB+","AB-"].map(g => <SelectItem key={g} value={g}>{g}</SelectItem>)}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )} />
                        <FormField control={addForm.control} name="religion" render={({ field }) => (
                          <FormItem>
                            <FormLabel>Religion</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value || ""}>
                              <FormControl><SelectTrigger data-testid="select-wizard-religion"><SelectValue placeholder="Select" /></SelectTrigger></FormControl>
                              <SelectContent>
                                <SelectItem value="islam">Islam</SelectItem>
                                <SelectItem value="christianity">Christianity</SelectItem>
                                <SelectItem value="hinduism">Hinduism</SelectItem>
                                <SelectItem value="other">Other</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )} />
                        <FormField control={addForm.control} name="nationality" render={({ field }) => (
                          <FormItem>
                            <FormLabel>Nationality</FormLabel>
                            <FormControl><Input placeholder="e.g. Pakistani" data-testid="input-wizard-nationality" {...field} value={field.value || ""} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                        <FormField control={addForm.control} name="emergencyContact" render={({ field }) => (
                          <FormItem>
                            <FormLabel>Emergency Contact Name</FormLabel>
                            <FormControl><Input placeholder="Name" data-testid="input-wizard-emg-name" {...field} value={field.value || ""} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                        <FormField control={addForm.control} name="emergencyPhone" render={({ field }) => (
                          <FormItem>
                            <FormLabel>Emergency Phone</FormLabel>
                            <FormControl><Input placeholder="03XX-XXXXXXX" data-testid="input-wizard-emg-phone" {...field} value={field.value || ""} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                        <FormField control={addForm.control} name="status" render={({ field }) => (
                          <FormItem>
                            <FormLabel>Status</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl><SelectTrigger data-testid="select-wizard-status"><SelectValue /></SelectTrigger></FormControl>
                              <SelectContent>
                                <SelectItem value="active">Active</SelectItem>
                                <SelectItem value="on_leave">On Leave</SelectItem>
                                <SelectItem value="terminated">Terminated</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )} />
                        <FormField control={addForm.control} name="probationEndDate" render={({ field }) => (
                          <FormItem>
                            <FormLabel>Probation End Date</FormLabel>
                            <FormControl><Input type="date" data-testid="input-wizard-probation" {...field} value={field.value || ""} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                        <FormField control={addForm.control} name="confirmationDate" render={({ field }) => (
                          <FormItem>
                            <FormLabel>Confirmation Date</FormLabel>
                            <FormControl><Input type="date" data-testid="input-wizard-confirmation" {...field} value={field.value || ""} /></FormControl>
                            <FormMessage />
                          </FormItem>
                        )} />
                      </div>
                    </div>
                  )}

                  {wizardStep === 6 && (
                    <div className="space-y-5 animate-in fade-in-0" data-testid="wizard-step-content-6">
                      <div className="space-y-2">
                        <p className="text-sm font-medium">Profile Picture</p>
                        <div className="flex items-center gap-4">
                          {profilePicUrl ? (
                            <div className="relative w-20 h-20">
                              <img src={profilePicUrl} alt="Profile" className="w-20 h-20 rounded-full object-cover border-2 border-primary" />
                              <button type="button" onClick={() => setProfilePicUrl("")} className="absolute -top-1 -right-1 w-5 h-5 bg-destructive rounded-full flex items-center justify-center text-white" data-testid="button-remove-pic"><X className="h-3 w-3" /></button>
                            </div>
                          ) : (
                            <div className="w-20 h-20 rounded-full border-2 border-dashed border-border flex items-center justify-center bg-muted/30 cursor-pointer" onClick={() => picInputRef.current?.click()} data-testid="drop-profile-pic">
                              <Upload className="h-6 w-6 text-muted-foreground" />
                            </div>
                          )}
                          <div>
                            <Button type="button" variant="outline" size="sm" className="gap-1.5" onClick={() => picInputRef.current?.click()} disabled={uploading} data-testid="button-upload-pic">
                              <Upload className="h-3.5 w-3.5" /> {uploading ? "Uploading..." : "Upload Photo"}
                            </Button>
                            <p className="text-[11px] text-muted-foreground mt-1">JPG, PNG up to 5MB. Square photos recommended.</p>
                          </div>
                          <input ref={picInputRef} type="file" accept="image/*" className="hidden" onChange={e => {
                            const f = e.target.files?.[0];
                            if (f) uploadFile(f, url => setProfilePicUrl(url));
                            e.target.value = "";
                          }} data-testid="input-pic-file" />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <p className="text-sm font-medium">Documents</p>
                        <p className="text-xs text-muted-foreground">Upload CNIC copy, degree certificates, experience letters, and other required documents.</p>
                        {docList.map((doc, i) => (
                          <div key={i} className="flex items-center gap-2 p-2 rounded-md border border-border bg-muted/20" data-testid={`doc-row-${i}`}>
                            <Paperclip className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                            <span className="text-sm flex-1 truncate">{doc.label}</span>
                            <a href={doc.url} target="_blank" rel="noopener noreferrer" className="text-xs text-primary underline">View</a>
                            <button type="button" onClick={() => setDocList(d => d.filter((_,j) => j!==i))} className="text-destructive" data-testid={`btn-remove-doc-${i}`}><X className="h-3.5 w-3.5" /></button>
                          </div>
                        ))}
                        <Button type="button" variant="outline" size="sm" className="gap-1.5" onClick={() => docInputRef.current?.click()} disabled={uploading} data-testid="button-upload-doc">
                          <Upload className="h-3.5 w-3.5" /> {uploading ? "Uploading..." : "Upload Document"}
                        </Button>
                        <input ref={docInputRef} type="file" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx" className="hidden" onChange={e => {
                          const f = e.target.files?.[0];
                          if (f) uploadFile(f, url => setDocList(d => [...d, { label: f.name, url }]));
                          e.target.value = "";
                        }} data-testid="input-doc-file" />
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-between pt-5 border-t border-border mt-6">
                  <Button type="button" variant="outline" onClick={handleWizardPrev} disabled={wizardStep === 1} className="gap-1.5" data-testid="button-wizard-prev">
                    <ChevronLeft className="h-4 w-4" /> Previous
                  </Button>
                  <span className="text-xs text-muted-foreground">Step {wizardStep} of 6</span>
                  {wizardStep < 6 ? (
                    <Button type="button" onClick={handleWizardNext} className="gap-1.5" data-testid="button-wizard-next">
                      Next <ChevronRight className="h-4 w-4" />
                    </Button>
                  ) : (
                    <Button type="button" onClick={handleWizardSubmit} disabled={createMutation.isPending} className="gap-1.5 bg-green-600 hover:bg-green-700 text-white" data-testid="button-wizard-submit">
                      {createMutation.isPending ? "Saving..." : <><Check className="h-4 w-4" /> Save Employee</>}
                    </Button>
                  )}
                </div>
              </Form>
            </CardContent>
          </Card>
        </div>
      )}

      {activeTab === "list" && (
        <div className="mt-5 space-y-4" data-testid="tab-content-list">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div>
              <h2 className="text-base font-semibold flex items-center gap-2">
                <Users className="h-4 w-4 text-primary" />
                Employee List
                <span className="text-xs text-muted-foreground font-normal">— View All Employees</span>
              </h2>
              <p className="text-xs text-muted-foreground mt-0.5">HR &amp; Payroll &rsaquo; Employee List</p>
            </div>
            <div className="flex gap-2 flex-wrap">
              <Button variant="outline" size="sm" className="gap-1.5 h-8 text-xs" onClick={() => window.print()} data-testid="button-print-employees">
                <Printer className="h-3.5 w-3.5" /> Print
              </Button>
              <Button variant="outline" size="sm" className="gap-1.5 h-8 text-xs" data-testid="button-export-employees">
                <Download className="h-3.5 w-3.5" /> Export CSV
              </Button>
              <Button size="sm" className="gap-1.5 h-8 text-xs" onClick={() => setActiveTab("add")} data-testid="button-add-employee-nav">
                <Plus className="h-3.5 w-3.5" /> Add Employee
              </Button>
            </div>
          </div>

          <Card className="shadow-sm">
            <CardContent className="p-0">
              <div className="p-4 border-b flex flex-wrap items-end gap-4">
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-1.5">Status</p>
                  <Select value={statusFilter} onValueChange={v => { setStatusFilter(v); setCurrentPage(1); }}>
                    <SelectTrigger className="w-[140px] h-9 text-sm" data-testid="select-status-filter">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Status</SelectItem>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="on_leave">On Leave</SelectItem>
                      <SelectItem value="terminated">Terminated</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground mb-1.5">Department</p>
                  <Select value={departmentFilter} onValueChange={v => { setDepartmentFilter(v); setCurrentPage(1); }}>
                    <SelectTrigger className="w-[160px] h-9 text-sm" data-testid="select-department-filter">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Departments</SelectItem>
                      {["engineering","support","sales","finance","admin","management","hr","it","operations"].map(d => (
                        <SelectItem key={d} value={d} className="capitalize">{d.charAt(0).toUpperCase()+d.slice(1)}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex-1" />
                <div className="flex items-center gap-2 flex-wrap">
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs text-muted-foreground font-medium">SHOW</span>
                    <Select value={String(pageSize)} onValueChange={v => { setPageSize(Number(v)); setCurrentPage(1); }}>
                      <SelectTrigger className="w-[70px] h-8 text-xs" data-testid="select-page-size">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="10">10</SelectItem>
                        <SelectItem value="25">25</SelectItem>
                        <SelectItem value="50">50</SelectItem>
                        <SelectItem value="100">100</SelectItem>
                      </SelectContent>
                    </Select>
                    <span className="text-xs text-muted-foreground font-medium">ENTRIES</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs text-muted-foreground font-medium">SEARCH:</span>
                    <div className="relative">
                      <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                      <Input
                        placeholder="Name, code, phone..."
                        value={search}
                        onChange={(e) => { setSearch(e.target.value); setCurrentPage(1); }}
                        className="pl-8 h-8 text-xs w-[200px]"
                        data-testid="input-search-employees"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {isLoading ? (
                <div className="p-5 space-y-2">
                  {[1,2,3,4,5].map(i => <Skeleton key={i} className="h-11 w-full" />)}
                </div>
              ) : filtered.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
                  <Users className="h-12 w-12 mb-3 opacity-20" />
                  <p className="font-medium">No employees found</p>
                  <p className="text-sm mt-1">Try adjusting your filters or add a new employee</p>
                </div>
              ) : (
                <>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow className="bg-[#1e293b] hover:bg-[#1e293b] dark:bg-slate-800">
                          <TableHead className="text-white font-semibold text-xs py-3 w-10">#</TableHead>
                          <TableHead className="text-white font-semibold text-xs py-3">Name</TableHead>
                          <TableHead className="text-white font-semibold text-xs py-3">ID</TableHead>
                          <TableHead className="text-white font-semibold text-xs py-3">Mobile No.</TableHead>
                          <TableHead className="text-white font-semibold text-xs py-3">Email / CNIC</TableHead>
                          <TableHead className="text-white font-semibold text-xs py-3">Department</TableHead>
                          <TableHead className="text-white font-semibold text-xs py-3">Designation</TableHead>
                          <TableHead className="text-white font-semibold text-xs py-3 text-right">Salary (Rs.)</TableHead>
                          <TableHead className="text-white font-semibold text-xs py-3 text-right">Balance (Rs.)</TableHead>
                          <TableHead className="text-white font-semibold text-xs py-3 text-center">Status</TableHead>
                          <TableHead className="text-white font-semibold text-xs py-3 text-center">Action</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize).map((employee, idx) => (
                          <TableRow
                            key={employee.id}
                            className="border-b border-border hover:bg-muted/40 transition-colors"
                            data-testid={`row-employee-${employee.id}`}
                          >
                            <TableCell className="text-xs text-muted-foreground py-2.5">
                              {(currentPage - 1) * pageSize + idx + 1}
                            </TableCell>
                            <TableCell className="py-2.5">
                              <div className="flex items-center gap-2.5">
                                {(employee as any).profilePicture ? (
                                  <img src={(employee as any).profilePicture} alt="" className="w-8 h-8 rounded-full object-cover flex-shrink-0 border border-border" />
                                ) : (
                                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 border border-primary/20">
                                    <span className="text-[10px] font-bold text-primary">{employee.fullName.charAt(0).toUpperCase()}</span>
                                  </div>
                                )}
                                <div>
                                  <p className="font-semibold text-sm leading-tight">{employee.fullName}</p>
                                  <p className="text-[10px] text-muted-foreground">{employee.joinDate ? `Joined ${employee.joinDate}` : ""}</p>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell className="py-2.5">
                              <span className="font-mono text-xs bg-muted px-2 py-0.5 rounded border border-border">{employee.empCode}</span>
                            </TableCell>
                            <TableCell className="py-2.5 text-sm">{employee.phone}</TableCell>
                            <TableCell className="py-2.5">
                              <p className="text-xs">{employee.email || "—"}</p>
                              <p className="text-[10px] text-muted-foreground">{employee.cnic || ""}</p>
                            </TableCell>
                            <TableCell className="py-2.5">
                              <Badge variant="secondary" className="no-default-active-elevate text-[10px] capitalize font-medium">
                                {departmentLabels[employee.department] || employee.department}
                              </Badge>
                            </TableCell>
                            <TableCell className="py-2.5 text-sm">{employee.designation}</TableCell>
                            <TableCell className="py-2.5 text-sm text-right font-medium tabular-nums">
                              {employee.salary ? Number(employee.salary).toLocaleString() : "—"}
                            </TableCell>
                            <TableCell className="py-2.5 text-sm text-right tabular-nums text-muted-foreground">
                              {employee.salary ? Number(employee.salary).toLocaleString() : "—"}
                            </TableCell>
                            <TableCell className="py-2.5 text-center">
                              <Badge
                                variant="secondary"
                                className={`no-default-active-elevate text-[10px] capitalize ${statusColors[employee.status] || ""}`}
                              >
                                {employee.status.replace("_", " ")}
                              </Badge>
                            </TableCell>
                            <TableCell className="py-2.5">
                              <div className="flex items-center justify-center gap-0.5">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-7 w-7 text-blue-500 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950"
                                  onClick={() => navigate(`/hr/employees/${employee.id}`)}
                                  data-testid={`button-view-${employee.id}`}
                                  title="View Profile"
                                >
                                  <Eye className="h-3.5 w-3.5" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-7 w-7 text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50 dark:hover:bg-emerald-950"
                                  onClick={() => openEdit(employee)}
                                  data-testid={`button-edit-${employee.id}`}
                                  title="Edit"
                                >
                                  <Edit className="h-3.5 w-3.5" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-7 w-7 text-slate-500 hover:text-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800"
                                  onClick={() => window.print()}
                                  data-testid={`button-print-${employee.id}`}
                                  title="Print"
                                >
                                  <Printer className="h-3.5 w-3.5" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-7 w-7 text-red-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950"
                                  onClick={() => {
                                    if (confirm(`Delete ${employee.fullName}?`)) {
                                      deleteMutation.mutate(employee.id);
                                    }
                                  }}
                                  data-testid={`button-delete-${employee.id}`}
                                  title="Delete"
                                >
                                  <Trash2 className="h-3.5 w-3.5" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                  <div className="flex items-center justify-between px-4 py-3 border-t text-xs text-muted-foreground">
                    <span>
                      Showing {Math.min((currentPage - 1) * pageSize + 1, filtered.length)}–{Math.min(currentPage * pageSize, filtered.length)} of {filtered.length} employees
                    </span>
                    <div className="flex items-center gap-1">
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-7 px-2 text-xs"
                        disabled={currentPage === 1}
                        onClick={() => setCurrentPage(p => p - 1)}
                        data-testid="button-prev-page"
                      >
                        <ChevronLeft className="h-3.5 w-3.5" /> Prev
                      </Button>
                      {Array.from({ length: Math.ceil(filtered.length / pageSize) }, (_, i) => i + 1)
                        .filter(p => p === 1 || p === Math.ceil(filtered.length / pageSize) || Math.abs(p - currentPage) <= 1)
                        .map((p, i, arr) => (
                          <>
                            {i > 0 && arr[i-1] !== p - 1 && <span key={`ellipsis-${p}`} className="px-1">…</span>}
                            <Button
                              key={p}
                              variant={currentPage === p ? "default" : "outline"}
                              size="sm"
                              className="h-7 w-7 p-0 text-xs"
                              onClick={() => setCurrentPage(p)}
                              data-testid={`button-page-${p}`}
                            >
                              {p}
                            </Button>
                          </>
                        ))}
                      <Button
                        variant="outline"
                        size="sm"
                        className="h-7 px-2 text-xs"
                        disabled={currentPage >= Math.ceil(filtered.length / pageSize)}
                        onClick={() => setCurrentPage(p => p + 1)}
                        data-testid="button-next-page"
                      >
                        Next <ChevronRight className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          <Dialog open={!!viewEmployee} onOpenChange={open => { if (!open) setViewEmployee(null); }}>
            <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto" data-testid="dialog-view-employee">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Eye className="h-4 w-4 text-primary" /> Employee Profile
                </DialogTitle>
              </DialogHeader>
              {viewEmployee && (
                <div className="space-y-5">
                  <div className="flex items-center gap-4 pb-4 border-b">
                    {(viewEmployee as any).profilePicture ? (
                      <img src={(viewEmployee as any).profilePicture} alt="" className="w-16 h-16 rounded-full object-cover border-2 border-primary" />
                    ) : (
                      <div className="w-16 h-16 rounded-full bg-primary/10 border-2 border-primary/30 flex items-center justify-center">
                        <span className="text-2xl font-bold text-primary">{viewEmployee.fullName.charAt(0)}</span>
                      </div>
                    )}
                    <div>
                      <h3 className="text-lg font-bold">{viewEmployee.fullName}</h3>
                      <p className="text-sm text-muted-foreground">{viewEmployee.designation} — {departmentLabels[viewEmployee.department] || viewEmployee.department}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="font-mono text-xs bg-muted px-2 py-0.5 rounded">{viewEmployee.empCode}</span>
                        <Badge variant="secondary" className={`no-default-active-elevate text-[10px] capitalize ${statusColors[viewEmployee.status]}`}>
                          {viewEmployee.status.replace("_"," ")}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-x-6 gap-y-3 text-sm">
                    {[
                      { label: "Email", value: viewEmployee.email },
                      { label: "Phone", value: viewEmployee.phone },
                      { label: "CNIC", value: viewEmployee.cnic },
                      { label: "Join Date", value: viewEmployee.joinDate },
                      { label: "Gender", value: (viewEmployee as any).gender },
                      { label: "Date of Birth", value: (viewEmployee as any).dateOfBirth },
                      { label: "Marital Status", value: (viewEmployee as any).maritalStatus },
                      { label: "Blood Group", value: (viewEmployee as any).bloodGroup },
                      { label: "Father's Name", value: (viewEmployee as any).fatherName },
                      { label: "Religion", value: (viewEmployee as any).religion },
                      { label: "Nationality", value: (viewEmployee as any).nationality },
                      { label: "City", value: viewEmployee.city },
                      { label: "Bank", value: (viewEmployee as any).bankName },
                      { label: "Bank Account", value: viewEmployee.bankAccount },
                      { label: "Salary Type", value: (viewEmployee as any).salaryType },
                      { label: "Salary", value: viewEmployee.salary ? `Rs. ${Number(viewEmployee.salary).toLocaleString()}` : null },
                      { label: "Shift", value: (viewEmployee as any).shift },
                      { label: "Work Location", value: (viewEmployee as any).workLocation },
                      { label: "Reporting To", value: (viewEmployee as any).reportingTo },
                      { label: "Emergency Contact", value: (viewEmployee as any).emergencyContact },
                      { label: "Emergency Phone", value: (viewEmployee as any).emergencyPhone },
                      { label: "Address", value: viewEmployee.address },
                    ].filter(f => f.value).map(({ label, value }) => (
                      <div key={label}>
                        <p className="text-[10px] uppercase tracking-wide font-semibold text-muted-foreground">{label}</p>
                        <p className="text-sm font-medium capitalize">{value}</p>
                      </div>
                    ))}
                  </div>
                  <div className="flex justify-end gap-2 pt-3 border-t">
                    <Button variant="outline" size="sm" onClick={() => window.print()} className="gap-1.5"><Printer className="h-3.5 w-3.5" /> Print</Button>
                    <Button size="sm" onClick={() => { openEdit(viewEmployee); setViewEmployee(null); }} className="gap-1.5"><Edit className="h-3.5 w-3.5" /> Edit</Button>
                  </div>
                </div>
              )}
            </DialogContent>
          </Dialog>
        </div>
      )}

      {activeTab === "roles" && (
        <div className="mt-5" data-testid="tab-content-roles">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Briefcase className="h-5 w-5" />
                Employee Types & Roles
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              {roleData.length === 0 ? (
                emptyState(<Settings className="h-12 w-12" />, "No roles configured", "Configure in Settings")
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Role / Designation</TableHead>
                        <TableHead>Department</TableHead>
                        <TableHead>Employment Type</TableHead>
                        <TableHead>Employees</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {roleData.map((role, idx) => (
                        <TableRow key={idx} data-testid={`row-role-${idx}`}>
                          <TableCell className="font-medium">{role.role}</TableCell>
                          <TableCell>
                            <Badge variant="secondary" className="no-default-active-elevate text-[10px]">
                              {role.department}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-sm">{role.type}</TableCell>
                          <TableCell className="text-sm">{role.count}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {activeTab === "shifts" && (
        <div className="mt-5" data-testid="tab-content-shifts">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Shift & Scheduling
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Shift Name</TableHead>
                      <TableHead>Start Time</TableHead>
                      <TableHead>End Time</TableHead>
                      <TableHead>Days</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {shiftData.map((shift, idx) => (
                      <TableRow key={idx} data-testid={`row-shift-${idx}`}>
                        <TableCell className="font-medium">{shift.name}</TableCell>
                        <TableCell className="text-sm">{shift.startTime}</TableCell>
                        <TableCell className="text-sm">{shift.endTime}</TableCell>
                        <TableCell className="text-sm">{shift.days}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {activeTab === "attendance" && (
        <div className="mt-5" data-testid="tab-content-attendance">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Attendance Tracking
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              {!employees || employees.length === 0 ? (
                emptyState(<Calendar className="h-12 w-12" />, "No attendance data", "Add employees first to track attendance")
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Emp Code</TableHead>
                        <TableHead>Employee Name</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {employees.slice(0, 10).map((emp, idx) => {
                        const statuses = ["Present", "Present", "Present", "Absent", "Late", "Leave"];
                        const status = statuses[idx % statuses.length];
                        const statusStyle: Record<string, string> = {
                          Present: "text-green-700 dark:text-green-300 bg-green-50 dark:bg-green-950",
                          Absent: "text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950",
                          Late: "text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950",
                          Leave: "text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950",
                        };
                        return (
                          <TableRow key={idx} data-testid={`row-attendance-${idx}`}>
                            <TableCell className="font-mono text-xs">{emp.empCode}</TableCell>
                            <TableCell className="font-medium">{emp.fullName}</TableCell>
                            <TableCell className="text-sm">{new Date().toISOString().split("T")[0]}</TableCell>
                            <TableCell>
                              <Badge variant="secondary" className={`no-default-active-elevate text-[10px] ${statusStyle[status] || ""}`}>
                                {status}
                              </Badge>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {activeTab === "salary" && (
        <div className="mt-5" data-testid="tab-content-salary">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="h-5 w-5" />
                Employee Salary
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              {!employees || employees.length === 0 ? (
                emptyState(<DollarSign className="h-12 w-12" />, "No salary data", "Add employees first to manage salaries")
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Emp Code</TableHead>
                        <TableHead>Employee Name</TableHead>
                        <TableHead>Department</TableHead>
                        <TableHead>Designation</TableHead>
                        <TableHead>Basic Salary (Rs.)</TableHead>
                        <TableHead>Bank Account</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {employees.map((emp) => (
                        <TableRow key={emp.id} data-testid={`row-salary-${emp.id}`}>
                          <TableCell className="font-mono text-xs">{emp.empCode}</TableCell>
                          <TableCell className="font-medium">{emp.fullName}</TableCell>
                          <TableCell>
                            <Badge variant="secondary" className="no-default-active-elevate text-[10px] capitalize">
                              {departmentLabels[emp.department] || emp.department}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-sm">{emp.designation}</TableCell>
                          <TableCell className="text-sm">
                            {emp.salary ? `Rs. ${Number(emp.salary).toLocaleString()}` : "\u2014"}
                          </TableCell>
                          <TableCell className="text-sm">{emp.bankAccount || "\u2014"}</TableCell>
                          <TableCell>
                            <Badge
                              variant="secondary"
                              className={`no-default-active-elevate text-[10px] capitalize ${statusColors[emp.status] || ""}`}
                            >
                              {emp.status.replace("_", " ")}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {activeTab === "bonus" && (
        <div className="mt-5" data-testid="tab-content-bonus">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Gift className="h-5 w-5" />
                Bonus & Commission
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              {!employees || employees.length === 0 ? (
                emptyState(<Gift className="h-12 w-12" />, "No bonus data", "Configure in Settings")
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Emp Code</TableHead>
                        <TableHead>Employee Name</TableHead>
                        <TableHead>Department</TableHead>
                        <TableHead>Bonus Type</TableHead>
                        <TableHead>Amount (Rs.)</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {employees.slice(0, 5).map((emp, idx) => {
                        const bonusTypes = ["Performance", "Annual", "Commission", "Incentive", "Festival"];
                        return (
                          <TableRow key={idx} data-testid={`row-bonus-${idx}`}>
                            <TableCell className="font-mono text-xs">{emp.empCode}</TableCell>
                            <TableCell className="font-medium">{emp.fullName}</TableCell>
                            <TableCell>
                              <Badge variant="secondary" className="no-default-active-elevate text-[10px] capitalize">
                                {departmentLabels[emp.department] || emp.department}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-sm">{bonusTypes[idx % bonusTypes.length]}</TableCell>
                            <TableCell className="text-sm">{"\u2014"}</TableCell>
                            <TableCell>
                              <Badge variant="secondary" className="no-default-active-elevate text-[10px] text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950">
                                Pending
                              </Badge>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {activeTab === "advance" && (
        <div className="mt-5" data-testid="tab-content-advance">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Wallet className="h-5 w-5" />
                Advance & Loan
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              {!employees || employees.length === 0 ? (
                emptyState(<Wallet className="h-12 w-12" />, "No advance/loan records", "Configure in Settings")
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Emp Code</TableHead>
                        <TableHead>Employee Name</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Amount (Rs.)</TableHead>
                        <TableHead>Monthly Deduction</TableHead>
                        <TableHead>Remaining</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {employees.slice(0, 5).map((emp, idx) => {
                        const types = ["Salary Advance", "Personal Loan", "Emergency Loan", "Salary Advance", "Personal Loan"];
                        return (
                          <TableRow key={idx} data-testid={`row-advance-${idx}`}>
                            <TableCell className="font-mono text-xs">{emp.empCode}</TableCell>
                            <TableCell className="font-medium">{emp.fullName}</TableCell>
                            <TableCell className="text-sm">{types[idx % types.length]}</TableCell>
                            <TableCell className="text-sm">{"\u2014"}</TableCell>
                            <TableCell className="text-sm">{"\u2014"}</TableCell>
                            <TableCell className="text-sm">{"\u2014"}</TableCell>
                            <TableCell>
                              <Badge variant="secondary" className="no-default-active-elevate text-[10px] text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950">
                                Pending
                              </Badge>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      {activeTab === "leave" && (
        <div className="mt-5" data-testid="tab-content-leave">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CalendarDays className="h-5 w-5" />
                Holiday & Leave Management
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              {!employees || employees.length === 0 ? (
                emptyState(<CalendarDays className="h-12 w-12" />, "No leave records", "Configure in Settings")
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Emp Code</TableHead>
                        <TableHead>Employee Name</TableHead>
                        <TableHead>Leave Type</TableHead>
                        <TableHead>From</TableHead>
                        <TableHead>To</TableHead>
                        <TableHead>Days</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {employees.slice(0, 5).map((emp, idx) => {
                        const leaveTypes = ["Annual", "Sick", "Casual", "Maternity", "Unpaid"];
                        const leaveStatuses = ["Approved", "Pending", "Approved", "Rejected", "Pending"];
                        const leaveStatusStyle: Record<string, string> = {
                          Approved: "text-green-700 dark:text-green-300 bg-green-50 dark:bg-green-950",
                          Pending: "text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950",
                          Rejected: "text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950",
                        };
                        return (
                          <TableRow key={idx} data-testid={`row-leave-${idx}`}>
                            <TableCell className="font-mono text-xs">{emp.empCode}</TableCell>
                            <TableCell className="font-medium">{emp.fullName}</TableCell>
                            <TableCell className="text-sm">{leaveTypes[idx % leaveTypes.length]}</TableCell>
                            <TableCell className="text-sm">{"\u2014"}</TableCell>
                            <TableCell className="text-sm">{"\u2014"}</TableCell>
                            <TableCell className="text-sm">{"\u2014"}</TableCell>
                            <TableCell>
                              <Badge variant="secondary" className={`no-default-active-elevate text-[10px] ${leaveStatusStyle[leaveStatuses[idx % leaveStatuses.length]] || ""}`}>
                                {leaveStatuses[idx % leaveStatuses.length]}
                              </Badge>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingEmployee ? "Edit Employee" : "Add New Employee"}</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              {renderEmployeeFormFields(form)}
              <DialogFooter>
                <Button type="button" variant="secondary" onClick={() => setDialogOpen(false)}>
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={createMutation.isPending || updateMutation.isPending}
                  data-testid="button-save-employee"
                >
                  {createMutation.isPending || updateMutation.isPending ? "Saving..." : editingEmployee ? "Update" : "Create"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}