import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Search,
  MapPin,
  Users,
  Activity,
  Map,
  Phone,
  Mail,
  Calendar,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import type { Customer, Package } from "@shared/schema";

export default function CustomerMapPage() {
  const [search, setSearch] = useState("");
  const [areaFilter, setAreaFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);

  const { data: customers, isLoading } = useQuery<Customer[]>({
    queryKey: ["/api/customers"],
  });

  const { data: packages } = useQuery<Package[]>({
    queryKey: ["/api/packages"],
  });

  const packageMap = (packages || []).reduce<Record<number, Package>>((acc, pkg) => {
    acc[pkg.id] = pkg;
    return acc;
  }, {});

  const allCustomers = customers || [];
  const uniqueAreas = Array.from(new Set(allCustomers.map((c) => c.area).filter(Boolean))) as string[];

  const filtered = allCustomers.filter((c) => {
    const matchSearch =
      c.fullName.toLowerCase().includes(search.toLowerCase()) ||
      (c.customerId || "").toLowerCase().includes(search.toLowerCase()) ||
      (c.area || "").toLowerCase().includes(search.toLowerCase()) ||
      (c.address || "").toLowerCase().includes(search.toLowerCase());
    const matchArea = areaFilter === "all" || c.area === areaFilter;
    const matchStatus = statusFilter === "all" || c.status === statusFilter;
    return matchSearch && matchArea && matchStatus;
  });

  const areaGroups = filtered.reduce<Record<string, Customer[]>>((acc, c) => {
    const area = c.area || "Unknown";
    if (!acc[area]) acc[area] = [];
    acc[area].push(c);
    return acc;
  }, {});

  const totalCustomers = allCustomers.length;
  const withLocation = allCustomers.filter((c) => c.area || c.mapLatitude).length;
  const activeCustomers = allCustomers.filter((c) => c.status === "active").length;
  const uniqueAreaCount = uniqueAreas.length;

  const summaryCards = [
    { title: "Total Customers", value: totalCustomers, icon: Users, color: "text-blue-600 dark:text-blue-400" },
    { title: "With Location Data", value: withLocation, icon: MapPin, color: "text-green-600 dark:text-green-400" },
    { title: "Active", value: activeCustomers, icon: Activity, color: "text-purple-600 dark:text-purple-400" },
    { title: "By Area", value: uniqueAreaCount, icon: Map, color: "text-amber-600 dark:text-amber-400" },
  ];

  const statusDotColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-500";
      case "suspended":
        return "bg-amber-500";
      case "disconnected":
        return "bg-red-500";
      default:
        return "bg-muted-foreground";
    }
  };

  const statusBadgeClass = (status: string) => {
    switch (status) {
      case "active":
        return "text-green-700 dark:text-green-300 bg-green-50 dark:bg-green-950";
      case "suspended":
        return "text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950";
      case "disconnected":
        return "text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950";
      default:
        return "";
    }
  };

  const getPackageName = (pkgId: number | null | undefined) => {
    if (!pkgId) return "\u2014";
    return packageMap[pkgId]?.name || "\u2014";
  };

  return (
    <div className="p-6 space-y-6 max-w-[1400px] mx-auto">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight" data-testid="text-customer-map-title">
            Customer Connection Map
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            Visual overview of customer locations grouped by area
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {summaryCards.map((card) => (
          <Card key={card.title} data-testid={`card-summary-${card.title.toLowerCase().replace(/\s+/g, "-")}`}>
            <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
              <span className="text-sm font-medium text-muted-foreground">{card.title}</span>
              <card.icon className={`h-4 w-4 ${card.color}`} />
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-8 w-16" />
              ) : (
                <div className="text-2xl font-bold" data-testid={`text-summary-${card.title.toLowerCase().replace(/\s+/g, "-")}`}>
                  {card.value}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
            <div className="relative flex-1 w-full sm:max-w-xs">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search customers..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9"
                data-testid="input-search-customers"
              />
            </div>
            <Select value={areaFilter} onValueChange={setAreaFilter}>
              <SelectTrigger className="w-[180px]" data-testid="select-area-filter">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Areas</SelectItem>
                {uniqueAreas.map((area) => (
                  <SelectItem key={area} value={area}>
                    {area}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[180px]" data-testid="select-status-filter">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="suspended">Suspended</SelectItem>
                <SelectItem value="disconnected">Disconnected</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
      </Card>

      {isLoading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-32 w-full" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
          <div className="lg:col-span-3 space-y-4" data-testid="map-container">
            {Object.keys(areaGroups).length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                  <MapPin className="h-12 w-12 mb-3 opacity-30" />
                  <p className="font-medium">No customers found</p>
                  <p className="text-sm mt-1">Adjust filters to see customer locations</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {Object.entries(areaGroups)
                  .sort((a, b) => b[1].length - a[1].length)
                  .map(([area, areaCustomers]) => (
                    <Card key={area} data-testid={`card-area-${area}`}>
                      <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
                        <div className="flex items-center gap-2">
                          <MapPin className="h-4 w-4 text-muted-foreground" />
                          <span className="font-medium text-sm" data-testid={`text-area-name-${area}`}>{area}</span>
                        </div>
                        <Badge variant="secondary" className="no-default-active-elevate text-[10px]">
                          {areaCustomers.length} customers
                        </Badge>
                      </CardHeader>
                      <CardContent>
                        <div className="flex flex-wrap gap-2 mb-3">
                          {areaCustomers.map((c) => (
                            <button
                              key={c.id}
                              onClick={() => setSelectedCustomer(c)}
                              className="group relative flex items-center gap-1.5 rounded-md px-2 py-1 text-xs hover-elevate cursor-pointer"
                              data-testid={`dot-customer-${c.id}`}
                              title={c.fullName}
                            >
                              <span className={`inline-block h-2.5 w-2.5 rounded-full ${statusDotColor(c.status)}`} />
                              <span className="text-muted-foreground truncate max-w-[100px]">{c.fullName}</span>
                            </button>
                          ))}
                        </div>
                        <div className="flex items-center gap-3 text-[10px] text-muted-foreground border-t pt-2">
                          <span className="flex items-center gap-1">
                            <span className="h-2 w-2 rounded-full bg-green-500" /> Active: {areaCustomers.filter((c) => c.status === "active").length}
                          </span>
                          <span className="flex items-center gap-1">
                            <span className="h-2 w-2 rounded-full bg-amber-500" /> Suspended: {areaCustomers.filter((c) => c.status === "suspended").length}
                          </span>
                          <span className="flex items-center gap-1">
                            <span className="h-2 w-2 rounded-full bg-red-500" /> Disconnected: {areaCustomers.filter((c) => c.status === "disconnected").length}
                          </span>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </div>
            )}
          </div>

          <div className="lg:col-span-2">
            <Card>
              <CardHeader className="pb-2">
                <span className="text-sm font-medium text-muted-foreground">Customer List ({filtered.length})</span>
              </CardHeader>
              <CardContent className="p-0">
                {filtered.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                    <Users className="h-12 w-12 mb-3 opacity-30" />
                    <p className="font-medium">No customers found</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto max-h-[600px] overflow-y-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Name</TableHead>
                          <TableHead>Area</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead className="hidden xl:table-cell">Address</TableHead>
                          <TableHead className="hidden xl:table-cell">Phone</TableHead>
                          <TableHead className="hidden xl:table-cell">Package</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {filtered.map((c) => (
                          <TableRow
                            key={c.id}
                            className="cursor-pointer"
                            onClick={() => setSelectedCustomer(c)}
                            data-testid={`row-customer-${c.id}`}
                          >
                            <TableCell>
                              <span className="font-medium text-sm" data-testid={`text-customer-name-${c.id}`}>
                                {c.fullName}
                              </span>
                            </TableCell>
                            <TableCell className="text-sm text-muted-foreground">
                              {c.area || "\u2014"}
                            </TableCell>
                            <TableCell>
                              <Badge
                                variant="secondary"
                                className={`no-default-active-elevate text-[10px] capitalize ${statusBadgeClass(c.status)}`}
                                data-testid={`badge-status-${c.id}`}
                              >
                                {c.status}
                              </Badge>
                            </TableCell>
                            <TableCell className="hidden xl:table-cell text-sm text-muted-foreground truncate max-w-[120px]">
                              {c.address || "\u2014"}
                            </TableCell>
                            <TableCell className="hidden xl:table-cell text-sm text-muted-foreground">
                              {c.phone || "\u2014"}
                            </TableCell>
                            <TableCell className="hidden xl:table-cell text-sm text-muted-foreground">
                              {getPackageName(c.packageId)}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      {selectedCustomer && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/40"
          onClick={() => setSelectedCustomer(null)}
          data-testid="customer-detail-overlay"
        >
          <Card
            className="w-full max-w-md mx-4"
            onClick={(e) => e.stopPropagation()}
            data-testid="card-customer-detail"
          >
            <CardHeader className="flex flex-row items-start justify-between gap-2">
              <div>
                <h3 className="font-semibold text-base" data-testid="text-detail-name">
                  {selectedCustomer.fullName}
                </h3>
                <p className="text-xs text-muted-foreground" data-testid="text-detail-id">
                  {selectedCustomer.customerId}
                </p>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setSelectedCustomer(null)}
                data-testid="button-close-detail"
              >
                <X className="h-4 w-4" />
              </Button>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2">
                <Badge
                  variant="secondary"
                  className={`no-default-active-elevate text-[10px] capitalize ${statusBadgeClass(selectedCustomer.status)}`}
                  data-testid="badge-detail-status"
                >
                  {selectedCustomer.status}
                </Badge>
              </div>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <p className="text-muted-foreground text-xs">Area</p>
                  <p className="font-medium" data-testid="text-detail-area">{selectedCustomer.area || "\u2014"}</p>
                </div>
                <div>
                  <p className="text-muted-foreground text-xs">Package</p>
                  <p className="font-medium" data-testid="text-detail-package">{getPackageName(selectedCustomer.packageId)}</p>
                </div>
                <div className="col-span-2">
                  <p className="text-muted-foreground text-xs flex items-center gap-1">
                    <MapPin className="h-3 w-3" /> Address
                  </p>
                  <p className="font-medium" data-testid="text-detail-address">{selectedCustomer.address || "\u2014"}</p>
                </div>
                <div>
                  <p className="text-muted-foreground text-xs flex items-center gap-1">
                    <Phone className="h-3 w-3" /> Phone
                  </p>
                  <p className="font-medium" data-testid="text-detail-phone">{selectedCustomer.phone || "\u2014"}</p>
                </div>
                <div>
                  <p className="text-muted-foreground text-xs flex items-center gap-1">
                    <Calendar className="h-3 w-3" /> Connection Date
                  </p>
                  <p className="font-medium" data-testid="text-detail-connection-date">{selectedCustomer.connectionDate || "\u2014"}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}