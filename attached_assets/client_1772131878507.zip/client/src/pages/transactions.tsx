import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Plus,
  Search,
  MoreHorizontal,
  Edit,
  Trash2,
  ArrowUpDown,
  CheckCircle,
  Clock,
  XCircle,
  RotateCcw,
  CreditCard,
  TrendingUp,
  TrendingDown,
  RefreshCw,
  ArrowLeftRight,
  Users,
  Store,
  Wallet,
  ShieldCheck,
  FileText,
  Send,
  DollarSign,
  Printer,
  Eye,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { useTab } from "@/hooks/use-tab";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertTransactionSchema, type Transaction, type InsertTransaction, type Customer, type Account } from "@shared/schema";
import { z } from "zod";

const transactionFormSchema = insertTransactionSchema.extend({
  txnId: z.string().min(1, "Transaction ID is required"),
  type: z.string().min(1, "Type is required"),
  amount: z.string().min(1, "Amount is required"),
  date: z.string().min(1, "Date is required"),
});

export default function TransactionsPage() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useTab("list");
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);
  const [viewingTransaction, setViewingTransaction] = useState<Transaction | null>(null);
  const [detailDialogOpen, setDetailDialogOpen] = useState(false);

  const { data: transactions, isLoading } = useQuery<(Transaction & { customerName?: string; accountName?: string })[]>({
    queryKey: ["/api/transactions"],
  });

  const { data: customers } = useQuery<Customer[]>({
    queryKey: ["/api/customers"],
  });

  const { data: accountsList } = useQuery<Account[]>({
    queryKey: ["/api/accounts"],
  });

  const form = useForm<InsertTransaction>({
    resolver: zodResolver(transactionFormSchema),
    defaultValues: {
      txnId: "",
      type: "payment",
      amount: "0",
      accountId: null,
      customerId: null,
      invoiceId: null,
      paymentMethod: "cash",
      reference: "",
      description: "",
      date: new Date().toISOString().split("T")[0],
      status: "completed",
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertTransaction) => {
      const res = await apiRequest("POST", "/api/transactions", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      setDialogOpen(false);
      form.reset();
      toast({ title: "Transaction created successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertTransaction> }) => {
      const res = await apiRequest("PATCH", `/api/transactions/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      setDialogOpen(false);
      setEditingTransaction(null);
      form.reset();
      toast({ title: "Transaction updated successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/transactions/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({ title: "Transaction deleted successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const openCreate = () => {
    setEditingTransaction(null);
    form.reset({
      txnId: "",
      type: "payment",
      amount: "0",
      accountId: null,
      customerId: null,
      invoiceId: null,
      paymentMethod: "cash",
      reference: "",
      description: "",
      date: new Date().toISOString().split("T")[0],
      status: "completed",
    });
    setDialogOpen(true);
  };

  const openEdit = (txn: Transaction) => {
    setEditingTransaction(txn);
    form.reset({
      txnId: txn.txnId,
      type: txn.type,
      amount: txn.amount,
      accountId: txn.accountId,
      customerId: txn.customerId,
      invoiceId: txn.invoiceId,
      paymentMethod: txn.paymentMethod || "cash",
      reference: txn.reference || "",
      description: txn.description || "",
      date: txn.date,
      status: txn.status,
    });
    setDialogOpen(true);
  };

  const onSubmit = (data: InsertTransaction) => {
    if (editingTransaction) {
      updateMutation.mutate({ id: editingTransaction.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const filtered = (transactions || []).filter((txn) => {
    const matchSearch =
      txn.txnId.toLowerCase().includes(search.toLowerCase()) ||
      (txn.description || "").toLowerCase().includes(search.toLowerCase());
    const matchType = typeFilter === "all" || txn.type === typeFilter;
    const matchStatus = statusFilter === "all" || txn.status === statusFilter;
    return matchSearch && matchType && matchStatus;
  });

  const typeConfig: Record<string, string> = {
    credit: "text-green-700 dark:text-green-300 bg-green-50 dark:bg-green-950",
    debit: "text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950",
    payment: "text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950",
    refund: "text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950",
    adjustment: "text-purple-700 dark:text-purple-300 bg-purple-50 dark:bg-purple-950",
  };

  const statusConfig: Record<string, { icon: any; color: string }> = {
    completed: { icon: CheckCircle, color: "text-green-700 dark:text-green-300 bg-green-50 dark:bg-green-950" },
    pending: { icon: Clock, color: "text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950" },
    failed: { icon: XCircle, color: "text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950" },
    reversed: { icon: RotateCcw, color: "text-gray-500 bg-gray-50 dark:bg-gray-900" },
  };

  const paymentMethodLabels: Record<string, string> = {
    cash: "Cash",
    bank_transfer: "Bank Transfer",
    cheque: "Cheque",
    online: "Online",
    jazzcash: "JazzCash",
    easypaisa: "EasyPaisa",
  };

  const buildSlipHtml = (txnList: typeof allTxns) => {
    const slips = txnList.map((txn) => {
      const customer = (customers || []).find((c) => c.id === txn.customerId);
      const account = (accountsList || []).find((a) => a.id === txn.accountId);
      return `
        <div class="slip">
          <div class="slip-header">
            <h2>Transaction Slip</h2>
            <span class="slip-id">${txn.txnId}</span>
          </div>
          <table>
            <tr><td>Type</td><td><b>${txn.type.toUpperCase()}</b></td></tr>
            <tr><td>Amount</td><td><b>Rs. ${Number(txn.amount).toLocaleString()}</b></td></tr>
            <tr><td>Date</td><td>${txn.date}</td></tr>
            <tr><td>Status</td><td>${txn.status}</td></tr>
            <tr><td>Payment Method</td><td>${txn.paymentMethod ? (paymentMethodLabels[txn.paymentMethod] || txn.paymentMethod) : "—"}</td></tr>
            ${account ? `<tr><td>Account</td><td>${account.code} - ${account.name}</td></tr>` : ""}
            ${customer ? `<tr><td>Customer</td><td>${customer.fullName} (${customer.customerId})</td></tr>` : ""}
            ${txn.reference ? `<tr><td>Reference</td><td>${txn.reference}</td></tr>` : ""}
            ${txn.description ? `<tr><td>Description</td><td>${txn.description}</td></tr>` : ""}
          </table>
          <div class="slip-footer">NetSphere Enterprise &mdash; Printed on ${new Date().toLocaleString()}</div>
        </div>`;
    }).join('<div class="page-break"></div>');
    return `<!DOCTYPE html><html><head><title>Transaction Slips</title><style>
      body { font-family: Arial, sans-serif; font-size: 12px; margin: 0; }
      .slip { padding: 24px; max-width: 480px; margin: 0 auto; border: 1px solid #ccc; border-radius: 8px; margin-bottom: 24px; }
      .slip-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; border-bottom: 1px solid #eee; padding-bottom: 10px; }
      .slip-header h2 { margin: 0; font-size: 16px; }
      .slip-id { font-family: monospace; font-size: 13px; color: #555; }
      table { width: 100%; border-collapse: collapse; }
      td { padding: 5px 2px; vertical-align: top; }
      td:first-child { color: #666; width: 42%; }
      .slip-footer { margin-top: 14px; border-top: 1px solid #eee; padding-top: 8px; font-size: 10px; color: #888; text-align: center; }
      .page-break { page-break-after: always; }
      @media print { body { margin: 10mm; } .slip { border: none; } }
    </style></head><body>${slips}</body></html>`;
  };

  const printSingleSlip = (txn: Transaction) => {
    const win = window.open("", "_blank", "width=600,height=700");
    if (!win) return;
    win.document.write(buildSlipHtml([txn]));
    win.document.close();
    win.focus();
    setTimeout(() => { win.print(); }, 300);
  };

  const printAllSlips = (txnList: typeof allTxns) => {
    if (!txnList.length) return;
    const win = window.open("", "_blank", "width=700,height=800");
    if (!win) return;
    win.document.write(buildSlipHtml(txnList));
    win.document.close();
    win.focus();
    setTimeout(() => { win.print(); }, 300);
  };

  const allTxns = transactions || [];
  const typeCounts = {
    payment: allTxns.filter((t) => t.type === "payment").length,
    credit: allTxns.filter((t) => t.type === "credit").length,
    debit: allTxns.filter((t) => t.type === "debit").length,
    refund: allTxns.filter((t) => t.type === "refund").length,
    adjustment: allTxns.filter((t) => t.type === "adjustment").length,
  };
  const typeAmounts = {
    payment: allTxns.filter((t) => t.type === "payment").reduce((s, t) => s + Number(t.amount), 0),
    credit: allTxns.filter((t) => t.type === "credit").reduce((s, t) => s + Number(t.amount), 0),
    debit: allTxns.filter((t) => t.type === "debit").reduce((s, t) => s + Number(t.amount), 0),
    refund: allTxns.filter((t) => t.type === "refund").reduce((s, t) => s + Number(t.amount), 0),
    adjustment: allTxns.filter((t) => t.type === "adjustment").reduce((s, t) => s + Number(t.amount), 0),
  };

  const customerTxns = allTxns.filter((t) => t.customerId != null && (t.type === "payment" || t.type === "credit"));
  const resellerTxns = allTxns.filter((t) => t.type === "debit" || t.type === "adjustment");
  const refundTxns = allTxns.filter((t) => t.type === "refund");
  const pendingApprovals = allTxns.filter((t) => t.status === "pending");

  const renderTransactionTable = (txnList: typeof allTxns, emptyMsg: string) => {
    if (isLoading) {
      return (
        <div className="p-5 space-y-3">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-14 w-full" />
          ))}
        </div>
      );
    }
    if (txnList.length === 0) {
      return (
        <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
          <ArrowUpDown className="h-12 w-12 mb-3 opacity-30" />
          <p className="font-medium">{emptyMsg}</p>
        </div>
      );
    }
    return (
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Txn ID</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Amount (Rs.)</TableHead>
              <TableHead className="hidden md:table-cell">Account</TableHead>
              <TableHead className="hidden md:table-cell">Customer</TableHead>
              <TableHead className="hidden lg:table-cell">Payment Method</TableHead>
              <TableHead className="hidden md:table-cell">Date</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="w-10"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {txnList.map((txn) => {
              const config = statusConfig[txn.status] || statusConfig.pending;
              const StatusIcon = config.icon;
              return (
                <TableRow key={txn.id} data-testid={`row-transaction-${txn.id}`}>
                  <TableCell className="font-mono text-xs" data-testid={`text-txn-id-${txn.id}`}>{txn.txnId}</TableCell>
                  <TableCell>
                    <Badge variant="secondary" className={`no-default-active-elevate text-[10px] capitalize ${typeConfig[txn.type] || ""}`} data-testid={`badge-txn-type-${txn.id}`}>
                      {txn.type}
                    </Badge>
                  </TableCell>
                  <TableCell className="font-semibold" data-testid={`text-txn-amount-${txn.id}`}>
                    Rs. {Number(txn.amount).toLocaleString()}
                  </TableCell>
                  <TableCell className="hidden md:table-cell text-sm text-muted-foreground" data-testid={`text-txn-account-${txn.id}`}>
                    {(txn as any).accountName || (txn.accountId ? `#${txn.accountId}` : "-")}
                  </TableCell>
                  <TableCell className="hidden md:table-cell text-sm text-muted-foreground" data-testid={`text-txn-customer-${txn.id}`}>
                    {(txn as any).customerName || (txn.customerId ? `#${txn.customerId}` : "-")}
                  </TableCell>
                  <TableCell className="hidden lg:table-cell text-sm" data-testid={`text-txn-method-${txn.id}`}>
                    {txn.paymentMethod ? paymentMethodLabels[txn.paymentMethod] || txn.paymentMethod : "-"}
                  </TableCell>
                  <TableCell className="hidden md:table-cell text-sm text-muted-foreground" data-testid={`text-txn-date-${txn.id}`}>
                    {txn.date}
                  </TableCell>
                  <TableCell>
                    <Badge variant="secondary" className={`no-default-active-elevate text-[10px] capitalize ${config.color}`} data-testid={`badge-txn-status-${txn.id}`}>
                      <StatusIcon className="h-3 w-3 mr-1" />
                      {txn.status}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" data-testid={`button-txn-actions-${txn.id}`}>
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => { setViewingTransaction(txn); setDetailDialogOpen(true); }} data-testid={`button-view-txn-${txn.id}`}>
                          <Eye className="h-4 w-4 mr-2" />
                          View Detail
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => printSingleSlip(txn)} data-testid={`button-print-txn-${txn.id}`}>
                          <Printer className="h-4 w-4 mr-2" />
                          Print Slip
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => openEdit(txn)} data-testid={`button-edit-txn-${txn.id}`}>
                          <Edit className="h-4 w-4 mr-2" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          className="text-destructive"
                          onClick={() => deleteMutation.mutate(txn.id)}
                          data-testid={`button-delete-txn-${txn.id}`}
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>
    );
  };

  return (
    <div className="p-6 space-y-6 max-w-[1400px] mx-auto">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight" data-testid="text-transactions-title">Financial Transactions</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Manage financial transactions and payments</p>
        </div>
        <Button onClick={openCreate} data-testid="button-add-transaction">
          <Plus className="h-4 w-4 mr-1" />
          Add Transaction
        </Button>
      </div>

        {activeTab === "types" && (<div className="mt-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
            {[
              { key: "payment", label: "Payment", icon: CreditCard, color: "text-blue-600 dark:text-blue-400" },
              { key: "credit", label: "Income", icon: TrendingUp, color: "text-green-600 dark:text-green-400" },
              { key: "debit", label: "Expense", icon: TrendingDown, color: "text-red-600 dark:text-red-400" },
              { key: "refund", label: "Refund", icon: RefreshCw, color: "text-amber-600 dark:text-amber-400" },
              { key: "adjustment", label: "Transfer", icon: ArrowLeftRight, color: "text-purple-600 dark:text-purple-400" },
            ].map((item) => (
              <Card key={item.key} data-testid={`card-type-${item.key}`}>
                <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
                  <CardTitle className="text-sm font-medium">{item.label}</CardTitle>
                  <item.icon className={`h-5 w-5 ${item.color}`} />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold" data-testid={`text-type-count-${item.key}`}>
                    {typeCounts[item.key as keyof typeof typeCounts]}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1" data-testid={`text-type-amount-${item.key}`}>
                    Rs. {typeAmounts[item.key as keyof typeof typeAmounts].toLocaleString()}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>)}

        {activeTab === "list" && (<div className="mt-5">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 flex-wrap">
                <div className="relative flex-1 w-full sm:max-w-xs">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search by ID or description..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="pl-9"
                    data-testid="input-search-transactions"
                  />
                </div>
                <Select value={typeFilter} onValueChange={setTypeFilter}>
                  <SelectTrigger className="w-[140px]" data-testid="select-transaction-type-filter">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="credit">Credit</SelectItem>
                    <SelectItem value="debit">Debit</SelectItem>
                    <SelectItem value="payment">Payment</SelectItem>
                    <SelectItem value="refund">Refund</SelectItem>
                    <SelectItem value="adjustment">Adjustment</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[140px]" data-testid="select-transaction-status-filter">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="failed">Failed</SelectItem>
                    <SelectItem value="reversed">Reversed</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline" size="sm" onClick={() => printAllSlips(filtered)} disabled={filtered.length === 0} data-testid="button-print-all-slips">
                  <Printer className="h-4 w-4 mr-1" />
                  Print All Slips
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              {isLoading ? (
                <div className="p-5 space-y-3">
                  {[1, 2, 3].map((i) => (
                    <Skeleton key={i} className="h-14 w-full" />
                  ))}
                </div>
              ) : filtered.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                  <ArrowUpDown className="h-12 w-12 mb-3 opacity-30" />
                  <p className="font-medium">No transactions found</p>
                  <p className="text-sm mt-1">Create your first transaction</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Txn ID</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Amount (Rs.)</TableHead>
                        <TableHead className="hidden md:table-cell">Account</TableHead>
                        <TableHead className="hidden md:table-cell">Customer</TableHead>
                        <TableHead className="hidden lg:table-cell">Payment Method</TableHead>
                        <TableHead className="hidden md:table-cell">Date</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="w-10"></TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filtered.map((txn) => {
                        const config = statusConfig[txn.status] || statusConfig.pending;
                        const StatusIcon = config.icon;
                        return (
                          <TableRow key={txn.id} data-testid={`row-transaction-${txn.id}`}>
                            <TableCell className="font-mono text-xs" data-testid={`text-txn-id-${txn.id}`}>{txn.txnId}</TableCell>
                            <TableCell>
                              <Badge variant="secondary" className={`no-default-active-elevate text-[10px] capitalize ${typeConfig[txn.type] || ""}`} data-testid={`badge-txn-type-${txn.id}`}>
                                {txn.type}
                              </Badge>
                            </TableCell>
                            <TableCell className="font-semibold" data-testid={`text-txn-amount-${txn.id}`}>
                              Rs. {Number(txn.amount).toLocaleString()}
                            </TableCell>
                            <TableCell className="hidden md:table-cell text-sm text-muted-foreground" data-testid={`text-txn-account-${txn.id}`}>
                              {(txn as any).accountName || (txn.accountId ? `#${txn.accountId}` : "-")}
                            </TableCell>
                            <TableCell className="hidden md:table-cell text-sm text-muted-foreground" data-testid={`text-txn-customer-${txn.id}`}>
                              {(txn as any).customerName || (txn.customerId ? `#${txn.customerId}` : "-")}
                            </TableCell>
                            <TableCell className="hidden lg:table-cell text-sm" data-testid={`text-txn-method-${txn.id}`}>
                              {txn.paymentMethod ? paymentMethodLabels[txn.paymentMethod] || txn.paymentMethod : "-"}
                            </TableCell>
                            <TableCell className="hidden md:table-cell text-sm text-muted-foreground" data-testid={`text-txn-date-${txn.id}`}>
                              {txn.date}
                            </TableCell>
                            <TableCell>
                              <Badge variant="secondary" className={`no-default-active-elevate text-[10px] capitalize ${config.color}`} data-testid={`badge-txn-status-${txn.id}`}>
                                <StatusIcon className="h-3 w-3 mr-1" />
                                {txn.status}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon" data-testid={`button-txn-actions-${txn.id}`}>
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem onClick={() => { setViewingTransaction(txn); setDetailDialogOpen(true); }} data-testid={`button-view-txn-${txn.id}`}>
                                    <Eye className="h-4 w-4 mr-2" />
                                    View Detail
                                  </DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => printSingleSlip(txn)} data-testid={`button-print-txn-${txn.id}`}>
                                    <Printer className="h-4 w-4 mr-2" />
                                    Print Slip
                                  </DropdownMenuItem>
                                  <DropdownMenuItem onClick={() => openEdit(txn)} data-testid={`button-edit-txn-${txn.id}`}>
                                    <Edit className="h-4 w-4 mr-2" />
                                    Edit
                                  </DropdownMenuItem>
                                  <DropdownMenuItem
                                    className="text-destructive"
                                    onClick={() => deleteMutation.mutate(txn.id)}
                                    data-testid={`button-delete-txn-${txn.id}`}
                                  >
                                    <Trash2 className="h-4 w-4 mr-2" />
                                    Delete
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>)}

        {activeTab === "customer-collections" && (<div className="mt-5">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex flex-row items-center justify-between gap-2 flex-wrap">
                <div>
                  <CardTitle className="text-lg">Customer Collections</CardTitle>
                  <CardDescription>Payments received from customers</CardDescription>
                </div>
                <Badge variant="secondary" className="no-default-active-elevate" data-testid="badge-customer-collections-count">
                  <Users className="h-3 w-3 mr-1" />
                  {customerTxns.length} transactions
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              {renderTransactionTable(customerTxns, "No customer collections found")}
            </CardContent>
          </Card>
        </div>)}

        {activeTab === "reseller-collections" && (<div className="mt-5">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex flex-row items-center justify-between gap-2 flex-wrap">
                <div>
                  <CardTitle className="text-lg">Reseller Collections</CardTitle>
                  <CardDescription>Transactions related to resellers and partners</CardDescription>
                </div>
                <Badge variant="secondary" className="no-default-active-elevate" data-testid="badge-reseller-collections-count">
                  <Store className="h-3 w-3 mr-1" />
                  {resellerTxns.length} transactions
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              {renderTransactionTable(resellerTxns, "No reseller collections found")}
            </CardContent>
          </Card>
        </div>)}

        {activeTab === "refund" && (<div className="mt-5">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex flex-row items-center justify-between gap-2 flex-wrap">
                <div>
                  <CardTitle className="text-lg">Refund & Credit Notes</CardTitle>
                  <CardDescription>Manage refunds and credit note transactions</CardDescription>
                </div>
                <Badge variant="secondary" className="no-default-active-elevate" data-testid="badge-refund-count">
                  <RefreshCw className="h-3 w-3 mr-1" />
                  {refundTxns.length} refunds
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              {renderTransactionTable(refundTxns, "No refund or credit note transactions found")}
            </CardContent>
          </Card>
        </div>)}

        {activeTab === "transfer" && (<div className="mt-5">
          <div className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Account Transfer</CardTitle>
                <CardDescription>Transfer funds between accounts</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">From Account</label>
                    <Select data-testid="select-transfer-from">
                      <SelectTrigger data-testid="select-transfer-from-trigger">
                        <SelectValue placeholder="Select source account" />
                      </SelectTrigger>
                      <SelectContent>
                        {(accountsList || []).map((a) => (
                          <SelectItem key={a.id} value={a.id.toString()}>
                            {a.code} - {a.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">To Account</label>
                    <Select data-testid="select-transfer-to">
                      <SelectTrigger data-testid="select-transfer-to-trigger">
                        <SelectValue placeholder="Select destination account" />
                      </SelectTrigger>
                      <SelectContent>
                        {(accountsList || []).map((a) => (
                          <SelectItem key={a.id} value={a.id.toString()}>
                            {a.code} - {a.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Amount (Rs.)</label>
                    <Input type="number" placeholder="0.00" data-testid="input-transfer-amount" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Date</label>
                    <Input type="date" defaultValue={new Date().toISOString().split("T")[0]} data-testid="input-transfer-date" />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Description</label>
                  <Textarea placeholder="Transfer description..." data-testid="input-transfer-description" />
                </div>
                <div className="flex justify-end">
                  <Button data-testid="button-submit-transfer">
                    <Send className="h-4 w-4 mr-1" />
                    Submit Transfer
                  </Button>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Recent Transfers</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                {renderTransactionTable(
                  allTxns.filter((t) => t.type === "adjustment"),
                  "No transfer transactions found"
                )}
              </CardContent>
            </Card>
          </div>
        </div>)}

        {activeTab === "wallet" && (<div className="mt-5">
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Card data-testid="card-wallet-balance">
                <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
                  <CardTitle className="text-sm font-medium">Wallet Balance</CardTitle>
                  <Wallet className="h-5 w-5 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold" data-testid="text-wallet-balance">
                    Rs. {allTxns.filter((t) => t.type === "credit").reduce((s, t) => s + Number(t.amount), 0).toLocaleString()}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">Available balance</p>
                </CardContent>
              </Card>
              <Card data-testid="card-prepaid-balance">
                <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
                  <CardTitle className="text-sm font-medium">Prepaid Credits</CardTitle>
                  <DollarSign className="h-5 w-5 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold" data-testid="text-prepaid-balance">
                    Rs. {allTxns.filter((t) => t.type === "payment" && t.paymentMethod === "online").reduce((s, t) => s + Number(t.amount), 0).toLocaleString()}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">Online prepaid amount</p>
                </CardContent>
              </Card>
              <Card data-testid="card-total-spent">
                <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
                  <CardTitle className="text-sm font-medium">Total Spent</CardTitle>
                  <TrendingDown className="h-5 w-5 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold" data-testid="text-total-spent">
                    Rs. {allTxns.filter((t) => t.type === "debit").reduce((s, t) => s + Number(t.amount), 0).toLocaleString()}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">Total debit transactions</p>
                </CardContent>
              </Card>
            </div>
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Wallet Transactions</CardTitle>
                <CardDescription>All wallet and prepaid transactions</CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                {renderTransactionTable(
                  allTxns.filter((t) => t.paymentMethod === "online" || t.paymentMethod === "jazzcash" || t.paymentMethod === "easypaisa"),
                  "No wallet or prepaid transactions found"
                )}
              </CardContent>
            </Card>
          </div>
        </div>)}

        {activeTab === "approval" && (<div className="mt-5">
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Card data-testid="card-pending-approvals">
                <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
                  <CardTitle className="text-sm font-medium">Pending Approvals</CardTitle>
                  <Clock className="h-5 w-5 text-amber-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold" data-testid="text-pending-count">
                    {pendingApprovals.length}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">Awaiting review</p>
                </CardContent>
              </Card>
              <Card data-testid="card-approved-count">
                <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
                  <CardTitle className="text-sm font-medium">Approved</CardTitle>
                  <CheckCircle className="h-5 w-5 text-green-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold" data-testid="text-approved-count">
                    {allTxns.filter((t) => t.status === "completed").length}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">Completed transactions</p>
                </CardContent>
              </Card>
              <Card data-testid="card-rejected-count">
                <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
                  <CardTitle className="text-sm font-medium">Rejected</CardTitle>
                  <XCircle className="h-5 w-5 text-red-500" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold" data-testid="text-rejected-count">
                    {allTxns.filter((t) => t.status === "failed").length}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">Failed or rejected</p>
                </CardContent>
              </Card>
            </div>
            <Card>
              <CardHeader className="pb-3">
                <div className="flex flex-row items-center justify-between gap-2 flex-wrap">
                  <div>
                    <CardTitle className="text-lg">Pending Approval Queue</CardTitle>
                    <CardDescription>Transactions waiting for approval</CardDescription>
                  </div>
                  <Badge variant="secondary" className="no-default-active-elevate" data-testid="badge-pending-approval-count">
                    <ShieldCheck className="h-3 w-3 mr-1" />
                    {pendingApprovals.length} pending
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                {renderTransactionTable(pendingApprovals, "No pending approvals")}
              </CardContent>
            </Card>
          </div>
        </div>)}

      <Dialog open={detailDialogOpen} onOpenChange={setDetailDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Transaction Detail
            </DialogTitle>
          </DialogHeader>
          {viewingTransaction && (() => {
            const txn = viewingTransaction;
            const customer = (customers || []).find((c) => c.id === txn.customerId);
            const account = (accountsList || []).find((a) => a.id === txn.accountId);
            const config = statusConfig[txn.status] || statusConfig.pending;
            const StatusIcon = config.icon;
            return (
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                  <Badge variant="secondary" className={`no-default-active-elevate capitalize ${typeConfig[txn.type] || ""}`}>
                    {txn.type}
                  </Badge>
                  <span className="text-xl font-bold">Rs. {Number(txn.amount).toLocaleString()}</span>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Transaction ID</span>
                    <span className="font-mono font-medium">{txn.txnId}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Date</span>
                    <span className="font-medium">{txn.date}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Status</span>
                    <Badge variant="secondary" className={`no-default-active-elevate text-[10px] capitalize ${config.color}`}>
                      <StatusIcon className="h-3 w-3 mr-1" />
                      {txn.status}
                    </Badge>
                  </div>
                  <div className="border-t my-1" />
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Payment Method</span>
                    <span className="font-medium capitalize">{txn.paymentMethod ? (paymentMethodLabels[txn.paymentMethod] || txn.paymentMethod) : "—"}</span>
                  </div>
                  {account && (
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Account</span>
                      <span className="font-medium">{account.code} - {account.name}</span>
                    </div>
                  )}
                  {customer && (
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Customer</span>
                      <span className="font-medium">{customer.fullName} ({customer.customerId})</span>
                    </div>
                  )}
                  {txn.reference && (
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Reference</span>
                      <span className="font-medium">{txn.reference}</span>
                    </div>
                  )}
                  {txn.description && (
                    <>
                      <div className="border-t my-1" />
                      <div className="text-sm">
                        <span className="text-muted-foreground block mb-1">Description</span>
                        <p className="p-2 rounded bg-muted/50 text-sm">{txn.description}</p>
                      </div>
                    </>
                  )}
                </div>
              </div>
            );
          })()}
          <DialogFooter>
            <Button variant="outline" onClick={() => setDetailDialogOpen(false)} data-testid="button-close-detail">
              Close
            </Button>
            {viewingTransaction && (
              <Button onClick={() => printSingleSlip(viewingTransaction)} data-testid="button-print-slip">
                <Printer className="h-4 w-4 mr-1" />
                Print Slip
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingTransaction ? "Edit Transaction" : "Add Transaction"}</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="txnId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Transaction ID</FormLabel>
                      <FormControl>
                        <Input placeholder="TXN-001" data-testid="input-txn-id" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Type</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value || "payment"}>
                        <FormControl>
                          <SelectTrigger data-testid="select-txn-type">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="credit">Credit</SelectItem>
                          <SelectItem value="debit">Debit</SelectItem>
                          <SelectItem value="payment">Payment</SelectItem>
                          <SelectItem value="refund">Refund</SelectItem>
                          <SelectItem value="adjustment">Adjustment</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="amount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Amount (Rs.)</FormLabel>
                      <FormControl>
                        <Input type="number" step="0.01" placeholder="0.00" data-testid="input-txn-amount" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="date"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Date</FormLabel>
                      <FormControl>
                        <Input type="date" data-testid="input-txn-date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="accountId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Account</FormLabel>
                      <Select
                        onValueChange={(v) => field.onChange(v === "none" ? null : parseInt(v))}
                        value={field.value?.toString() || "none"}
                      >
                        <FormControl>
                          <SelectTrigger data-testid="select-txn-account">
                            <SelectValue placeholder="Select account" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="none">None</SelectItem>
                          {(accountsList || []).map((a) => (
                            <SelectItem key={a.id} value={a.id.toString()}>
                              {a.code} - {a.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="customerId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Customer</FormLabel>
                      <Select
                        onValueChange={(v) => field.onChange(v === "none" ? null : parseInt(v))}
                        value={field.value?.toString() || "none"}
                      >
                        <FormControl>
                          <SelectTrigger data-testid="select-txn-customer">
                            <SelectValue placeholder="Select customer" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="none">None</SelectItem>
                          {(customers || []).map((c) => (
                            <SelectItem key={c.id} value={c.id.toString()}>
                              {c.fullName} ({c.customerId})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="paymentMethod"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Payment Method</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value || "cash"}>
                        <FormControl>
                          <SelectTrigger data-testid="select-txn-payment-method">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="cash">Cash</SelectItem>
                          <SelectItem value="bank_transfer">Bank Transfer</SelectItem>
                          <SelectItem value="cheque">Cheque</SelectItem>
                          <SelectItem value="online">Online</SelectItem>
                          <SelectItem value="jazzcash">JazzCash</SelectItem>
                          <SelectItem value="easypaisa">EasyPaisa</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Status</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value || "completed"}>
                        <FormControl>
                          <SelectTrigger data-testid="select-txn-status">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="completed">Completed</SelectItem>
                          <SelectItem value="pending">Pending</SelectItem>
                          <SelectItem value="failed">Failed</SelectItem>
                          <SelectItem value="reversed">Reversed</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={form.control}
                name="invoiceId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Invoice ID (optional)</FormLabel>
                    <FormControl>
                      <Input
                        type="number"
                        placeholder="Leave empty if not linked"
                        data-testid="input-txn-invoice-id"
                        value={field.value ?? ""}
                        onChange={(e) => field.onChange(e.target.value ? parseInt(e.target.value) : null)}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="reference"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Reference</FormLabel>
                    <FormControl>
                      <Input placeholder="Reference number..." data-testid="input-txn-reference" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Transaction details..." data-testid="input-txn-description" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="button" variant="secondary" onClick={() => setDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending} data-testid="button-save-transaction">
                  {createMutation.isPending || updateMutation.isPending ? "Saving..." : editingTransaction ? "Update" : "Create"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}