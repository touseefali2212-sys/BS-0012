import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Plus,
  Search,
  MoreHorizontal,
  Edit,
  Trash2,
  ClipboardList,
  CheckCircle,
  Clock,
  AlertCircle,
  XCircle,
  Calendar,
  Users,
  FolderKanban,
  History,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Progress } from "@/components/ui/progress";
import { useTab } from "@/hooks/use-tab";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertTaskSchema, type Task, type InsertTask, type Customer } from "@shared/schema";
import { z } from "zod";

const taskFormSchema = insertTaskSchema.extend({
  title: z.string().min(2, "Title is required"),
  type: z.string().min(1, "Type is required"),
});

export default function TasksPage() {
  const { toast } = useToast();
  const [tab, changeTab] = useTab("list");
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);

  const { data: tasks, isLoading } = useQuery<(Task & { customerName?: string })[]>({
    queryKey: ["/api/tasks"],
  });

  const { data: customers } = useQuery<Customer[]>({
    queryKey: ["/api/customers"],
  });

  const form = useForm<InsertTask>({
    resolver: zodResolver(taskFormSchema),
    defaultValues: {
      title: "",
      type: "general",
      description: "",
      priority: "medium",
      status: "pending",
      assignedTo: "",
      customerId: undefined,
      dueDate: "",
      completedDate: "",
      notes: "",
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertTask) => {
      const res = await apiRequest("POST", "/api/tasks", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      setDialogOpen(false);
      form.reset();
      toast({ title: "Task created successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertTask> }) => {
      const res = await apiRequest("PATCH", `/api/tasks/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      setDialogOpen(false);
      setEditingTask(null);
      form.reset();
      toast({ title: "Task updated successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/tasks/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({ title: "Task deleted" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const openCreate = () => {
    setEditingTask(null);
    form.reset({
      title: "",
      type: "general",
      description: "",
      priority: "medium",
      status: "pending",
      assignedTo: "",
      customerId: undefined,
      dueDate: "",
      completedDate: "",
      notes: "",
    });
    setDialogOpen(true);
  };

  const openEdit = (task: Task) => {
    setEditingTask(task);
    form.reset({
      title: task.title,
      type: task.type,
      description: task.description || "",
      priority: task.priority,
      status: task.status,
      assignedTo: task.assignedTo || "",
      customerId: task.customerId ?? undefined,
      dueDate: task.dueDate || "",
      completedDate: task.completedDate || "",
      notes: task.notes || "",
    });
    setDialogOpen(true);
  };

  const onSubmit = (data: InsertTask) => {
    if (editingTask) {
      updateMutation.mutate({ id: editingTask.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const filtered = (tasks || []).filter((t) => {
    const matchSearch =
      t.title.toLowerCase().includes(search.toLowerCase()) ||
      (t.assignedTo || "").toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === "all" || t.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const statusConfig: Record<string, { icon: any; color: string }> = {
    pending: { icon: Clock, color: "text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950" },
    in_progress: { icon: AlertCircle, color: "text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950" },
    completed: { icon: CheckCircle, color: "text-green-700 dark:text-green-300 bg-green-50 dark:bg-green-950" },
    cancelled: { icon: XCircle, color: "text-gray-500 bg-gray-50 dark:bg-gray-900" },
  };

  const priorityColors: Record<string, string> = {
    critical: "text-red-700 dark:text-red-300 bg-red-100 dark:bg-red-900",
    high: "text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950",
    medium: "text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950",
    low: "text-green-600 dark:text-green-400 bg-green-50 dark:bg-green-950",
  };

  const typeColors: Record<string, string> = {
    installation: "text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950",
    repair: "text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950",
    upgrade: "text-purple-600 dark:text-purple-400 bg-purple-50 dark:bg-purple-950",
    maintenance: "text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950",
    general: "text-gray-600 dark:text-gray-400 bg-gray-50 dark:bg-gray-900",
  };

  const allTasks = tasks || [];
  const totalTasks = allTasks.length;
  const completedTasks = allTasks.filter((t) => t.status === "completed").length;
  const pendingTasks = allTasks.filter((t) => t.status === "pending").length;
  const inProgressTasks = allTasks.filter((t) => t.status === "in_progress").length;
  const cancelledTasks = allTasks.filter((t) => t.status === "cancelled").length;
  const completionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  const tasksByType = allTasks.reduce<Record<string, (Task & { customerName?: string })[]>>((acc, task) => {
    const type = task.type || "general";
    if (!acc[type]) acc[type] = [];
    acc[type].push(task);
    return acc;
  }, {});

  const assigneeMap = allTasks.reduce<Record<string, { total: number; completed: number; inProgress: number; pending: number; tasks: (Task & { customerName?: string })[] }>>((acc, task) => {
    const assignee = task.assignedTo || "Unassigned";
    if (!acc[assignee]) acc[assignee] = { total: 0, completed: 0, inProgress: 0, pending: 0, tasks: [] };
    acc[assignee].total++;
    acc[assignee].tasks.push(task);
    if (task.status === "completed") acc[assignee].completed++;
    else if (task.status === "in_progress") acc[assignee].inProgress++;
    else if (task.status === "pending") acc[assignee].pending++;
    return acc;
  }, {});

  const completedTasksList = allTasks
    .filter((t) => t.status === "completed")
    .sort((a, b) => (b.completedDate || "").localeCompare(a.completedDate || ""));

  return (
    <div className="p-6 space-y-6 max-w-[1400px] mx-auto">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight" data-testid="text-tasks-title">Task Management</h1>
          <p className="text-sm text-muted-foreground mt-0.5">Manage field operations and assignments</p>
        </div>
        <Button onClick={openCreate} data-testid="button-add-task">
          <Plus className="h-4 w-4 mr-1" />
          Create Task
        </Button>
      </div>

      {tab === "projects" && (<div className="mt-5" data-testid="tab-content-projects">
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-40 w-full" />
              ))}
            </div>
          ) : Object.keys(tasksByType).length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                <FolderKanban className="h-12 w-12 mb-3 opacity-30" />
                <p className="font-medium">No projects found</p>
                <p className="text-sm mt-1">Create tasks to see project groupings</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {Object.entries(tasksByType).map(([type, typeTasks]) => {
                const typeCompleted = typeTasks.filter((t) => t.status === "completed").length;
                const typeProgress = typeTasks.length > 0 ? Math.round((typeCompleted / typeTasks.length) * 100) : 0;
                return (
                  <Card key={type} data-testid={`card-project-${type}`}>
                    <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
                      <div className="flex items-center gap-2">
                        <Badge variant="secondary" className={`no-default-active-elevate text-[10px] capitalize ${typeColors[type] || ""}`}>
                          {type}
                        </Badge>
                      </div>
                      <span className="text-sm text-muted-foreground" data-testid={`text-project-count-${type}`}>
                        {typeTasks.length} {typeTasks.length === 1 ? "task" : "tasks"}
                      </span>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">Progress</span>
                          <span className="font-medium" data-testid={`text-project-progress-${type}`}>{typeProgress}%</span>
                        </div>
                        <Progress value={typeProgress} className="h-2" data-testid={`progress-project-${type}`} />
                      </div>
                      <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
                        <span data-testid={`text-project-completed-${type}`}>
                          <CheckCircle className="h-3 w-3 inline mr-1 text-green-600 dark:text-green-400" />
                          {typeCompleted} completed
                        </span>
                        <span data-testid={`text-project-pending-${type}`}>
                          <Clock className="h-3 w-3 inline mr-1 text-blue-600 dark:text-blue-400" />
                          {typeTasks.filter((t) => t.status === "pending").length} pending
                        </span>
                        <span data-testid={`text-project-inprogress-${type}`}>
                          <AlertCircle className="h-3 w-3 inline mr-1 text-amber-600 dark:text-amber-400" />
                          {typeTasks.filter((t) => t.status === "in_progress").length} in progress
                        </span>
                      </div>
                      <div className="space-y-1 pt-1">
                        {typeTasks.slice(0, 3).map((t) => {
                          const cfg = statusConfig[t.status] || statusConfig.pending;
                          return (
                            <div key={t.id} className="flex items-center justify-between text-sm" data-testid={`text-project-task-${t.id}`}>
                              <span className="truncate max-w-[180px]">{t.title}</span>
                              <Badge variant="secondary" className={`no-default-active-elevate text-[9px] capitalize ${cfg.color}`}>
                                {t.status.replace("_", " ")}
                              </Badge>
                            </div>
                          );
                        })}
                        {typeTasks.length > 3 && (
                          <p className="text-xs text-muted-foreground">+{typeTasks.length - 3} more</p>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </div>)}

      {tab === "list" && (<div className="mt-5" data-testid="tab-content-list">
          <Card>
            <CardHeader className="pb-3">
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
                <div className="relative flex-1 w-full sm:max-w-xs">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search tasks..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="pl-9"
                    data-testid="input-search-tasks"
                  />
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[160px]" data-testid="select-task-status-filter">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="in_progress">In Progress</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="cancelled">Cancelled</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              {isLoading ? (
                <div className="p-5 space-y-3">
                  {[1, 2, 3].map((i) => (
                    <Skeleton key={i} className="h-14 w-full" />
                  ))}
                </div>
              ) : filtered.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                  <ClipboardList className="h-12 w-12 mb-3 opacity-30" />
                  <p className="font-medium">No tasks found</p>
                  <p className="text-sm mt-1">Create a new task to get started</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Title</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead className="hidden md:table-cell">Customer</TableHead>
                        <TableHead className="hidden lg:table-cell">Assigned To</TableHead>
                        <TableHead>Priority</TableHead>
                        <TableHead className="hidden lg:table-cell">Due Date</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="w-10"></TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filtered.map((task) => {
                        const config = statusConfig[task.status] || statusConfig.pending;
                        const StatusIcon = config.icon;
                        return (
                          <TableRow key={task.id} data-testid={`row-task-${task.id}`}>
                            <TableCell>
                              <div className="font-medium max-w-[200px] truncate">{task.title}</div>
                            </TableCell>
                            <TableCell>
                              <Badge variant="secondary" className={`no-default-active-elevate text-[10px] capitalize ${typeColors[task.type] || ""}`}>
                                {task.type}
                              </Badge>
                            </TableCell>
                            <TableCell className="hidden md:table-cell text-sm text-muted-foreground">
                              {task.customerName || (task.customerId ? `#${task.customerId}` : "\u2014")}
                            </TableCell>
                            <TableCell className="hidden lg:table-cell text-sm text-muted-foreground">
                              {task.assignedTo || "\u2014"}
                            </TableCell>
                            <TableCell>
                              <Badge variant="secondary" className={`no-default-active-elevate text-[10px] capitalize ${priorityColors[task.priority] || ""}`}>
                                {task.priority}
                              </Badge>
                            </TableCell>
                            <TableCell className="hidden lg:table-cell text-sm text-muted-foreground">
                              {task.dueDate || "\u2014"}
                            </TableCell>
                            <TableCell>
                              <Badge variant="secondary" className={`no-default-active-elevate text-[10px] capitalize ${config.color}`}>
                                <StatusIcon className="h-3 w-3 mr-1" />
                                {task.status.replace("_", " ")}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon" data-testid={`button-task-actions-${task.id}`}>
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem onClick={() => openEdit(task)} data-testid={`button-edit-task-${task.id}`}>
                                    <Edit className="h-4 w-4 mr-2" />
                                    Edit
                                  </DropdownMenuItem>
                                  <DropdownMenuItem
                                    className="text-destructive"
                                    onClick={() => deleteMutation.mutate(task.id)}
                                    data-testid={`button-delete-task-${task.id}`}
                                  >
                                    <Trash2 className="h-4 w-4 mr-2" />
                                    Delete
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>)}

      {tab === "team" && (<div className="mt-5" data-testid="tab-content-team">
          {isLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-20 w-full" />
              ))}
            </div>
          ) : Object.keys(assigneeMap).length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                <Users className="h-12 w-12 mb-3 opacity-30" />
                <p className="font-medium">No team members found</p>
                <p className="text-sm mt-1">Assign tasks to team members to see them here</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {Object.entries(assigneeMap).map(([assignee, data]) => {
                const rate = data.total > 0 ? Math.round((data.completed / data.total) * 100) : 0;
                return (
                  <Card key={assignee} data-testid={`card-team-member-${assignee}`}>
                    <CardContent className="py-4">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <div className="flex items-center justify-center h-9 w-9 rounded-full bg-muted text-sm font-medium">
                            {assignee.charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <p className="font-medium" data-testid={`text-team-name-${assignee}`}>{assignee}</p>
                            <p className="text-xs text-muted-foreground" data-testid={`text-team-task-count-${assignee}`}>
                              {data.total} {data.total === 1 ? "task" : "tasks"} assigned
                            </p>
                          </div>
                        </div>
                        <div className="flex flex-wrap items-center gap-3">
                          <Badge variant="secondary" className="no-default-active-elevate text-[10px] text-green-700 dark:text-green-300 bg-green-50 dark:bg-green-950" data-testid={`badge-team-completed-${assignee}`}>
                            <CheckCircle className="h-3 w-3 mr-1" />
                            {data.completed} completed
                          </Badge>
                          <Badge variant="secondary" className="no-default-active-elevate text-[10px] text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950" data-testid={`badge-team-inprogress-${assignee}`}>
                            <AlertCircle className="h-3 w-3 mr-1" />
                            {data.inProgress} in progress
                          </Badge>
                          <Badge variant="secondary" className="no-default-active-elevate text-[10px] text-blue-700 dark:text-blue-300 bg-blue-50 dark:bg-blue-950" data-testid={`badge-team-pending-${assignee}`}>
                            <Clock className="h-3 w-3 mr-1" />
                            {data.pending} pending
                          </Badge>
                        </div>
                      </div>
                      <div className="mt-3 space-y-1.5">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">Completion Rate</span>
                          <span className="font-medium" data-testid={`text-team-rate-${assignee}`}>{rate}%</span>
                        </div>
                        <Progress value={rate} className="h-2" data-testid={`progress-team-${assignee}`} />
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </div>)}

      {tab === "progress" && (<div className="mt-5" data-testid="tab-content-progress">
          {isLoading ? (
            <div className="space-y-4">
              {[1, 2, 3, 4].map((i) => (
                <Skeleton key={i} className="h-24 w-full" />
              ))}
            </div>
          ) : (
            <div className="space-y-6">
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <Card data-testid="card-metric-total">
                  <CardContent className="py-4">
                    <p className="text-sm text-muted-foreground">Total Tasks</p>
                    <p className="text-2xl font-bold mt-1" data-testid="text-metric-total">{totalTasks}</p>
                  </CardContent>
                </Card>
                <Card data-testid="card-metric-completed">
                  <CardContent className="py-4">
                    <p className="text-sm text-muted-foreground">Completed</p>
                    <p className="text-2xl font-bold mt-1 text-green-600 dark:text-green-400" data-testid="text-metric-completed">{completedTasks}</p>
                  </CardContent>
                </Card>
                <Card data-testid="card-metric-inprogress">
                  <CardContent className="py-4">
                    <p className="text-sm text-muted-foreground">In Progress</p>
                    <p className="text-2xl font-bold mt-1 text-amber-600 dark:text-amber-400" data-testid="text-metric-inprogress">{inProgressTasks}</p>
                  </CardContent>
                </Card>
                <Card data-testid="card-metric-pending">
                  <CardContent className="py-4">
                    <p className="text-sm text-muted-foreground">Pending</p>
                    <p className="text-2xl font-bold mt-1 text-blue-600 dark:text-blue-400" data-testid="text-metric-pending">{pendingTasks}</p>
                  </CardContent>
                </Card>
              </div>

              <Card data-testid="card-overall-progress">
                <CardHeader className="pb-2">
                  <p className="font-medium">Overall Completion</p>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">{completedTasks} of {totalTasks} tasks completed</span>
                    <span className="font-medium" data-testid="text-overall-rate">{completionRate}%</span>
                  </div>
                  <Progress value={completionRate} className="h-3" data-testid="progress-overall" />
                </CardContent>
              </Card>

              <Card data-testid="card-status-breakdown">
                <CardHeader className="pb-2">
                  <p className="font-medium">Status Breakdown</p>
                </CardHeader>
                <CardContent className="space-y-3">
                  {[
                    { label: "Completed", count: completedTasks, color: "text-green-600 dark:text-green-400", barColor: "bg-green-500" },
                    { label: "In Progress", count: inProgressTasks, color: "text-amber-600 dark:text-amber-400", barColor: "bg-amber-500" },
                    { label: "Pending", count: pendingTasks, color: "text-blue-600 dark:text-blue-400", barColor: "bg-blue-500" },
                    { label: "Cancelled", count: cancelledTasks, color: "text-gray-500", barColor: "bg-gray-400" },
                  ].map((item) => {
                    const pct = totalTasks > 0 ? Math.round((item.count / totalTasks) * 100) : 0;
                    return (
                      <div key={item.label} className="space-y-1" data-testid={`status-breakdown-${item.label.toLowerCase().replace(" ", "-")}`}>
                        <div className="flex items-center justify-between text-sm">
                          <span className={item.color}>{item.label}</span>
                          <span className="text-muted-foreground">{item.count} ({pct}%)</span>
                        </div>
                        <div className="h-2 rounded-full bg-muted overflow-hidden">
                          <div className={`h-full rounded-full ${item.barColor}`} style={{ width: `${pct}%` }} />
                        </div>
                      </div>
                    );
                  })}
                </CardContent>
              </Card>

              <Card data-testid="card-priority-breakdown">
                <CardHeader className="pb-2">
                  <p className="font-medium">Priority Distribution</p>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    {["critical", "high", "medium", "low"].map((priority) => {
                      const count = allTasks.filter((t) => t.priority === priority).length;
                      return (
                        <div key={priority} className="text-center" data-testid={`priority-stat-${priority}`}>
                          <Badge variant="secondary" className={`no-default-active-elevate text-[10px] capitalize ${priorityColors[priority] || ""}`}>
                            {priority}
                          </Badge>
                          <p className="text-lg font-bold mt-1">{count}</p>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>)}

      {tab === "audit" && (<div className="mt-5" data-testid="tab-content-audit">
          {isLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : completedTasksList.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                <History className="h-12 w-12 mb-3 opacity-30" />
                <p className="font-medium">No completed tasks yet</p>
                <p className="text-sm mt-1">Completed tasks will appear here as an audit trail</p>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Task</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead className="hidden md:table-cell">Assigned To</TableHead>
                      <TableHead className="hidden md:table-cell">Due Date</TableHead>
                      <TableHead>Completed Date</TableHead>
                      <TableHead>Priority</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {completedTasksList.map((task) => (
                      <TableRow key={task.id} data-testid={`row-audit-${task.id}`}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400 shrink-0" />
                            <span className="font-medium truncate max-w-[200px]">{task.title}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary" className={`no-default-active-elevate text-[10px] capitalize ${typeColors[task.type] || ""}`}>
                            {task.type}
                          </Badge>
                        </TableCell>
                        <TableCell className="hidden md:table-cell text-sm text-muted-foreground">
                          {task.assignedTo || "\u2014"}
                        </TableCell>
                        <TableCell className="hidden md:table-cell text-sm text-muted-foreground">
                          {task.dueDate || "\u2014"}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1.5 text-sm">
                            <Calendar className="h-3.5 w-3.5 text-muted-foreground" />
                            <span data-testid={`text-audit-date-${task.id}`}>{task.completedDate || "\u2014"}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary" className={`no-default-active-elevate text-[10px] capitalize ${priorityColors[task.priority] || ""}`}>
                            {task.priority}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          )}
        </div>)}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingTask ? "Edit Task" : "Create Task"}</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Title</FormLabel>
                    <FormControl>
                      <Input placeholder="Task title" data-testid="input-task-title" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Type</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value || "general"}>
                        <FormControl>
                          <SelectTrigger data-testid="select-task-type">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="installation">Installation</SelectItem>
                          <SelectItem value="repair">Repair</SelectItem>
                          <SelectItem value="upgrade">Upgrade</SelectItem>
                          <SelectItem value="maintenance">Maintenance</SelectItem>
                          <SelectItem value="general">General</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="customerId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Customer</FormLabel>
                      <Select
                        onValueChange={(v) => field.onChange(v === "none" ? undefined : parseInt(v))}
                        value={field.value?.toString() || "none"}
                      >
                        <FormControl>
                          <SelectTrigger data-testid="select-task-customer">
                            <SelectValue placeholder="Select customer" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="none">No customer</SelectItem>
                          {(customers || []).map((c) => (
                            <SelectItem key={c.id} value={c.id.toString()}>
                              {c.fullName}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Task details..." data-testid="input-task-description" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="priority"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Priority</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value || "medium"}>
                        <FormControl>
                          <SelectTrigger data-testid="select-task-priority">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="low">Low</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="high">High</SelectItem>
                          <SelectItem value="critical">Critical</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Status</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value || "pending"}>
                        <FormControl>
                          <SelectTrigger data-testid="select-task-status">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="pending">Pending</SelectItem>
                          <SelectItem value="in_progress">In Progress</SelectItem>
                          <SelectItem value="completed">Completed</SelectItem>
                          <SelectItem value="cancelled">Cancelled</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={form.control}
                name="assignedTo"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Assigned To</FormLabel>
                    <FormControl>
                      <Input placeholder="Technician name" data-testid="input-task-assigned-to" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="dueDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Due Date</FormLabel>
                      <FormControl>
                        <Input type="date" data-testid="input-task-due-date" {...field} value={field.value || ""} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="completedDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Completed Date</FormLabel>
                      <FormControl>
                        <Input type="date" data-testid="input-task-completed-date" {...field} value={field.value || ""} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes</FormLabel>
                    <FormControl>
                      <Textarea placeholder="Additional notes..." data-testid="input-task-notes" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="button" variant="secondary" onClick={() => setDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending} data-testid="button-save-task">
                  {createMutation.isPending || updateMutation.isPending ? "Saving..." : editingTask ? "Update" : "Create"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
