import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, boolean, decimal, serial } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  email: text("email").notNull(),
  role: text("role").notNull().default("staff"),
  avatar: text("avatar"),
  isActive: boolean("is_active").notNull().default(true),
});

export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  customerId: text("customer_id").notNull().unique(),
  fullName: text("full_name").notNull(),
  email: text("email"),
  phone: text("phone").notNull(),
  cnic: text("cnic"),
  address: text("address"),
  area: text("area"),
  customerType: text("customer_type").notNull().default("home"),
  packageId: integer("package_id"),
  status: text("status").notNull().default("active"),
  connectionDate: text("connection_date"),
  monthlyBill: decimal("monthly_bill", { precision: 10, scale: 2 }),
  notes: text("notes"),
  isRecurring: boolean("is_recurring").notNull().default(true),
  recurringDay: integer("recurring_day").default(1),
  nextBillingDate: text("next_billing_date"),
  lastBilledDate: text("last_billed_date"),
  gender: text("gender"),
  occupation: text("occupation"),
  dateOfBirth: text("date_of_birth"),
  fatherName: text("father_name"),
  motherName: text("mother_name"),
  nidNumber: text("nid_number"),
  registrationFormNo: text("registration_form_no"),
  profilePicture: text("profile_picture"),
  nidPicture: text("nid_picture"),
  registrationFormPicture: text("registration_form_picture"),
  mapLatitude: text("map_latitude"),
  mapLongitude: text("map_longitude"),
  phoneNumber: text("phone_number"),
  district: text("district"),
  upazilaThana: text("upazila_thana"),
  roadNumber: text("road_number"),
  houseNumber: text("house_number"),
  presentAddress: text("present_address"),
  permanentAddress: text("permanent_address"),
  facebookUrl: text("facebook_url"),
  linkedinUrl: text("linkedin_url"),
  twitterUrl: text("twitter_url"),
  server: text("server"),
  protocolType: text("protocol_type"),
  zone: text("zone"),
  subzone: text("subzone"),
  box: text("box"),
  connectionType: text("connection_type"),
  cableRequirement: text("cable_requirement"),
  fiberCode: text("fiber_code"),
  numberOfCore: text("number_of_core"),
  coreColor: text("core_color"),
  device: text("device"),
  deviceMacSerial: text("device_mac_serial"),
  vendorId: integer("vendor_id"),
  purchaseDate: text("purchase_date"),
  profile: text("profile"),
  billingStatus: text("billing_status").default("Inactive"),
  usernameIp: text("username_ip"),
  password: text("password"),
  joiningDate: text("joining_date"),
  billingStartMonth: text("billing_start_month"),
  expireDate: text("expire_date"),
  referenceBy: text("reference_by"),
  isVipClient: boolean("is_vip_client").default(false),
  connectedBy: text("connected_by"),
  assignTo: text("assign_to"),
  affiliator: text("affiliator"),
  sendSmsToEmployee: boolean("send_sms_to_employee").default(false),
  sendGreetingSms: boolean("send_greeting_sms").default(false),
});

export const packages = pgTable("packages", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  serviceType: text("service_type").notNull().default("internet"),
  speed: text("speed"),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  billingCycle: text("billing_cycle").notNull().default("monthly"),
  dataLimit: text("data_limit"),
  channels: text("channels"),
  features: text("features"),
  description: text("description"),
  isActive: boolean("is_active").notNull().default(true),
  vendorId: integer("vendor_id"),
  whTax: decimal("wh_tax", { precision: 5, scale: 2 }),
  aitTax: decimal("ait_tax", { precision: 5, scale: 2 }),
});

export const invoices = pgTable("invoices", {
  id: serial("id").primaryKey(),
  invoiceNumber: text("invoice_number").notNull().unique(),
  customerId: integer("customer_id").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  tax: decimal("tax", { precision: 10, scale: 2 }).default("0"),
  totalAmount: decimal("total_amount", { precision: 10, scale: 2 }).notNull(),
  status: text("status").notNull().default("pending"),
  dueDate: text("due_date").notNull(),
  issueDate: text("issue_date").notNull(),
  paidDate: text("paid_date"),
  description: text("description"),
  isRecurring: boolean("is_recurring").notNull().default(false),
  serviceType: text("service_type"),
});

export const tickets = pgTable("tickets", {
  id: serial("id").primaryKey(),
  ticketNumber: text("ticket_number").notNull().unique(),
  customerId: integer("customer_id").notNull(),
  subject: text("subject").notNull(),
  description: text("description"),
  priority: text("priority").notNull().default("medium"),
  status: text("status").notNull().default("open"),
  category: text("category").notNull().default("general"),
  assignedTo: text("assigned_to"),
  createdAt: text("created_at").notNull(),
  resolvedAt: text("resolved_at"),
});

export const activityLogs = pgTable("activity_logs", {
  id: serial("id").primaryKey(),
  action: text("action").notNull(),
  module: text("module").notNull(),
  description: text("description").notNull(),
  userId: integer("user_id"),
  createdAt: text("created_at").notNull(),
});

export const areas = pgTable("areas", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  city: text("city").notNull(),
  zone: text("zone"),
  branch: text("branch"),
  totalCustomers: integer("total_customers").default(0),
  totalHousesOffices: integer("total_houses_offices").default(0),
  status: text("status").notNull().default("active"),
});

export const vendors = pgTable("vendors", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  vendorType: text("vendor_type").notNull().default("bandwidth"),
  contactPerson: text("contact_person"),
  phone: text("phone").notNull(),
  email: text("email"),
  address: text("address"),
  serviceType: text("service_type").notNull(),
  ntn: text("ntn"),
  bankAccount: text("bank_account"),
  bankName: text("bank_name"),
  bankAccountTitle: text("bank_account_title"),
  bankAccountNumber: text("bank_account_number"),
  bankBranchCode: text("bank_branch_code"),
  slaLevel: text("sla_level").default("standard"),
  totalBandwidth: text("total_bandwidth"),
  usedBandwidth: text("used_bandwidth"),
  bandwidthCost: decimal("bandwidth_cost", { precision: 10, scale: 2 }),
  contractStartDate: text("contract_start_date"),
  contractEndDate: text("contract_end_date"),
  walletBalance: decimal("wallet_balance", { precision: 12, scale: 2 }).default("0"),
  lastRechargeDate: text("last_recharge_date"),
  panelUrl: text("panel_url"),
  panelUsername: text("panel_username"),
  payableAmount: decimal("payable_amount", { precision: 12, scale: 2 }).default("0"),
  city: text("city"),
  status: text("status").notNull().default("active"),
});

export const resellers = pgTable("resellers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  resellerType: text("reseller_type").notNull().default("authorized_dealer"),
  contactName: text("contact_name"),
  phone: text("phone").notNull(),
  email: text("email"),
  address: text("address"),
  area: text("area"),
  vendorId: integer("vendor_id"),
  commissionRate: decimal("commission_rate", { precision: 5, scale: 2 }).default("10"),
  walletBalance: decimal("wallet_balance", { precision: 12, scale: 2 }).default("0"),
  totalCustomers: integer("total_customers").default(0),
  status: text("status").notNull().default("active"),
});

export const accounts = pgTable("accounts", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  parentId: integer("parent_id"),
  balance: decimal("balance", { precision: 12, scale: 2 }).default("0"),
  description: text("description"),
  isActive: boolean("is_active").notNull().default(true),
});

export const transactions = pgTable("transactions", {
  id: serial("id").primaryKey(),
  txnId: text("txn_id").notNull().unique(),
  type: text("type").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  accountId: integer("account_id"),
  customerId: integer("customer_id"),
  invoiceId: integer("invoice_id"),
  paymentMethod: text("payment_method"),
  reference: text("reference"),
  description: text("description"),
  date: text("date").notNull(),
  status: text("status").notNull().default("completed"),
});

export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  type: text("type").notNull().default("general"),
  description: text("description"),
  priority: text("priority").notNull().default("medium"),
  status: text("status").notNull().default("pending"),
  assignedTo: text("assigned_to"),
  customerId: integer("customer_id"),
  dueDate: text("due_date"),
  completedDate: text("completed_date"),
  notes: text("notes"),
});

export const assets = pgTable("assets", {
  id: serial("id").primaryKey(),
  assetTag: text("asset_tag").notNull().unique(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  brand: text("brand"),
  model: text("model"),
  serialNumber: text("serial_number"),
  vendorId: integer("vendor_id"),
  purchaseDate: text("purchase_date"),
  purchaseCost: decimal("purchase_cost", { precision: 10, scale: 2 }),
  warrantyEnd: text("warranty_end"),
  location: text("location"),
  assignedTo: text("assigned_to"),
  status: text("status").notNull().default("available"),
});

export const inventoryItems = pgTable("inventory_items", {
  id: serial("id").primaryKey(),
  sku: text("sku").notNull().unique(),
  itemName: text("item_name").notNull(),
  category: text("category").notNull(),
  quantity: integer("quantity").notNull().default(0),
  unitCost: decimal("unit_cost", { precision: 10, scale: 2 }),
  reorderLevel: integer("reorder_level").default(10),
  vendorId: integer("vendor_id"),
  location: text("location"),
  description: text("description"),
  status: text("status").notNull().default("in_stock"),
});

export const employees = pgTable("employees", {
  id: serial("id").primaryKey(),
  empCode: text("emp_code").notNull().unique(),
  fullName: text("full_name").notNull(),
  email: text("email"),
  phone: text("phone").notNull(),
  cnic: text("cnic"),
  department: text("department").notNull(),
  designation: text("designation").notNull(),
  joinDate: text("join_date"),
  salary: decimal("salary", { precision: 10, scale: 2 }),
  bankAccount: text("bank_account"),
  address: text("address"),
  status: text("status").notNull().default("active"),
  gender: text("gender"),
  dateOfBirth: text("date_of_birth"),
  maritalStatus: text("marital_status"),
  fatherName: text("father_name"),
  guardianPhone: text("guardian_phone"),
  bloodGroup: text("blood_group"),
  religion: text("religion"),
  nationality: text("nationality"),
  emergencyContact: text("emergency_contact"),
  emergencyPhone: text("emergency_phone"),
  city: text("city"),
  country: text("country"),
  bankName: text("bank_name"),
  bankBranch: text("bank_branch"),
  salaryType: text("salary_type").default("monthly"),
  employmentType: text("employment_type").default("full_time"),
  allowances: text("allowances"),
  deductions: text("deductions"),
  qualifications: text("qualifications"),
  experiences: text("experiences"),
  shift: text("shift"),
  reportingTo: text("reporting_to"),
  probationEndDate: text("probation_end_date"),
  confirmationDate: text("confirmation_date"),
  workLocation: text("work_location"),
  profilePicture: text("profile_picture"),
  documents: text("documents"),
});

export const roles = pgTable("roles", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description"),
  permissions: text("permissions"),
  isSystem: boolean("is_system").notNull().default(false),
  status: text("status").notNull().default("active"),
});

export const companySettings = pgTable("company_settings", {
  id: serial("id").primaryKey(),
  companyName: text("company_name").notNull(),
  registrationNo: text("registration_no"),
  ntn: text("ntn"),
  address: text("address"),
  address2: text("address_2"),
  city: text("city"),
  phone: text("phone"),
  phone2: text("phone_2"),
  mobile1: text("mobile_1"),
  mobile2: text("mobile_2"),
  email: text("email"),
  website: text("website"),
  logo: text("logo"),
  currency: text("currency").default("PKR"),
  currencySymbol: text("currency_symbol").default("Rs"),
  taxRate: decimal("tax_rate", { precision: 5, scale: 2 }).default("17"),
  country: text("country").default("Pakistan"),
  countryCode: text("country_code").default("PK"),
  dialCode: text("dial_code").default("+92"),
  language: text("language").default("en"),
  timezone: text("timezone").default("Asia/Karachi"),
  clientCodeType: text("client_code_type").default("automatic"),
  clientCodePrefix: text("client_code_prefix").default("CUST-"),
  showOnLogin: boolean("show_on_login").default(true),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  type: text("type").notNull().default("info"),
  channel: text("channel").notNull().default("app"),
  recipientType: text("recipient_type").default("all"),
  recipientId: integer("recipient_id"),
  isRead: boolean("is_read").notNull().default(false),
  createdAt: text("created_at").notNull(),
});

export const reports = pgTable("reports", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(),
  description: text("description"),
  parameters: text("parameters"),
  lastRunAt: text("last_run_at"),
  createdBy: text("created_by"),
  status: text("status").notNull().default("active"),
});

export const settings = pgTable("settings", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
  value: text("value").notNull(),
  category: text("category").notNull(),
  description: text("description"),
});

export const notificationTemplates = pgTable("notification_templates", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull().default("general"),
  channel: text("channel").notNull().default("email"),
  subject: text("subject"),
  body: text("body").notNull(),
  variables: text("variables"),
  isActive: boolean("is_active").notNull().default(true),
});

export const smtpSettings = pgTable("smtp_settings", {
  id: serial("id").primaryKey(),
  host: text("host").notNull(),
  port: integer("port").notNull().default(587),
  username: text("username").notNull(),
  password: text("password").notNull(),
  fromEmail: text("from_email").notNull(),
  fromName: text("from_name"),
  encryption: text("encryption").notNull().default("tls"),
  isActive: boolean("is_active").notNull().default(true),
});

export const smsSettings = pgTable("sms_settings", {
  id: serial("id").primaryKey(),
  provider: text("provider").notNull().default("custom"),
  apiUrl: text("api_url").notNull(),
  apiKey: text("api_key"),
  apiSecret: text("api_secret"),
  senderId: text("sender_id"),
  httpMethod: text("http_method").notNull().default("POST"),
  headerParams: text("header_params"),
  bodyTemplate: text("body_template"),
  isActive: boolean("is_active").notNull().default(true),
});

export const notificationDispatches = pgTable("notification_dispatches", {
  id: serial("id").primaryKey(),
  templateId: integer("template_id"),
  channel: text("channel").notNull(),
  recipient: text("recipient").notNull(),
  subject: text("subject"),
  body: text("body").notNull(),
  status: text("status").notNull().default("pending"),
  errorMessage: text("error_message"),
  sentAt: text("sent_at"),
  createdAt: text("created_at").notNull(),
});

export const branches = pgTable("branches", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  code: text("code").notNull().unique(),
  address: text("address"),
  city: text("city"),
  phone: text("phone"),
  email: text("email"),
  managerId: integer("manager_id"),
  status: text("status").notNull().default("active"),
});

export const customerConnections = pgTable("customer_connections", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").notNull(),
  username: text("username"),
  ipAddress: text("ip_address"),
  macAddress: text("mac_address"),
  onuSerial: text("onu_serial"),
  routerModel: text("router_model"),
  routerSerial: text("router_serial"),
  connectionType: text("connection_type").default("fiber"),
  port: text("port"),
  vlan: text("vlan"),
  installDate: text("install_date"),
  status: text("status").notNull().default("active"),
});

export const vendorWalletTransactions = pgTable("vendor_wallet_transactions", {
  id: serial("id").primaryKey(),
  vendorId: integer("vendor_id").notNull(),
  type: text("type").notNull(),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  balanceAfter: decimal("balance_after", { precision: 12, scale: 2 }).notNull(),
  reference: text("reference"),
  description: text("description"),
  paymentMethod: text("payment_method"),
  performedBy: text("performed_by"),
  approvedBy: text("approved_by"),
  notes: text("notes"),
  reason: text("reason"),
  customerId: integer("customer_id"),
  resellerId: integer("reseller_id"),
  createdAt: text("created_at").notNull(),
});

export const resellerWalletTransactions = pgTable("reseller_wallet_transactions", {
  id: serial("id").primaryKey(),
  resellerId: integer("reseller_id").notNull(),
  type: text("type").notNull(),
  amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
  balanceAfter: decimal("balance_after", { precision: 12, scale: 2 }).notNull(),
  reference: text("reference"),
  description: text("description"),
  vendorId: integer("vendor_id"),
  customerId: integer("customer_id"),
  createdAt: text("created_at").notNull(),
});

export const vendorPackages = pgTable("vendor_packages", {
  id: serial("id").primaryKey(),
  vendorId: integer("vendor_id").notNull(),
  packageName: text("package_name").notNull(),
  speed: text("speed"),
  vendorPrice: decimal("vendor_price", { precision: 10, scale: 2 }).notNull(),
  ispSellingPrice: decimal("isp_selling_price", { precision: 10, scale: 2 }).notNull(),
  resellerPrice: decimal("reseller_price", { precision: 10, scale: 2 }),
  dataLimit: text("data_limit"),
  validity: text("validity").default("30 days"),
  ispMargin: decimal("isp_margin", { precision: 10, scale: 2 }),
  resellerMargin: decimal("reseller_margin", { precision: 10, scale: 2 }),
  isActive: boolean("is_active").notNull().default(true),
});

export const vendorBandwidthLinks = pgTable("vendor_bandwidth_links", {
  id: serial("id").primaryKey(),
  vendorId: integer("vendor_id").notNull(),
  linkName: text("link_name").notNull(),
  ipAddress: text("ip_address"),
  vlanDetail: text("vlan_detail"),
  city: text("city"),
  bandwidthMbps: decimal("bandwidth_mbps", { precision: 10, scale: 2 }).notNull(),
  bandwidthRate: decimal("bandwidth_rate", { precision: 10, scale: 2 }).notNull(),
  totalMonthlyCost: decimal("total_monthly_cost", { precision: 12, scale: 2 }).notNull(),
  status: text("status").notNull().default("active"),
  notes: text("notes"),
  createdAt: text("created_at").default(sql`CURRENT_TIMESTAMP`),
});

export const customerQueries = pgTable("customer_queries", {
  id: serial("id").primaryKey(),
  queryId: text("query_id").notNull(),
  name: text("name").notNull(),
  gender: text("gender"),
  occupation: text("occupation"),
  dateOfBirth: text("date_of_birth"),
  fatherName: text("father_name"),
  motherName: text("mother_name"),
  nidNumber: text("nid_number"),
  registrationFormNo: text("registration_form_no"),
  remarks: text("remarks"),
  profilePicture: text("profile_picture"),
  nidPicture: text("nid_picture"),
  registrationFormPicture: text("registration_form_picture"),
  phone: text("phone").notNull(),
  email: text("email"),
  address: text("address"),
  area: text("area"),
  city: text("city"),
  district: text("district"),
  emergencyContact: text("emergency_contact"),
  emergencyPhone: text("emergency_phone"),
  connectionType: text("connection_type"),
  packageId: integer("package_id"),
  ipAddress: text("ip_address"),
  macAddress: text("mac_address"),
  routerModel: text("router_model"),
  ontSerialNumber: text("ont_serial_number"),
  popLocation: text("pop_location"),
  vlanId: text("vlan_id"),
  serviceType: text("service_type"),
  billingCycle: text("billing_cycle"),
  installationDate: text("installation_date"),
  activationDate: text("activation_date"),
  monthlyCharges: decimal("monthly_charges", { precision: 10, scale: 2 }),
  securityDeposit: decimal("security_deposit", { precision: 10, scale: 2 }),
  installationFee: decimal("installation_fee", { precision: 10, scale: 2 }),
  specialDiscount: decimal("special_discount", { precision: 10, scale: 2 }),
  zone: text("zone"),
  subzone: text("subzone"),
  customerType: text("customer_type"),
  billingDate: integer("billing_date"),
  otcCharge: decimal("otc_charge", { precision: 10, scale: 2 }),
  phyConnectivity: text("phy_connectivity").default("Pending"),
  createdBy: text("created_by"),
  setupBy: text("setup_by"),
  setupTime: text("setup_time"),
  status: text("status").notNull().default("Pending"),
  createdAt: text("created_at").notNull(),
});

export const invoiceItems = pgTable("invoice_items", {
  id: serial("id").primaryKey(),
  invoiceId: integer("invoice_id").notNull(),
  itemType: text("item_type").notNull().default("service"),
  description: text("description").notNull(),
  quantity: integer("quantity").notNull().default(1),
  unitPrice: decimal("unit_price", { precision: 10, scale: 2 }).notNull(),
  discount: decimal("discount", { precision: 10, scale: 2 }).default("0"),
  taxRate: decimal("tax_rate", { precision: 5, scale: 2 }).default("0"),
  taxAmount: decimal("tax_amount", { precision: 10, scale: 2 }).default("0"),
  total: decimal("total", { precision: 10, scale: 2 }).notNull(),
  packageId: integer("package_id"),
  sortOrder: integer("sort_order").default(0),
});

export const insertInvoiceItemSchema = createInsertSchema(invoiceItems).omit({ id: true });

export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export const insertCustomerSchema = createInsertSchema(customers).omit({ id: true });
export const insertPackageSchema = createInsertSchema(packages).omit({ id: true });
export const insertInvoiceSchema = createInsertSchema(invoices).omit({ id: true });
export const insertTicketSchema = createInsertSchema(tickets).omit({ id: true });
export const insertActivityLogSchema = createInsertSchema(activityLogs).omit({ id: true });
export const insertAreaSchema = createInsertSchema(areas).omit({ id: true });
export const insertVendorSchema = createInsertSchema(vendors).omit({ id: true });
export const insertResellerSchema = createInsertSchema(resellers).omit({ id: true });
export const insertAccountSchema = createInsertSchema(accounts).omit({ id: true });
export const insertTransactionSchema = createInsertSchema(transactions).omit({ id: true });
export const insertTaskSchema = createInsertSchema(tasks).omit({ id: true });
export const insertAssetSchema = createInsertSchema(assets).omit({ id: true });
export const insertInventoryItemSchema = createInsertSchema(inventoryItems).omit({ id: true });
export const insertEmployeeSchema = createInsertSchema(employees).omit({ id: true });
export const insertRoleSchema = createInsertSchema(roles).omit({ id: true });
export const insertCompanySettingsSchema = createInsertSchema(companySettings).omit({ id: true });
export const insertNotificationSchema = createInsertSchema(notifications).omit({ id: true });
export const insertReportSchema = createInsertSchema(reports).omit({ id: true });
export const insertSettingSchema = createInsertSchema(settings).omit({ id: true });
export const insertCustomerConnectionSchema = createInsertSchema(customerConnections).omit({ id: true });
export const insertNotificationTemplateSchema = createInsertSchema(notificationTemplates).omit({ id: true });
export const insertSmtpSettingsSchema = createInsertSchema(smtpSettings).omit({ id: true });
export const insertSmsSettingsSchema = createInsertSchema(smsSettings).omit({ id: true });
export const insertNotificationDispatchSchema = createInsertSchema(notificationDispatches).omit({ id: true });
export const insertBranchSchema = createInsertSchema(branches).omit({ id: true });
export const insertVendorWalletTransactionSchema = createInsertSchema(vendorWalletTransactions).omit({ id: true });
export const insertResellerWalletTransactionSchema = createInsertSchema(resellerWalletTransactions).omit({ id: true });
export const insertVendorPackageSchema = createInsertSchema(vendorPackages).omit({ id: true });
export const insertVendorBandwidthLinkSchema = createInsertSchema(vendorBandwidthLinks).omit({ id: true });

export const bandwidthChangeHistory = pgTable("bandwidth_change_history", {
  id: serial("id").primaryKey(),
  vendorId: integer("vendor_id").notNull(),
  linkId: integer("link_id").notNull(),
  changeType: text("change_type").notNull(),
  previousMbps: decimal("previous_mbps", { precision: 10, scale: 2 }).notNull(),
  newMbps: decimal("new_mbps", { precision: 10, scale: 2 }).notNull(),
  previousRate: decimal("previous_rate", { precision: 10, scale: 2 }).notNull(),
  newRate: decimal("new_rate", { precision: 10, scale: 2 }).notNull(),
  previousCost: decimal("previous_cost", { precision: 12, scale: 2 }).notNull(),
  newCost: decimal("new_cost", { precision: 12, scale: 2 }).notNull(),
  reason: text("reason"),
  requestedBy: text("requested_by"),
  approvedBy: text("approved_by"),
  status: text("status").notNull().default("completed"),
  effectiveDate: text("effective_date"),
  notes: text("notes"),
  createdAt: text("created_at").default(sql`CURRENT_TIMESTAMP`),
});

export const insertBandwidthChangeHistorySchema = createInsertSchema(bandwidthChangeHistory).omit({ id: true });

export const insertCustomerQuerySchema = createInsertSchema(customerQueries).omit({ id: true });

export const supportCategories = pgTable("support_categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  department: text("department").notNull(),
  categoryType: text("category_type").notNull().default("for_everyone"),
  details: text("details"),
  targetGroup: text("target_group").default("clients"),
  createdAt: text("created_at").default(sql`CURRENT_TIMESTAMP`),
});

export const insertSupportCategorySchema = createInsertSchema(supportCategories).omit({ id: true });

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertCustomer = z.infer<typeof insertCustomerSchema>;
export type Customer = typeof customers.$inferSelect;
export type InsertPackage = z.infer<typeof insertPackageSchema>;
export type Package = typeof packages.$inferSelect;
export type InsertInvoice = z.infer<typeof insertInvoiceSchema>;
export type Invoice = typeof invoices.$inferSelect;
export type InsertTicket = z.infer<typeof insertTicketSchema>;
export type Ticket = typeof tickets.$inferSelect;
export type InsertActivityLog = z.infer<typeof insertActivityLogSchema>;
export type ActivityLog = typeof activityLogs.$inferSelect;
export type InsertArea = z.infer<typeof insertAreaSchema>;
export type Area = typeof areas.$inferSelect;
export type InsertVendor = z.infer<typeof insertVendorSchema>;
export type Vendor = typeof vendors.$inferSelect;
export type InsertReseller = z.infer<typeof insertResellerSchema>;
export type Reseller = typeof resellers.$inferSelect;
export type InsertAccount = z.infer<typeof insertAccountSchema>;
export type Account = typeof accounts.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactions.$inferSelect;
export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Task = typeof tasks.$inferSelect;
export type InsertAsset = z.infer<typeof insertAssetSchema>;
export type Asset = typeof assets.$inferSelect;
export type InsertInventoryItem = z.infer<typeof insertInventoryItemSchema>;
export type InventoryItem = typeof inventoryItems.$inferSelect;
export type InsertEmployee = z.infer<typeof insertEmployeeSchema>;
export type Employee = typeof employees.$inferSelect;
export type InsertRole = z.infer<typeof insertRoleSchema>;
export type Role = typeof roles.$inferSelect;
export type InsertCompanySettings = z.infer<typeof insertCompanySettingsSchema>;
export type CompanySettings = typeof companySettings.$inferSelect;
export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type Notification = typeof notifications.$inferSelect;
export type InsertReport = z.infer<typeof insertReportSchema>;
export type Report = typeof reports.$inferSelect;
export type InsertSetting = z.infer<typeof insertSettingSchema>;
export type Setting = typeof settings.$inferSelect;
export type InsertCustomerConnection = z.infer<typeof insertCustomerConnectionSchema>;
export type CustomerConnection = typeof customerConnections.$inferSelect;
export type InsertNotificationTemplate = z.infer<typeof insertNotificationTemplateSchema>;
export type NotificationTemplate = typeof notificationTemplates.$inferSelect;
export type InsertSmtpSettings = z.infer<typeof insertSmtpSettingsSchema>;
export type SmtpSettings = typeof smtpSettings.$inferSelect;
export type InsertSmsSettings = z.infer<typeof insertSmsSettingsSchema>;
export type SmsSettings = typeof smsSettings.$inferSelect;
export type InsertNotificationDispatch = z.infer<typeof insertNotificationDispatchSchema>;
export type NotificationDispatch = typeof notificationDispatches.$inferSelect;
export type InsertBranch = z.infer<typeof insertBranchSchema>;
export type Branch = typeof branches.$inferSelect;
export type InsertVendorWalletTransaction = z.infer<typeof insertVendorWalletTransactionSchema>;
export type VendorWalletTransaction = typeof vendorWalletTransactions.$inferSelect;
export type InsertResellerWalletTransaction = z.infer<typeof insertResellerWalletTransactionSchema>;
export type ResellerWalletTransaction = typeof resellerWalletTransactions.$inferSelect;
export type InsertVendorPackage = z.infer<typeof insertVendorPackageSchema>;
export type VendorPackage = typeof vendorPackages.$inferSelect;
export type InsertVendorBandwidthLink = z.infer<typeof insertVendorBandwidthLinkSchema>;
export type VendorBandwidthLink = typeof vendorBandwidthLinks.$inferSelect;
export type InsertBandwidthChangeHistory = z.infer<typeof insertBandwidthChangeHistorySchema>;
export type BandwidthChangeHistory = typeof bandwidthChangeHistory.$inferSelect;

export type InsertCustomerQuery = z.infer<typeof insertCustomerQuerySchema>;
export type CustomerQuery = typeof customerQueries.$inferSelect;
export type InsertSupportCategory = z.infer<typeof insertSupportCategorySchema>;
export type SupportCategory = typeof supportCategories.$inferSelect;
export type InsertInvoiceItem = z.infer<typeof insertInvoiceItemSchema>;
export type InvoiceItem = typeof invoiceItems.$inferSelect;

export const expenses = pgTable("expenses", {
  id: serial("id").primaryKey(),
  expenseId: text("expense_id").notNull().unique(),
  category: text("category").notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  description: text("description").notNull(),
  paymentMethod: text("payment_method").default("cash"),
  reference: text("reference"),
  vendorId: integer("vendor_id"),
  approvedBy: text("approved_by"),
  status: text("status").notNull().default("pending"),
  date: text("date").notNull(),
  receipt: text("receipt"),
  notes: text("notes"),
  createdBy: text("created_by"),
  area: text("area"),
  branch: text("branch"),
});

export const attendance = pgTable("attendance", {
  id: serial("id").primaryKey(),
  employeeId: integer("employee_id").notNull(),
  date: text("date").notNull(),
  checkIn: text("check_in"),
  checkOut: text("check_out"),
  status: text("status").notNull().default("present"),
  hoursWorked: decimal("hours_worked", { precision: 5, scale: 2 }),
  overtime: decimal("overtime", { precision: 5, scale: 2 }).default("0"),
  notes: text("notes"),
  location: text("location"),
});

export const auditLogs = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  userName: text("user_name"),
  action: text("action").notNull(),
  module: text("module").notNull(),
  entityType: text("entity_type"),
  entityId: integer("entity_id"),
  oldValues: text("old_values"),
  newValues: text("new_values"),
  ipAddress: text("ip_address"),
  description: text("description").notNull(),
  createdAt: text("created_at").notNull(),
});

export const creditNotes = pgTable("credit_notes", {
  id: serial("id").primaryKey(),
  creditNoteNumber: text("credit_note_number").notNull().unique(),
  customerId: integer("customer_id").notNull(),
  invoiceId: integer("invoice_id"),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  reason: text("reason").notNull(),
  status: text("status").notNull().default("draft"),
  issueDate: text("issue_date").notNull(),
  appliedDate: text("applied_date"),
  notes: text("notes"),
  createdBy: text("created_by"),
});

export const bulkMessages = pgTable("bulk_messages", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  channel: text("channel").notNull().default("sms"),
  targetType: text("target_type").notNull().default("all"),
  targetArea: text("target_area"),
  targetStatus: text("target_status"),
  recipientCount: integer("recipient_count").default(0),
  sentCount: integer("sent_count").default(0),
  failedCount: integer("failed_count").default(0),
  status: text("status").notNull().default("draft"),
  scheduledAt: text("scheduled_at"),
  sentAt: text("sent_at"),
  createdBy: text("created_by"),
  createdAt: text("created_at").notNull(),
});

export const ipAddresses = pgTable("ip_addresses", {
  id: serial("id").primaryKey(),
  ipAddress: text("ip_address").notNull().unique(),
  subnet: text("subnet"),
  gateway: text("gateway"),
  type: text("type").notNull().default("dynamic"),
  status: text("status").notNull().default("available"),
  customerId: integer("customer_id"),
  assignedDate: text("assigned_date"),
  vlan: text("vlan"),
  pool: text("pool"),
  notes: text("notes"),
});

export const outages = pgTable("outages", {
  id: serial("id").primaryKey(),
  outageId: text("outage_id").notNull().unique(),
  title: text("title").notNull(),
  description: text("description"),
  affectedArea: text("affected_area"),
  affectedCustomers: integer("affected_customers").default(0),
  severity: text("severity").notNull().default("minor"),
  type: text("type").notNull().default("unplanned"),
  status: text("status").notNull().default("ongoing"),
  startTime: text("start_time").notNull(),
  estimatedRestore: text("estimated_restore"),
  endTime: text("end_time"),
  rootCause: text("root_cause"),
  resolution: text("resolution"),
  notifiedCustomers: boolean("notified_customers").default(false),
  createdBy: text("created_by"),
});

// Network Devices for monitoring
export const networkDevices = pgTable("network_devices", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull().default("router"),
  vendor: text("vendor").default("mikrotik"),
  ipAddress: text("ip_address").notNull(),
  macAddress: text("mac_address"),
  location: text("location"),
  area: text("area"),
  status: text("status").notNull().default("online"),
  lastSeen: text("last_seen"),
  uptime: text("uptime"),
  cpuUsage: integer("cpu_usage"),
  memoryUsage: integer("memory_usage"),
  firmware: text("firmware"),
  model: text("model"),
  serialNumber: text("serial_number"),
  notes: text("notes"),
  monitoringEnabled: boolean("monitoring_enabled").default(true),
  alertThreshold: integer("alert_threshold").default(80),
});

// PPPoE Users managed via MikroTik/RADIUS
export const pppoeUsers = pgTable("pppoe_users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password"),
  customerId: integer("customer_id"),
  profileName: text("profile_name"),
  serviceType: text("service_type").default("pppoe"),
  status: text("status").notNull().default("active"),
  ipAddress: text("ip_address"),
  macAddress: text("mac_address"),
  uploadSpeed: text("upload_speed"),
  downloadSpeed: text("download_speed"),
  dataLimit: text("data_limit"),
  bytesIn: text("bytes_in").default("0"),
  bytesOut: text("bytes_out").default("0"),
  lastOnline: text("last_online"),
  nasDevice: text("nas_device"),
  callerStationId: text("caller_station_id"),
  sessionTimeout: integer("session_timeout"),
  idleTimeout: integer("idle_timeout"),
  createdAt: text("created_at"),
});

// RADIUS Profiles for bandwidth management
export const radiusProfiles = pgTable("radius_profiles", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  downloadRate: text("download_rate").notNull(),
  uploadRate: text("upload_rate").notNull(),
  burstDownload: text("burst_download"),
  burstUpload: text("burst_upload"),
  burstThreshold: text("burst_threshold"),
  burstTime: text("burst_time"),
  priority: integer("priority").default(8),
  dataQuota: text("data_quota"),
  sessionTimeout: integer("session_timeout"),
  idleTimeout: integer("idle_timeout").default(300),
  addressPool: text("address_pool"),
  sharedUsers: integer("shared_users").default(1),
  packageId: integer("package_id"),
  status: text("status").notNull().default("active"),
  notes: text("notes"),
});

// Payment gateway config
export const paymentGateways = pgTable("payment_gateways", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  provider: text("provider").notNull(),
  merchantId: text("merchant_id"),
  apiKey: text("api_key"),
  apiSecret: text("api_secret"),
  callbackUrl: text("callback_url"),
  mode: text("mode").notNull().default("test"),
  isActive: boolean("is_active").notNull().default(false),
  supportedMethods: text("supported_methods"),
  notes: text("notes"),
});

// Payment records
export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  paymentId: text("payment_id").notNull().unique(),
  customerId: integer("customer_id").notNull(),
  invoiceId: integer("invoice_id"),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  method: text("method").notNull().default("cash"),
  gateway: text("gateway"),
  transactionRef: text("transaction_ref"),
  status: text("status").notNull().default("completed"),
  paidAt: text("paid_at").notNull(),
  receivedBy: text("received_by"),
  notes: text("notes"),
});

// Billing rules for auto late fees / suspension
export const billingRules = pgTable("billing_rules", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull().default("late_fee"),
  graceDays: integer("grace_days").default(7),
  penaltyType: text("penalty_type").default("fixed"),
  penaltyAmount: decimal("penalty_amount", { precision: 10, scale: 2 }),
  penaltyPercent: decimal("penalty_percent", { precision: 5, scale: 2 }),
  maxPenalty: decimal("max_penalty", { precision: 10, scale: 2 }),
  autoSuspendDays: integer("auto_suspend_days").default(30),
  autoDisconnectDays: integer("auto_disconnect_days").default(60),
  notifyOnApply: boolean("notify_on_apply").default(true),
  isActive: boolean("is_active").notNull().default(true),
  description: text("description"),
});

// Bandwidth usage tracking
export const bandwidthUsage = pgTable("bandwidth_usage", {
  id: serial("id").primaryKey(),
  customerId: integer("customer_id").notNull(),
  pppoeUserId: integer("pppoe_user_id"),
  date: text("date").notNull(),
  downloadMb: decimal("download_mb", { precision: 12, scale: 2 }).default("0"),
  uploadMb: decimal("upload_mb", { precision: 12, scale: 2 }).default("0"),
  totalMb: decimal("total_mb", { precision: 12, scale: 2 }).default("0"),
  peakDownload: text("peak_download"),
  peakUpload: text("peak_upload"),
  sessionCount: integer("session_count").default(1),
  avgLatency: decimal("avg_latency", { precision: 6, scale: 2 }),
});

export const insertNetworkDeviceSchema = createInsertSchema(networkDevices).omit({ id: true });
export const insertPppoeUserSchema = createInsertSchema(pppoeUsers).omit({ id: true });
export const insertRadiusProfileSchema = createInsertSchema(radiusProfiles).omit({ id: true });
export const insertPaymentGatewaySchema = createInsertSchema(paymentGateways).omit({ id: true });
export const insertPaymentSchema = createInsertSchema(payments).omit({ id: true });
export const insertBillingRuleSchema = createInsertSchema(billingRules).omit({ id: true });
export const insertBandwidthUsageSchema = createInsertSchema(bandwidthUsage).omit({ id: true });

export type InsertNetworkDevice = z.infer<typeof insertNetworkDeviceSchema>;
export type NetworkDevice = typeof networkDevices.$inferSelect;
export type InsertPppoeUser = z.infer<typeof insertPppoeUserSchema>;
export type PppoeUser = typeof pppoeUsers.$inferSelect;
export type InsertRadiusProfile = z.infer<typeof insertRadiusProfileSchema>;
export type RadiusProfile = typeof radiusProfiles.$inferSelect;
export type InsertPaymentGateway = z.infer<typeof insertPaymentGatewaySchema>;
export type PaymentGateway = typeof paymentGateways.$inferSelect;
export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type Payment = typeof payments.$inferSelect;
export type InsertBillingRule = z.infer<typeof insertBillingRuleSchema>;
export type BillingRule = typeof billingRules.$inferSelect;
export type InsertBandwidthUsage = z.infer<typeof insertBandwidthUsageSchema>;
export type BandwidthUsage = typeof bandwidthUsage.$inferSelect;

export const insertExpenseSchema = createInsertSchema(expenses).omit({ id: true });
export const insertAttendanceSchema = createInsertSchema(attendance).omit({ id: true });
export const insertAuditLogSchema = createInsertSchema(auditLogs).omit({ id: true });
export const insertCreditNoteSchema = createInsertSchema(creditNotes).omit({ id: true });
export const insertBulkMessageSchema = createInsertSchema(bulkMessages).omit({ id: true });
export const insertIpAddressSchema = createInsertSchema(ipAddresses).omit({ id: true });
export const insertOutageSchema = createInsertSchema(outages).omit({ id: true });

export type InsertExpense = z.infer<typeof insertExpenseSchema>;
export type Expense = typeof expenses.$inferSelect;
export type InsertAttendance = z.infer<typeof insertAttendanceSchema>;
export type Attendance = typeof attendance.$inferSelect;
export type InsertAuditLog = z.infer<typeof insertAuditLogSchema>;
export type AuditLog = typeof auditLogs.$inferSelect;
export type InsertCreditNote = z.infer<typeof insertCreditNoteSchema>;
export type CreditNote = typeof creditNotes.$inferSelect;
export type InsertBulkMessage = z.infer<typeof insertBulkMessageSchema>;
export type BulkMessage = typeof bulkMessages.$inferSelect;
export type InsertIpAddress = z.infer<typeof insertIpAddressSchema>;
export type IpAddress = typeof ipAddresses.$inferSelect;
export type InsertOutage = z.infer<typeof insertOutageSchema>;
export type Outage = typeof outages.$inferSelect;

export const dailyCollections = pgTable("daily_collections", {
  id: serial("id").primaryKey(),
  date: text("date").notNull(),
  customerId: integer("customer_id").notNull(),
  invoiceId: integer("invoice_id"),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  received: decimal("received", { precision: 10, scale: 2 }).notNull().default("0"),
  vat: decimal("vat", { precision: 10, scale: 2 }).default("0"),
  discount: decimal("discount", { precision: 10, scale: 2 }).default("0"),
  balanceDue: decimal("balance_due", { precision: 10, scale: 2 }).default("0"),
  paymentMethod: text("payment_method").default("cash"),
  receivedBy: text("received_by"),
  approvedBy: text("approved_by"),
  createdBy: text("created_by"),
  notes: text("notes"),
  status: text("status").notNull().default("pending"),
  connectionType: text("connection_type"),
  area: text("area"),
  transactionType: text("transaction_type").default("collection"),
});

export const insertDailyCollectionSchema = createInsertSchema(dailyCollections).omit({ id: true });
export type InsertDailyCollection = z.infer<typeof insertDailyCollectionSchema>;
export type DailyCollection = typeof dailyCollections.$inferSelect;

export const salaryHistory = pgTable("salary_history", {
  id: serial("id").primaryKey(),
  employeeId: integer("employee_id").notNull(),
  salaryDate: text("salary_date").notNull(),
  salaryMonth: text("salary_month").notNull(),
  paidAmount: decimal("paid_amount", { precision: 10, scale: 2 }).notNull().default("0"),
  overtime: decimal("overtime", { precision: 10, scale: 2 }).default("0"),
  incentive: decimal("incentive", { precision: 10, scale: 2 }).default("0"),
  bonus: decimal("bonus", { precision: 10, scale: 2 }).default("0"),
  overall: decimal("overall", { precision: 10, scale: 2 }).default("0"),
  remarks: text("remarks"),
  givenBy: text("given_by"),
  createdAt: text("created_at").default(sql`CURRENT_TIMESTAMP`),
});

export const insertSalaryHistorySchema = createInsertSchema(salaryHistory).omit({ id: true, createdAt: true });
export type InsertSalaryHistory = z.infer<typeof insertSalaryHistorySchema>;
export type SalaryHistory = typeof salaryHistory.$inferSelect;

export const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

export type LoginData = z.infer<typeof loginSchema>;
