import { storage } from "./storage";
import { db } from "./db";
import { users } from "@shared/schema";
import { log } from "./index";

export async function seedDatabase() {
  try {
    const existingUsers = await db.select().from(users).limit(1);
    if (existingUsers.length > 0) {
      log("Database already seeded, skipping...", "seed");
      return;
    }

    log("Seeding database with sample data...", "seed");

    await storage.createUser({
      username: "admin",
      password: "admin123",
      fullName: "System Administrator",
      email: "admin@netsphere.pk",
      role: "super_admin",
      isActive: true,
    });

    const pkg1 = await storage.createPackage({ name: "Basic Home", serviceType: "internet", speed: "10 Mbps", price: "1500", billingCycle: "monthly", dataLimit: "Unlimited", description: "Ideal for light browsing and social media use", isActive: true });
    const pkg2 = await storage.createPackage({ name: "Standard Home", serviceType: "internet", speed: "25 Mbps", price: "2500", billingCycle: "monthly", dataLimit: "Unlimited", description: "Great for streaming and online gaming", isActive: true });
    const pkg3 = await storage.createPackage({ name: "Premium Home", serviceType: "internet", speed: "50 Mbps", price: "4000", billingCycle: "monthly", dataLimit: "Unlimited", description: "Best for multiple devices and 4K streaming", isActive: true });
    const pkg4 = await storage.createPackage({ name: "Corporate Basic", serviceType: "internet", speed: "100 Mbps", price: "8000", billingCycle: "monthly", dataLimit: "Unlimited", description: "Reliable connectivity for small businesses", isActive: true });
    const pkg5 = await storage.createPackage({ name: "Enterprise Plus", serviceType: "internet", speed: "200 Mbps", price: "15000", billingCycle: "monthly", dataLimit: "Unlimited", description: "Dedicated bandwidth for enterprises with SLA", isActive: true });

    await storage.createPackage({ name: "IPTV Basic", serviceType: "iptv", price: "800", billingCycle: "monthly", channels: "100+ SD Channels", features: "SD quality, Local channels, News, Sports basics", description: "Basic IPTV package with local and news channels", isActive: true });
    await storage.createPackage({ name: "IPTV Premium", serviceType: "iptv", price: "1500", billingCycle: "monthly", channels: "250+ HD Channels", features: "HD quality, Sports HD, Movies, International channels, DVR", description: "Premium IPTV with HD sports and international content", isActive: true });
    await storage.createPackage({ name: "Cable TV Standard", serviceType: "cable_tv", price: "600", billingCycle: "monthly", channels: "80+ Channels", features: "Local channels, News, Entertainment, Sports basics", description: "Standard cable TV with popular local channels", isActive: true });
    await storage.createPackage({ name: "Triple Play Bundle", serviceType: "bundle", speed: "50 Mbps", price: "5500", billingCycle: "monthly", dataLimit: "Unlimited", channels: "200+ HD Channels", features: "Internet 50Mbps + IPTV Premium + Free Router", description: "Complete bundle: Internet + IPTV + Free equipment", isActive: true });

    const c1 = await storage.createCustomer({ customerId: "ISP-1001", fullName: "Ahmed Khan", email: "ahmed.khan@gmail.com", phone: "0321-4567890", cnic: "35201-1234567-1", address: "House 45, Street 12, Gulberg III", area: "Gulberg", customerType: "home", packageId: pkg2.id, status: "active", connectionDate: "2024-06-15", monthlyBill: "2500" });
    const c2 = await storage.createCustomer({ customerId: "ISP-1002", fullName: "Fatima Zahra", email: "fatima.z@outlook.com", phone: "0300-1234567", cnic: "35202-7654321-2", address: "Flat 302, Al-Rehman Tower, DHA Phase 5", area: "DHA Phase 5", customerType: "home", packageId: pkg3.id, status: "active", connectionDate: "2024-08-20", monthlyBill: "4000" });
    const c3 = await storage.createCustomer({ customerId: "ISP-1003", fullName: "TechVista Solutions", email: "info@techvista.pk", phone: "0333-9876543", address: "Office 12, 3rd Floor, Software Technology Park", area: "Johar Town", customerType: "corporate", packageId: pkg4.id, status: "active", connectionDate: "2024-03-10", monthlyBill: "8000" });
    const c4 = await storage.createCustomer({ customerId: "ISP-1004", fullName: "Hassan Ali", email: "hassan.ali@yahoo.com", phone: "0345-6789012", cnic: "35203-9876543-3", address: "House 78, Block C, Model Town", area: "Model Town", customerType: "home", packageId: pkg1.id, status: "suspended", connectionDate: "2024-01-05", monthlyBill: "1500" });
    const c5 = await storage.createCustomer({ customerId: "ISP-1005", fullName: "Digital Nomad Cafe", email: "manager@nomadcafe.pk", phone: "0312-3456789", address: "Shop 5, Liberty Market", area: "Liberty", customerType: "corporate", packageId: pkg5.id, status: "active", connectionDate: "2024-09-01", monthlyBill: "15000" });

    const inv1 = await storage.createInvoice({ invoiceNumber: "INV-2024-001", customerId: c1.id, amount: "2500", tax: "425", totalAmount: "2925", status: "paid", dueDate: "2025-01-15", issueDate: "2025-01-01", paidDate: "2025-01-10", description: "Monthly internet service - January 2025" });
    const inv2 = await storage.createInvoice({ invoiceNumber: "INV-2024-002", customerId: c2.id, amount: "4000", tax: "680", totalAmount: "4680", status: "paid", dueDate: "2025-01-15", issueDate: "2025-01-01", paidDate: "2025-01-12", description: "Monthly internet service - January 2025" });
    const inv3 = await storage.createInvoice({ invoiceNumber: "INV-2024-003", customerId: c3.id, amount: "8000", tax: "1360", totalAmount: "9360", status: "pending", dueDate: "2025-02-15", issueDate: "2025-02-01", description: "Monthly internet service - February 2025" });
    await storage.createInvoice({ invoiceNumber: "INV-2024-004", customerId: c4.id, amount: "1500", tax: "255", totalAmount: "1755", status: "overdue", dueDate: "2024-12-15", issueDate: "2024-12-01", description: "Monthly internet service - December 2024" });
    await storage.createInvoice({ invoiceNumber: "INV-2024-005", customerId: c5.id, amount: "15000", tax: "2550", totalAmount: "17550", status: "pending", dueDate: "2025-02-15", issueDate: "2025-02-01", description: "Monthly internet service - February 2025" });

    await storage.createTicket({ ticketNumber: "TKT-001", customerId: c1.id, subject: "Internet speed slower than subscribed package", description: "Customer reports getting only 5 Mbps instead of 25 Mbps on the Standard Home package.", priority: "high", status: "open", category: "speed", assignedTo: "Technician Usman", createdAt: "2025-02-18T10:30:00Z" });
    await storage.createTicket({ ticketNumber: "TKT-002", customerId: c2.id, subject: "Frequent disconnections during evening hours", description: "Connection drops 3-4 times daily between 7 PM and 11 PM.", priority: "medium", status: "in_progress", category: "connectivity", assignedTo: "Technician Ali", createdAt: "2025-02-19T14:15:00Z" });
    await storage.createTicket({ ticketNumber: "TKT-003", customerId: c3.id, subject: "Request for static IP configuration", description: "Corporate client needs a static IP address for VPN and server hosting.", priority: "medium", status: "open", category: "general", assignedTo: "", createdAt: "2025-02-20T09:00:00Z" });
    await storage.createTicket({ ticketNumber: "TKT-004", customerId: c4.id, subject: "Billing dispute - charged for suspended period", description: "Customer was charged for the month when service was suspended.", priority: "low", status: "open", category: "billing", assignedTo: "", createdAt: "2025-02-21T11:45:00Z" });

    await storage.createArea({ name: "Gulberg", city: "Lahore", zone: "Central", branch: "Main Branch", totalCustomers: 45, status: "active" });
    await storage.createArea({ name: "DHA Phase 5", city: "Lahore", zone: "South", branch: "DHA Branch", totalCustomers: 78, status: "active" });
    await storage.createArea({ name: "Johar Town", city: "Lahore", zone: "East", branch: "Main Branch", totalCustomers: 32, status: "active" });
    await storage.createArea({ name: "Model Town", city: "Lahore", zone: "Central", branch: "Main Branch", totalCustomers: 56, status: "active" });
    await storage.createArea({ name: "Liberty", city: "Lahore", zone: "Central", branch: "Main Branch", totalCustomers: 23, status: "active" });
    await storage.createArea({ name: "Bahria Town", city: "Lahore", zone: "South", branch: "DHA Branch", totalCustomers: 120, status: "active" });
    await storage.createArea({ name: "Clifton", city: "Karachi", zone: "South", branch: "Karachi Branch", totalCustomers: 95, status: "active" });
    await storage.createArea({ name: "F-8", city: "Islamabad", zone: "Central", branch: "Islamabad Branch", totalCustomers: 40, status: "active" });

    const v1 = await storage.createVendor({ name: "FiberLink Technologies", contactPerson: "Bilal Hussain", phone: "042-35761234", email: "sales@fiberlink.pk", address: "23-A Industrial Area, Gulberg", serviceType: "fiber", ntn: "1234567-8", bankAccount: "HBL-001234567890", slaLevel: "premium", status: "active" });
    const v2 = await storage.createVendor({ name: "NetEquip Solutions", contactPerson: "Sara Ahmed", phone: "042-35889900", email: "info@netequip.pk", address: "Office 45, Tech Park, DHA", serviceType: "equipment", ntn: "9876543-2", bankAccount: "MCB-009876543210", slaLevel: "standard", status: "active" });
    await storage.createVendor({ name: "CyberShield Security", contactPerson: "Kamran Malik", phone: "051-2345678", email: "support@cybershield.pk", address: "Blue Area, Islamabad", serviceType: "software", ntn: "5678901-4", slaLevel: "enterprise", status: "active" });
    await storage.createVendor({ name: "TowerTech Maintenance", contactPerson: "Rizwan Qureshi", phone: "0300-9871234", email: "ops@towertech.pk", address: "I-9 Industrial, Islamabad", serviceType: "maintenance", ntn: "3456789-6", slaLevel: "standard", status: "active" });

    await storage.createReseller({ name: "SpeedNet Resellers", contactName: "Imran Siddiqui", phone: "0311-2223344", email: "imran@speednet.pk", address: "Shop 12, Faisal Town", area: "Faisal Town", commissionRate: "12", totalCustomers: 35, status: "active" });
    await storage.createReseller({ name: "ConnectPlus Partners", contactName: "Ayesha Tariq", phone: "0322-5556677", email: "ayesha@connectplus.pk", address: "Plaza 7, Garden Town", area: "Garden Town", commissionRate: "10", totalCustomers: 22, status: "active" });
    await storage.createReseller({ name: "FastWave Distributors", contactName: "Naveed Aslam", phone: "0333-8889900", email: "naveed@fastwave.pk", address: "Market 3, Cantt Area", area: "Cantt", commissionRate: "15", totalCustomers: 48, status: "active" });

    const acc1 = await storage.createAccount({ code: "1000", name: "Cash & Bank", type: "asset", balance: "2500000", description: "Primary cash and bank accounts", isActive: true });
    const acc2 = await storage.createAccount({ code: "2000", name: "Accounts Receivable", type: "asset", balance: "850000", description: "Outstanding customer payments", isActive: true });
    await storage.createAccount({ code: "3000", name: "Accounts Payable", type: "liability", balance: "320000", description: "Vendor and supplier payables", isActive: true });
    const acc4 = await storage.createAccount({ code: "4000", name: "Service Revenue", type: "income", balance: "4500000", description: "Internet service revenue", isActive: true });
    await storage.createAccount({ code: "5000", name: "Operating Expenses", type: "expense", balance: "1200000", description: "Day-to-day operational costs", isActive: true });
    await storage.createAccount({ code: "6000", name: "Owner's Equity", type: "equity", balance: "5000000", description: "Owner's capital investment", isActive: true });

    await storage.createTransaction({ txnId: "TXN-001", type: "payment", amount: "2925", accountId: acc1.id, customerId: c1.id, invoiceId: inv1.id, paymentMethod: "bank_transfer", reference: "HBL-TRF-001", description: "Invoice INV-2024-001 payment", date: "2025-01-10", status: "completed" });
    await storage.createTransaction({ txnId: "TXN-002", type: "payment", amount: "4680", accountId: acc1.id, customerId: c2.id, invoiceId: inv2.id, paymentMethod: "jazzcash", reference: "JC-PAY-002", description: "Invoice INV-2024-002 payment", date: "2025-01-12", status: "completed" });
    await storage.createTransaction({ txnId: "TXN-003", type: "debit", amount: "45000", accountId: acc4.id, description: "Fiber cable purchase from FiberLink", date: "2025-01-20", status: "completed", paymentMethod: "bank_transfer" });
    await storage.createTransaction({ txnId: "TXN-004", type: "credit", amount: "9360", accountId: acc2.id, customerId: c3.id, invoiceId: inv3.id, description: "Invoice INV-2024-003 billed", date: "2025-02-01", status: "pending", paymentMethod: "cash" });

    await storage.createTask({ title: "Install fiber connection - Ahmed Khan", type: "installation", description: "New fiber connection installation at Gulberg III residence", priority: "high", status: "completed", assignedTo: "Technician Usman", customerId: c1.id, dueDate: "2024-06-15", completedDate: "2024-06-15" });
    await storage.createTask({ title: "Router replacement - Fatima Zahra", type: "repair", description: "Replace faulty TP-Link router with new unit", priority: "medium", status: "in_progress", assignedTo: "Technician Ali", customerId: c2.id, dueDate: "2025-02-25" });
    await storage.createTask({ title: "Upgrade bandwidth - TechVista", type: "upgrade", description: "Upgrade from 100 Mbps to 200 Mbps dedicated line", priority: "high", status: "pending", assignedTo: "Engineer Hamza", customerId: c3.id, dueDate: "2025-03-01" });
    await storage.createTask({ title: "Monthly tower maintenance", type: "maintenance", description: "Routine maintenance of main tower equipment", priority: "medium", status: "pending", assignedTo: "Technician Usman", dueDate: "2025-02-28" });
    await storage.createTask({ title: "Network audit - DHA sector", type: "general", description: "Complete network performance audit for DHA Phase 5 area", priority: "low", status: "pending", assignedTo: "Engineer Hamza", dueDate: "2025-03-15" });

    await storage.createAsset({ assetTag: "AST-001", name: "Huawei OLT MA5800-X7", type: "OLT", brand: "Huawei", model: "MA5800-X7", serialNumber: "HW2024X7001", vendorId: v1.id, purchaseDate: "2024-01-15", purchaseCost: "850000", warrantyEnd: "2027-01-15", location: "Main POP - Gulberg", status: "deployed" });
    await storage.createAsset({ assetTag: "AST-002", name: "Cisco Catalyst 9300", type: "switch", brand: "Cisco", model: "C9300-48P", serialNumber: "CSC9300A001", vendorId: v2.id, purchaseDate: "2024-03-20", purchaseCost: "320000", warrantyEnd: "2027-03-20", location: "Main POP - Gulberg", status: "deployed" });
    await storage.createAsset({ assetTag: "AST-003", name: "TP-Link Archer AX73", type: "router", brand: "TP-Link", model: "AX73", serialNumber: "TPL73A0001", vendorId: v2.id, purchaseDate: "2024-06-10", purchaseCost: "12000", warrantyEnd: "2025-06-10", location: "Customer - Ahmed Khan", assignedTo: "Ahmed Khan", status: "deployed" });
    await storage.createAsset({ assetTag: "AST-004", name: "APC Smart-UPS 3000VA", type: "UPS", brand: "APC", model: "SUA3000I", serialNumber: "APC3KVA001", vendorId: v2.id, purchaseDate: "2024-02-01", purchaseCost: "95000", warrantyEnd: "2026-02-01", location: "Main POP - Gulberg", status: "deployed" });
    await storage.createAsset({ assetTag: "AST-005", name: "ZTE ONT F660", type: "ONT", brand: "ZTE", model: "F660", serialNumber: "ZTE660B003", vendorId: v1.id, purchaseDate: "2024-08-15", purchaseCost: "4500", warrantyEnd: "2025-08-15", location: "Warehouse", status: "available" });

    await storage.createInventoryItem({ sku: "INV-FC-001", itemName: "Single Mode Fiber Cable (1km)", category: "fiber_cable", quantity: 25, unitCost: "8500", reorderLevel: 5, vendorId: v1.id, location: "Main Warehouse", description: "G.652D single mode fiber optic cable", status: "in_stock" });
    await storage.createInventoryItem({ sku: "INV-SC-001", itemName: "SC/APC Connectors (Pack of 100)", category: "connectors", quantity: 8, unitCost: "3500", reorderLevel: 10, vendorId: v1.id, location: "Main Warehouse", description: "SC/APC fiber connectors for FTTH", status: "low_stock" });
    await storage.createInventoryItem({ sku: "INV-ONT-001", itemName: "ZTE F660 ONT Unit", category: "ONT", quantity: 45, unitCost: "4500", reorderLevel: 15, vendorId: v1.id, location: "Main Warehouse", description: "GPON ONT for residential customers", status: "in_stock" });
    await storage.createInventoryItem({ sku: "INV-RT-001", itemName: "TP-Link Archer AX73 Router", category: "router", quantity: 12, unitCost: "12000", reorderLevel: 5, vendorId: v2.id, location: "Main Warehouse", description: "WiFi 6 dual-band router for premium customers", status: "in_stock" });
    await storage.createInventoryItem({ sku: "INV-TL-001", itemName: "Fiber Splicing Tool Kit", category: "tools", quantity: 3, unitCost: "45000", reorderLevel: 2, vendorId: v2.id, location: "Field Team", description: "Complete fiber optic splicing toolkit", status: "in_stock" });
    await storage.createInventoryItem({ sku: "INV-SP-001", itemName: "1x8 PLC Splitter", category: "connectors", quantity: 0, unitCost: "2800", reorderLevel: 10, vendorId: v1.id, location: "Main Warehouse", description: "PLC fiber optic splitter", status: "out_of_stock" });

    await storage.createEmployee({ empCode: "EMP-001", fullName: "Usman Tariq", email: "usman@netsphere.pk", phone: "0321-1112233", cnic: "35201-5555555-1", department: "engineering", designation: "Senior Technician", joinDate: "2023-01-15", salary: "65000", bankAccount: "HBL-123456789", address: "House 12, Township", status: "active" });
    await storage.createEmployee({ empCode: "EMP-002", fullName: "Ali Raza", email: "ali@netsphere.pk", phone: "0300-4445566", cnic: "35202-6666666-2", department: "engineering", designation: "Field Technician", joinDate: "2023-06-01", salary: "45000", bankAccount: "MCB-987654321", address: "Flat 5, Iqbal Town", status: "active" });
    await storage.createEmployee({ empCode: "EMP-003", fullName: "Hamza Sheikh", email: "hamza@netsphere.pk", phone: "0333-7778899", cnic: "35203-7777777-3", department: "engineering", designation: "Network Engineer", joinDate: "2022-09-01", salary: "120000", bankAccount: "UBL-456789123", address: "DHA Phase 6", status: "active" });
    await storage.createEmployee({ empCode: "EMP-004", fullName: "Sana Malik", email: "sana@netsphere.pk", phone: "0345-0001122", cnic: "35204-8888888-4", department: "support", designation: "Support Lead", joinDate: "2023-03-15", salary: "55000", address: "Garden Town", status: "active" });
    await storage.createEmployee({ empCode: "EMP-005", fullName: "Zeeshan Qureshi", email: "zeeshan@netsphere.pk", phone: "0311-3334455", cnic: "35205-9999999-5", department: "sales", designation: "Sales Manager", joinDate: "2022-05-01", salary: "85000", address: "Johar Town", status: "active" });
    await storage.createEmployee({ empCode: "EMP-006", fullName: "Nadia Butt", email: "nadia@netsphere.pk", phone: "0322-6667788", department: "finance", designation: "Accountant", joinDate: "2023-08-01", salary: "50000", address: "Model Town", status: "active" });

    await storage.createRole({ name: "Super Admin", description: "Full system access with all permissions", permissions: "dashboard.view,customers.manage,packages.manage,invoices.manage,tickets.manage,reports.view,settings.manage,users.manage,hr.manage", isSystem: true, status: "active" });
    await storage.createRole({ name: "Manager", description: "Management access to most modules", permissions: "dashboard.view,customers.manage,packages.view,invoices.manage,tickets.manage,reports.view,hr.view", isSystem: true, status: "active" });
    await storage.createRole({ name: "Technician", description: "Field operations and customer service", permissions: "dashboard.view,customers.view,tickets.manage,tasks.manage,assets.view", isSystem: false, status: "active" });
    await storage.createRole({ name: "Billing Staff", description: "Billing and invoice management", permissions: "dashboard.view,customers.view,invoices.manage,transactions.manage,accounting.view", isSystem: false, status: "active" });
    await storage.createRole({ name: "Support Agent", description: "Customer support and ticket handling", permissions: "dashboard.view,customers.view,tickets.manage", isSystem: false, status: "active" });

    await storage.upsertCompanySettings({ companyName: "NetSphere Technologies (Pvt) Ltd", registrationNo: "C-12345/LHR/2020", ntn: "1234567-8", address: "23-A, Tech Avenue, Gulberg III", city: "Lahore", phone: "042-35761000", email: "info@netsphere.pk", website: "https://netsphere.pk", currency: "PKR", taxRate: "17" });

    await storage.createNotification({ title: "Payment Received", message: "Payment of Rs. 2,925 received from Ahmed Khan for INV-2024-001", type: "success", channel: "app", recipientType: "staff", createdAt: "2025-01-10T12:00:00Z" });
    await storage.createNotification({ title: "Invoice Overdue", message: "Invoice INV-2024-004 for Hassan Ali is overdue by 45 days", type: "warning", channel: "app", recipientType: "staff", createdAt: "2025-02-01T09:00:00Z" });
    await storage.createNotification({ title: "New Ticket Submitted", message: "Ticket TKT-001: Internet speed slower than subscribed package", type: "info", channel: "app", recipientType: "staff", createdAt: "2025-02-18T10:30:00Z" });
    await storage.createNotification({ title: "System Maintenance", message: "Scheduled maintenance on Feb 25, 2025 from 2 AM to 5 AM", type: "warning", channel: "email", recipientType: "all", createdAt: "2025-02-20T08:00:00Z" });
    await storage.createNotification({ title: "Low Stock Alert", message: "SC/APC Connectors (INV-SC-001) stock is below reorder level", type: "error", channel: "app", recipientType: "staff", createdAt: "2025-02-21T16:00:00Z" });

    await storage.createReport({ name: "Monthly Revenue Report", type: "revenue", description: "Summary of monthly revenue, collections, and outstanding amounts", createdBy: "System", status: "active" });
    await storage.createReport({ name: "Customer Growth Report", type: "customers", description: "New customer acquisitions and churn rate analysis", createdBy: "System", status: "active" });
    await storage.createReport({ name: "Invoice Aging Report", type: "invoices", description: "Outstanding invoices categorized by aging periods", createdBy: "System", status: "active" });
    await storage.createReport({ name: "Ticket Resolution Report", type: "tickets", description: "Support ticket resolution times and satisfaction metrics", createdBy: "System", status: "active" });
    await storage.createReport({ name: "Inventory Status Report", type: "inventory", description: "Current inventory levels, low stock items, and reorder alerts", createdBy: "System", status: "active" });

    await storage.upsertSetting({ key: "billing.tax_rate", value: "17", category: "billing", description: "Default tax rate percentage" });
    await storage.upsertSetting({ key: "billing.invoice_prefix", value: "INV", category: "billing", description: "Prefix for invoice numbers" });
    await storage.upsertSetting({ key: "billing.due_days", value: "15", category: "billing", description: "Default number of days until invoice due" });
    await storage.upsertSetting({ key: "general.company_name", value: "NetSphere Technologies", category: "general", description: "Company display name" });
    await storage.upsertSetting({ key: "general.currency", value: "PKR", category: "general", description: "Default currency" });
    await storage.upsertSetting({ key: "notifications.email_enabled", value: "true", category: "notifications", description: "Enable email notifications" });
    await storage.upsertSetting({ key: "notifications.sms_enabled", value: "false", category: "notifications", description: "Enable SMS notifications" });
    await storage.upsertSetting({ key: "security.session_timeout", value: "24", category: "security", description: "Session timeout in hours" });
    await storage.upsertSetting({ key: "security.max_login_attempts", value: "5", category: "security", description: "Maximum failed login attempts" });

    await storage.createCustomerConnection({ customerId: c1.id, username: "ahmed.khan@isp", ipAddress: "192.168.1.101", macAddress: "AA:BB:CC:DD:EE:01", onuSerial: "ZTEG12345678", routerModel: "TP-Link Archer AX73", routerSerial: "TPL73A0001", connectionType: "fiber", port: "PON1/1/1", vlan: "100", installDate: "2024-06-15", status: "active" });
    await storage.createCustomerConnection({ customerId: c2.id, username: "fatima.z@isp", ipAddress: "192.168.1.102", macAddress: "AA:BB:CC:DD:EE:02", onuSerial: "ZTEG87654321", routerModel: "Huawei AX3 Pro", routerSerial: "HW-AX3P-002", connectionType: "fiber", port: "PON1/1/2", vlan: "100", installDate: "2024-08-20", status: "active" });
    await storage.createCustomerConnection({ customerId: c3.id, username: "techvista@isp", ipAddress: "10.0.1.50", macAddress: "AA:BB:CC:DD:EE:03", onuSerial: "ZTEG11223344", routerModel: "MikroTik hAP ac3", routerSerial: "MT-HAP-003", connectionType: "fiber", port: "PON1/2/1", vlan: "200", installDate: "2024-03-10", status: "active" });
    await storage.createCustomerConnection({ customerId: c5.id, username: "nomadcafe@isp", ipAddress: "10.0.2.100", macAddress: "AA:BB:CC:DD:EE:05", onuSerial: "ZTEG99887766", routerModel: "Cisco RV340", routerSerial: "CSC-RV340-005", connectionType: "fiber", port: "PON1/3/1", vlan: "300", installDate: "2024-09-01", status: "active" });

    await storage.createExpense({ expenseId: "EXP-001", category: "utilities", amount: "35000", description: "Monthly electricity bill for main office", paymentMethod: "bank_transfer", reference: "ELEC-2025-02", status: "approved", date: "2025-02-05", createdBy: "admin" });
    await storage.createExpense({ expenseId: "EXP-002", category: "internet", amount: "120000", description: "Upstream bandwidth from PTCL - February", paymentMethod: "bank_transfer", reference: "PTCL-BWD-02", status: "paid", date: "2025-02-01", createdBy: "admin" });
    await storage.createExpense({ expenseId: "EXP-003", category: "equipment", amount: "85000", description: "10x ZTE F660 ONT units purchase", paymentMethod: "bank_transfer", reference: "PO-2025-012", vendorId: v1.id, status: "pending", date: "2025-02-18", createdBy: "admin" });
    await storage.createExpense({ expenseId: "EXP-004", category: "maintenance", amount: "15000", description: "Tower maintenance and cleaning", paymentMethod: "cash", status: "approved", date: "2025-02-10", createdBy: "admin" });
    await storage.createExpense({ expenseId: "EXP-005", category: "salary", amount: "420000", description: "February staff salaries", paymentMethod: "bank_transfer", status: "paid", date: "2025-02-28", createdBy: "admin" });
    await storage.createExpense({ expenseId: "EXP-006", category: "rent", amount: "80000", description: "Main office rent - February", paymentMethod: "check", reference: "RENT-02-2025", status: "paid", date: "2025-02-01", createdBy: "admin" });

    await storage.createAttendance({ employeeId: 1, date: "2025-02-23", checkIn: "09:00", checkOut: "18:00", status: "present", hoursWorked: "9", overtime: "1", location: "Main Office" });
    await storage.createAttendance({ employeeId: 2, date: "2025-02-23", checkIn: "09:15", checkOut: "17:30", status: "late", hoursWorked: "8.25", overtime: "0", location: "Field" });
    await storage.createAttendance({ employeeId: 3, date: "2025-02-23", checkIn: "08:45", checkOut: "19:00", status: "present", hoursWorked: "10.25", overtime: "2.25", location: "Main Office" });
    await storage.createAttendance({ employeeId: 4, date: "2025-02-23", status: "absent", notes: "Sick leave" });
    await storage.createAttendance({ employeeId: 5, date: "2025-02-23", checkIn: "10:00", checkOut: "14:00", status: "half_day", hoursWorked: "4", location: "Main Office" });
    await storage.createAttendance({ employeeId: 6, date: "2025-02-23", checkIn: "09:00", checkOut: "17:00", status: "present", hoursWorked: "8", location: "Main Office" });

    await storage.createAuditLog({ userName: "admin", action: "login", module: "auth", description: "User admin logged in successfully", ipAddress: "192.168.1.1", createdAt: "2025-02-23T09:00:00Z" });
    await storage.createAuditLog({ userName: "admin", action: "created", module: "customers", entityType: "customer", entityId: c1.id, description: "Created customer Ahmed Khan (ISP-1001)", ipAddress: "192.168.1.1", createdAt: "2025-02-23T09:15:00Z" });
    await storage.createAuditLog({ userName: "admin", action: "updated", module: "invoices", entityType: "invoice", entityId: inv1.id, description: "Updated invoice INV-2024-001 status to paid", ipAddress: "192.168.1.1", createdAt: "2025-02-23T10:00:00Z" });
    await storage.createAuditLog({ userName: "admin", action: "created", module: "tickets", entityType: "ticket", description: "Created support ticket TKT-001", ipAddress: "192.168.1.1", createdAt: "2025-02-23T10:30:00Z" });
    await storage.createAuditLog({ userName: "admin", action: "updated", module: "settings", description: "Updated billing tax rate to 17%", ipAddress: "192.168.1.1", createdAt: "2025-02-23T11:00:00Z" });

    await storage.createCreditNote({ creditNoteNumber: "CN-001", customerId: c4.id, amount: "1755", reason: "Billing for suspended period - customer was not using service", status: "applied", issueDate: "2025-02-15", appliedDate: "2025-02-16", createdBy: "admin" });
    await storage.createCreditNote({ creditNoteNumber: "CN-002", customerId: c1.id, invoiceId: inv1.id, amount: "500", reason: "Service downtime compensation - 2 days outage", status: "approved", issueDate: "2025-02-20", createdBy: "admin" });
    await storage.createCreditNote({ creditNoteNumber: "CN-003", customerId: c3.id, amount: "2000", reason: "Overcharge on corporate package upgrade", status: "draft", issueDate: "2025-02-22", createdBy: "admin" });

    await storage.createBulkMessage({ title: "February Maintenance Notice", message: "Dear customer, scheduled maintenance on Feb 25 from 2 AM to 5 AM. Service may be interrupted.", channel: "sms", targetType: "all", recipientCount: 354, sentCount: 348, failedCount: 6, status: "sent", sentAt: "2025-02-20T08:00:00Z", createdBy: "admin", createdAt: "2025-02-20T07:30:00Z" });
    await storage.createBulkMessage({ title: "Ramadan Package Promotion", message: "Special Ramadan offer! Get 50% extra speed on all packages. Valid till March 31.", channel: "email", targetType: "all", recipientCount: 354, status: "scheduled", scheduledAt: "2025-03-01T09:00:00Z", createdBy: "admin", createdAt: "2025-02-22T14:00:00Z" });
    await storage.createBulkMessage({ title: "DHA Area Outage Update", message: "Dear DHA residents, the network issue has been resolved. Thank you for your patience.", channel: "sms", targetType: "area", targetArea: "DHA Phase 5", recipientCount: 78, sentCount: 78, status: "sent", sentAt: "2025-02-19T16:00:00Z", createdBy: "admin", createdAt: "2025-02-19T15:45:00Z" });

    await storage.createIpAddress({ ipAddress: "192.168.1.101", subnet: "255.255.255.0", gateway: "192.168.1.1", type: "static", status: "assigned", customerId: c1.id, assignedDate: "2024-06-15", vlan: "100", pool: "residential" });
    await storage.createIpAddress({ ipAddress: "192.168.1.102", subnet: "255.255.255.0", gateway: "192.168.1.1", type: "static", status: "assigned", customerId: c2.id, assignedDate: "2024-08-20", vlan: "100", pool: "residential" });
    await storage.createIpAddress({ ipAddress: "10.0.1.50", subnet: "255.255.255.0", gateway: "10.0.1.1", type: "static", status: "assigned", customerId: c3.id, assignedDate: "2024-03-10", vlan: "200", pool: "corporate" });
    await storage.createIpAddress({ ipAddress: "10.0.2.100", subnet: "255.255.255.0", gateway: "10.0.2.1", type: "static", status: "assigned", customerId: c5.id, assignedDate: "2024-09-01", vlan: "300", pool: "corporate" });
    await storage.createIpAddress({ ipAddress: "192.168.1.103", subnet: "255.255.255.0", gateway: "192.168.1.1", type: "dynamic", status: "available", vlan: "100", pool: "residential" });
    await storage.createIpAddress({ ipAddress: "192.168.1.104", subnet: "255.255.255.0", gateway: "192.168.1.1", type: "dynamic", status: "available", vlan: "100", pool: "residential" });
    await storage.createIpAddress({ ipAddress: "10.0.1.51", subnet: "255.255.255.0", gateway: "10.0.1.1", type: "reserved", status: "reserved", vlan: "200", pool: "corporate", notes: "Reserved for upcoming corporate client" });
    await storage.createIpAddress({ ipAddress: "172.16.0.1", subnet: "255.255.0.0", gateway: "172.16.0.1", type: "static", status: "blocked", vlan: "999", pool: "management", notes: "Management interface - do not assign" });

    await storage.createOutage({ outageId: "OUT-001", title: "DHA Phase 5 Fiber Cut", description: "Fiber cable cut during road construction work near DHA Phase 5 main boulevard", affectedArea: "DHA Phase 5", affectedCustomers: 78, severity: "major", type: "unplanned", status: "resolved", startTime: "2025-02-19T14:00:00Z", estimatedRestore: "2025-02-19T18:00:00Z", endTime: "2025-02-19T16:30:00Z", rootCause: "Road construction damaged underground fiber conduit", resolution: "Fiber spliced and conduit repaired", notifiedCustomers: true, createdBy: "admin" });
    await storage.createOutage({ outageId: "OUT-002", title: "Scheduled Maintenance - Core Router Upgrade", description: "Upgrading core router firmware to latest version for improved performance", affectedArea: "All Areas", affectedCustomers: 354, severity: "minor", type: "maintenance", status: "scheduled", startTime: "2025-02-25T02:00:00Z", estimatedRestore: "2025-02-25T05:00:00Z", notifiedCustomers: true, createdBy: "admin" });
    await storage.createOutage({ outageId: "OUT-003", title: "Gulberg Power Outage Impact", description: "Extended power outage affecting Gulberg POP site. Backup generator running.", affectedArea: "Gulberg", affectedCustomers: 45, severity: "critical", type: "unplanned", status: "ongoing", startTime: "2025-02-23T08:00:00Z", estimatedRestore: "2025-02-23T14:00:00Z", notifiedCustomers: true, createdBy: "admin" });

    log("Database seeded successfully!", "seed");
  } catch (error) {
    log(`Seed error: ${error}`, "seed");
  }
}
