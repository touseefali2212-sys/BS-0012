import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import session from "express-session";
import multer from "multer";
import path from "path";
import fs from "fs";
import { storage } from "./storage";
import {
  loginSchema, insertCustomerSchema, insertPackageSchema, insertInvoiceSchema,
  insertTicketSchema, insertAreaSchema, insertVendorSchema, insertResellerSchema,
  insertAccountSchema, insertTransactionSchema, insertTaskSchema, insertAssetSchema,
  insertInventoryItemSchema, insertEmployeeSchema, insertRoleSchema,
  insertCompanySettingsSchema, insertNotificationSchema, insertReportSchema,
  insertSettingSchema, insertCustomerConnectionSchema,
  insertNotificationTemplateSchema, insertSmtpSettingsSchema, insertSmsSettingsSchema,
  insertNotificationDispatchSchema, insertBranchSchema,
  insertVendorWalletTransactionSchema, insertResellerWalletTransactionSchema, insertVendorPackageSchema, insertVendorBandwidthLinkSchema, insertBandwidthChangeHistorySchema,
  insertCustomerQuerySchema,
  insertSupportCategorySchema,
  insertInvoiceItemSchema,
  insertExpenseSchema, insertAttendanceSchema, insertAuditLogSchema,
  insertCreditNoteSchema, insertBulkMessageSchema, insertIpAddressSchema, insertOutageSchema,
  insertNetworkDeviceSchema, insertPppoeUserSchema, insertRadiusProfileSchema,
  insertPaymentGatewaySchema, insertPaymentSchema, insertBillingRuleSchema, insertBandwidthUsageSchema, insertDailyCollectionSchema,
} from "@shared/schema";
import { seedDatabase } from "./seed";
import { z } from "zod";

const uploadsDir = path.join(process.cwd(), "client", "public", "uploads");
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

const logoStorage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadsDir),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `logo-${Date.now()}${ext}`);
  },
});

const uploadLogo = multer({
  storage: logoStorage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowed = [".png", ".jpg", ".jpeg", ".gif", ".svg", ".webp"];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowed.includes(ext)) {
      cb(null, true);
    } else {
      cb(new Error("Only image files are allowed"));
    }
  },
});

declare module "express-session" {
  interface SessionData {
    userId: number;
  }
}

function requireAuth(req: Request, res: Response, next: NextFunction) {
  if (!req.session.userId) {
    return res.status(401).json({ message: "Unauthorized" });
  }
  next();
}

function crudRoutes<T>(
  app: Express,
  path: string,
  schema: any,
  getAll: () => Promise<T[]>,
  getOne: (id: number) => Promise<T | undefined>,
  create: (data: any) => Promise<T>,
  update: (id: number, data: any) => Promise<T | undefined>,
  remove: (id: number) => Promise<void>,
) {
  app.get(`/api/${path}`, requireAuth, async (_req, res) => {
    try { res.json(await getAll()); }
    catch (error) { res.status(500).json({ message: `Failed to fetch ${path}` }); }
  });

  app.post(`/api/${path}`, requireAuth, async (req, res) => {
    try {
      const parsed = schema.safeParse(req.body);
      if (!parsed.success) return res.status(400).json({ message: "Invalid data", errors: parsed.error.flatten() });
      const item = await create(parsed.data);
      res.status(201).json(item);
    } catch (error: any) {
      res.status(500).json({ message: error.message || `Failed to create ${path}` });
    }
  });

  app.patch(`/api/${path}/:id`, requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const partial = schema.partial().safeParse(req.body);
      if (!partial.success) return res.status(400).json({ message: "Invalid data", errors: partial.error.flatten() });
      const updated = await update(id, partial.data);
      if (!updated) return res.status(404).json({ message: "Not found" });
      res.json(updated);
    } catch (error: any) {
      res.status(500).json({ message: error.message || `Failed to update` });
    }
  });

  app.delete(`/api/${path}/:id`, requireAuth, async (req, res) => {
    try {
      await remove(parseInt(req.params.id));
      res.json({ message: "Deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete" });
    }
  });
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.use(
    session({
      secret: process.env.SESSION_SECRET || "netsphere-dev-secret-key",
      resave: false,
      saveUninitialized: false,
      cookie: {
        secure: false,
        maxAge: 24 * 60 * 60 * 1000,
      },
    })
  );

  await seedDatabase();

  app.post("/api/auth/login", async (req, res) => {
    try {
      const parsed = loginSchema.safeParse(req.body);
      if (!parsed.success) {
        return res.status(400).json({ message: "Invalid credentials" });
      }
      const user = await storage.getUserByUsername(parsed.data.username);
      if (!user || user.password !== parsed.data.password) {
        return res.status(401).json({ message: "Invalid username or password" });
      }
      req.session.userId = user.id;
      const { password: _, ...safeUser } = user;
      res.json(safeUser);
    } catch (error) {
      res.status(500).json({ message: "Login failed" });
    }
  });

  app.get("/api/auth/me", async (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    const user = await storage.getUser(req.session.userId);
    if (!user) {
      return res.status(401).json({ message: "User not found" });
    }
    const { password: _, ...safeUser } = user;
    res.json(safeUser);
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy(() => {
      res.json({ message: "Logged out" });
    });
  });

  app.get("/api/dashboard/stats", requireAuth, async (_req, res) => {
    try {
      const stats = await storage.getDashboardStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  app.get("/api/dashboard/recent-invoices", requireAuth, async (_req, res) => {
    try {
      const all = await storage.getInvoices();
      res.json(all.slice(0, 5));
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch invoices" });
    }
  });

  app.get("/api/dashboard/recent-tickets", requireAuth, async (_req, res) => {
    try {
      const all = await storage.getTickets();
      const open = all.filter(t => t.status === "open" || t.status === "in_progress");
      res.json(open.slice(0, 5));
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch tickets" });
    }
  });

  app.get("/api/dashboard/revenue-overview", requireAuth, async (_req, res) => {
    try {
      const allInvoices = await storage.getInvoices();
      const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      const now = new Date();
      const data = [];
      for (let i = 5; i >= 0; i--) {
        const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
        const monthKey = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
        const monthInvoices = allInvoices.filter(inv => {
          const issueDate = inv.issueDate ? new Date(inv.issueDate) : null;
          return issueDate && `${issueDate.getFullYear()}-${String(issueDate.getMonth() + 1).padStart(2, "0")}` === monthKey;
        });
        const billed = monthInvoices.reduce((sum, inv) => sum + Number(inv.totalAmount || 0), 0);
        const collected = monthInvoices.filter(inv => inv.status === "paid").reduce((sum, inv) => sum + Number(inv.totalAmount || 0), 0);
        const dues = billed - collected;
        data.push({
          month: months[d.getMonth()],
          billed: Math.round(billed),
          collected: Math.round(collected),
          dues: Math.round(dues),
        });
      }
      res.json(data);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch revenue overview" });
    }
  });

  app.get("/api/dashboard/ticket-breakdown", requireAuth, async (_req, res) => {
    try {
      const allTickets = await storage.getTickets();
      const open = allTickets.filter(t => t.status === "open").length;
      const inProgress = allTickets.filter(t => t.status === "in_progress").length;
      const resolved = allTickets.filter(t => t.status === "resolved" || t.status === "closed").length;
      const total = allTickets.length;
      res.json({
        open,
        inProgress,
        resolved,
        total,
        openPercent: total > 0 ? Math.round((open / total) * 100) : 0,
        inProgressPercent: total > 0 ? Math.round((inProgress / total) * 100) : 0,
        resolvedPercent: total > 0 ? Math.round((resolved / total) * 100) : 0,
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch ticket breakdown" });
    }
  });

  app.get("/api/dashboard/technician-performance", requireAuth, async (_req, res) => {
    try {
      const allTasks = await storage.getTasks();
      const techMap: Record<string, { completed: number; total: number }> = {};
      for (const task of allTasks) {
        const tech = task.assignedTo || "Unassigned";
        if (!techMap[tech]) techMap[tech] = { completed: 0, total: 0 };
        techMap[tech].total++;
        if (task.status === "completed") techMap[tech].completed++;
      }
      const result = Object.entries(techMap)
        .map(([name, stats]) => ({ name, jobsCompleted: stats.completed, totalJobs: stats.total }))
        .sort((a, b) => b.jobsCompleted - a.jobsCompleted)
        .slice(0, 5);
      res.json(result);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch technician performance" });
    }
  });

  app.post("/api/billing/generate-recurring", requireAuth, async (_req, res) => {
    try {
      const allCustomers = await storage.getCustomers();
      const today = new Date().toISOString().split("T")[0];
      const generated: any[] = [];

      for (const customer of allCustomers) {
        if (!customer.isRecurring || customer.status !== "active" || !customer.packageId) continue;

        const nextBilling = customer.nextBillingDate;
        if (nextBilling && nextBilling > today) continue;

        const pkg = await storage.getPackage(customer.packageId);
        if (!pkg) continue;

        const amount = customer.monthlyBill || pkg.price;
        const taxRate = 0.17;
        const tax = (Number(amount) * taxRate).toFixed(2);
        const totalAmount = (Number(amount) + Number(tax)).toFixed(2);

        const invoiceCount = (await storage.getInvoicesByCustomer(customer.id)).length;
        const invoiceNumber = `INV-${new Date().getFullYear()}-${String(customer.id).padStart(3, "0")}-${String(invoiceCount + 1).padStart(3, "0")}`;

        const now = new Date();
        const dueDay = customer.recurringDay || 15;
        const dueDate = new Date(now.getFullYear(), now.getMonth() + 1, dueDay).toISOString().split("T")[0];
        const issueDate = today;

        const invoice = await storage.createInvoice({
          invoiceNumber,
          customerId: customer.id,
          amount: String(amount),
          tax,
          totalAmount,
          status: "pending",
          dueDate,
          issueDate,
          description: `Recurring ${pkg.serviceType || "internet"} service - ${pkg.name}`,
          isRecurring: true,
          serviceType: pkg.serviceType || "internet",
        });

        const nextMonth = new Date(now.getFullYear(), now.getMonth() + 1, customer.recurringDay || 1);
        await storage.updateCustomer(customer.id, {
          lastBilledDate: today,
          nextBillingDate: nextMonth.toISOString().split("T")[0],
        });

        generated.push({ invoiceId: invoice.id, invoiceNumber, customerId: customer.id, customerName: customer.fullName, amount: totalAmount });
      }

      res.json({ generated: generated.length, invoices: generated });
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Failed to generate recurring invoices" });
    }
  });

  app.get("/api/analytics/branch-stats", requireAuth, async (_req, res) => {
    try {
      const [customers, resellers, allExpenses, resellerTxns] = await Promise.all([
        storage.getCustomers(),
        storage.getResellers(),
        storage.getExpenses(),
        storage.getAllResellerWalletTransactions(),
      ]);
      const now = new Date();
      const thisMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
      const lastMonth = now.getMonth() === 0
        ? `${now.getFullYear() - 1}-12`
        : `${now.getFullYear()}-${String(now.getMonth()).padStart(2, "0")}`;

      const resellerMap: Record<number, typeof resellers[0]> = {};
      for (const r of resellers) resellerMap[r.id] = r;

      const resellerTxnsByReseller: Record<number, typeof resellerTxns> = {};
      for (const t of resellerTxns) {
        if (!resellerTxnsByReseller[t.resellerId]) resellerTxnsByReseller[t.resellerId] = [];
        resellerTxnsByReseller[t.resellerId].push(t);
      }

      const areaNames = [...new Set([
        ...customers.map(c => c.area).filter(Boolean),
        ...resellers.map(r => r.area).filter(Boolean),
      ])] as string[];

      const areaStats = areaNames.map(areaName => {
        const areaCusts = customers.filter(c => c.area?.toLowerCase() === areaName.toLowerCase());
        const active = areaCusts.filter(c => c.status === "active");
        const suspended = areaCusts.filter(c => c.status === "suspended");
        const inactive = areaCusts.filter(c => c.status === "inactive");
        const revenue = active.reduce((s, c) => s + parseFloat(c.monthlyBill || "0"), 0);
        const newThisMonth = areaCusts.filter(c => c.connectionDate && c.connectionDate.startsWith(thisMonth)).length;
        const newLastMonth = areaCusts.filter(c => c.connectionDate && c.connectionDate.startsWith(lastMonth)).length;
        const growthPct = newLastMonth > 0 ? ((newThisMonth - newLastMonth) / newLastMonth * 100).toFixed(1) : newThisMonth > 0 ? "100.0" : "0.0";
        const closedPct = areaCusts.length > 0 ? (((suspended.length + inactive.length) / areaCusts.length) * 100).toFixed(1) : "0.0";

        const areaResellers = resellers.filter(r => r.area?.toLowerCase() === areaName.toLowerCase());
        const resellerRevenue = areaResellers.reduce((sum, r) => {
          const txns = resellerTxnsByReseller[r.id] || [];
          const credits = txns.filter(t => t.type === "credit" || t.type === "recharge").reduce((s, t) => s + parseFloat(t.amount || "0"), 0);
          return sum + credits;
        }, 0);

        const areaExpenses = allExpenses.filter(e => e.area?.toLowerCase() === areaName.toLowerCase() && e.status === "approved");
        const totalExpenses = areaExpenses.reduce((s, e) => s + parseFloat(e.amount || "0"), 0);
        const profitLoss = revenue - totalExpenses;

        return {
          area: areaName,
          totalCustomers: areaCusts.length,
          activeCustomers: active.length,
          suspendedCustomers: suspended.length,
          inactiveCustomers: inactive.length,
          monthlyRevenue: revenue,
          newThisMonth,
          newLastMonth,
          growthPct: parseFloat(growthPct),
          closedPct: parseFloat(closedPct),
          resellersCount: areaResellers.length,
          resellerRevenue,
          totalExpenses,
          profitLoss,
        };
      });

      res.json(areaStats);
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Failed to compute branch stats" });
    }
  });

  crudRoutes(app, "customers", insertCustomerSchema,
    () => storage.getCustomers(),
    (id) => storage.getCustomer(id),
    (data) => storage.createCustomer(data),
    (id, data) => storage.updateCustomer(id, data),
    (id) => storage.deleteCustomer(id),
  );

  app.get("/api/customers/:id", requireAuth, async (req, res) => {
    try {
      const customer = await storage.getCustomer(parseInt(req.params.id));
      if (!customer) return res.status(404).json({ message: "Customer not found" });
      res.json(customer);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch customer" });
    }
  });

  app.get("/api/customers/:id/invoices", requireAuth, async (req, res) => {
    try {
      res.json(await storage.getInvoicesByCustomer(parseInt(req.params.id)));
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch customer invoices" });
    }
  });

  app.get("/api/customers/:id/tickets", requireAuth, async (req, res) => {
    try {
      res.json(await storage.getTicketsByCustomer(parseInt(req.params.id)));
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch customer tickets" });
    }
  });

  app.get("/api/customers/:id/connections", requireAuth, async (req, res) => {
    try {
      res.json(await storage.getCustomerConnections(parseInt(req.params.id)));
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch connections" });
    }
  });

  app.get("/api/customers/:id/transactions", requireAuth, async (req, res) => {
    try {
      res.json(await storage.getTransactionsByCustomer(parseInt(req.params.id)));
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch transactions" });
    }
  });

  crudRoutes(app, "packages", insertPackageSchema,
    () => storage.getPackages(),
    (id) => storage.getPackage(id),
    (data) => storage.createPackage(data),
    (id, data) => storage.updatePackage(id, data),
    (id) => storage.deletePackage(id),
  );

  crudRoutes(app, "invoices", insertInvoiceSchema,
    () => storage.getInvoices(),
    (id) => storage.getInvoice(id),
    (data) => storage.createInvoice(data),
    (id, data) => storage.updateInvoice(id, data),
    (id) => storage.deleteInvoice(id),
  );

  app.get("/api/invoice-items/:invoiceId", requireAuth, async (req, res) => {
    try {
      const items = await storage.getInvoiceItems(parseInt(req.params.invoiceId));
      res.json(items);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch invoice items" });
    }
  });

  app.post("/api/invoice-items", requireAuth, async (req, res) => {
    try {
      const parsed = insertInvoiceItemSchema.parse(req.body);
      const item = await storage.createInvoiceItem(parsed);
      res.status(201).json(item);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Failed to create invoice item" });
    }
  });

  app.patch("/api/invoice-items/:id", requireAuth, async (req, res) => {
    try {
      const updated = await storage.updateInvoiceItem(parseInt(req.params.id), req.body);
      if (!updated) return res.status(404).json({ message: "Item not found" });
      res.json(updated);
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Failed to update invoice item" });
    }
  });

  app.delete("/api/invoice-items/:id", requireAuth, async (req, res) => {
    try {
      await storage.deleteInvoiceItem(parseInt(req.params.id));
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete invoice item" });
    }
  });

  app.post("/api/invoices-with-items", requireAuth, async (req, res) => {
    try {
      const { invoice: invoiceData, items } = req.body;
      const parsedInvoice = insertInvoiceSchema.parse(invoiceData);
      const created = await storage.createInvoice(parsedInvoice);
      const createdItems = [];
      if (items && items.length > 0) {
        for (let i = 0; i < items.length; i++) {
          const parsed = insertInvoiceItemSchema.parse({ ...items[i], invoiceId: created.id, sortOrder: i });
          const item = await storage.createInvoiceItem(parsed);
          createdItems.push(item);
        }
      }
      res.status(201).json({ ...created, items: createdItems });
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Failed to create invoice with items" });
    }
  });

  app.put("/api/invoices-with-items/:id", requireAuth, async (req, res) => {
    try {
      const invoiceId = parseInt(req.params.id);
      const { invoice: invoiceData, items } = req.body;
      const updated = await storage.updateInvoice(invoiceId, invoiceData);
      if (!updated) return res.status(404).json({ message: "Invoice not found" });
      await storage.deleteInvoiceItemsByInvoiceId(invoiceId);
      const createdItems = [];
      if (items && items.length > 0) {
        for (let i = 0; i < items.length; i++) {
          const parsed = insertInvoiceItemSchema.parse({ ...items[i], invoiceId, sortOrder: i });
          const item = await storage.createInvoiceItem(parsed);
          createdItems.push(item);
        }
      }
      res.json({ ...updated, items: createdItems });
    } catch (error: any) {
      res.status(400).json({ message: error.message || "Failed to update invoice with items" });
    }
  });

  app.get("/api/invoices/:id/full", requireAuth, async (req, res) => {
    try {
      const invoice = await storage.getInvoice(parseInt(req.params.id));
      if (!invoice) return res.status(404).json({ message: "Invoice not found" });
      const items = await storage.getInvoiceItems(invoice.id);
      const customer = await storage.getCustomer(invoice.customerId);
      const allCompany = await storage.getCompanySettings();
      res.json({ invoice, items, customer, company: allCompany || null });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch invoice details" });
    }
  });

  crudRoutes(app, "tickets", insertTicketSchema,
    () => storage.getTickets(),
    (id) => storage.getTicket(id),
    (data) => storage.createTicket(data),
    (id, data) => storage.updateTicket(id, data),
    (id) => storage.deleteTicket(id),
  );

  crudRoutes(app, "support-categories", insertSupportCategorySchema,
    () => storage.getSupportCategories(),
    (id) => storage.getSupportCategory(id),
    (data) => storage.createSupportCategory(data),
    (id, data) => storage.updateSupportCategory(id, data),
    (id) => storage.deleteSupportCategory(id),
  );

  crudRoutes(app, "areas", insertAreaSchema,
    () => storage.getAreas(),
    (id) => storage.getArea(id),
    (data) => storage.createArea(data),
    (id, data) => storage.updateArea(id, data),
    (id) => storage.deleteArea(id),
  );

  crudRoutes(app, "vendors", insertVendorSchema,
    () => storage.getVendors(),
    (id) => storage.getVendor(id),
    (data) => storage.createVendor(data),
    (id, data) => storage.updateVendor(id, data),
    (id) => storage.deleteVendor(id),
  );

  crudRoutes(app, "resellers", insertResellerSchema,
    () => storage.getResellers(),
    (id) => storage.getReseller(id),
    (data) => storage.createReseller(data),
    (id, data) => storage.updateReseller(id, data),
    (id) => storage.deleteReseller(id),
  );

  app.get("/api/vendor-wallet-transactions/all", requireAuth, async (req, res) => {
    try {
      res.json(await storage.getAllVendorWalletTransactions());
    } catch (error: any) { res.status(500).json({ message: error.message }); }
  });

  app.get("/api/vendor-wallet-transactions/:vendorId", requireAuth, async (req, res) => {
    try {
      const vendorId = parseInt(req.params.vendorId);
      res.json(await storage.getVendorWalletTransactions(vendorId));
    } catch (error: any) { res.status(500).json({ message: error.message }); }
  });

  app.patch("/api/vendor-wallet-transactions/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const schema = z.object({ amount: z.union([z.number(), z.string()]).transform(v => parseFloat(String(v))).refine(v => v > 0, "Amount must be positive").optional(), paymentMethod: z.string().optional(), performedBy: z.string().optional(), approvedBy: z.string().optional(), notes: z.string().optional(), reason: z.string().optional(), reference: z.string().optional() });
      const parsed = schema.safeParse(req.body);
      if (!parsed.success) return res.status(400).json({ message: "Invalid data", errors: parsed.error.flatten() });
      const { amount, ...otherFields } = parsed.data;
      if (amount !== undefined) {
        const updated = await storage.updateVendorWalletTransactionWithAmount(id, amount, otherFields);
        if (!updated) return res.status(404).json({ message: "Transaction not found" });
        res.json(updated);
      } else {
        const updated = await storage.updateVendorWalletTransaction(id, otherFields);
        if (!updated) return res.status(404).json({ message: "Transaction not found" });
        res.json(updated);
      }
    } catch (error: any) { res.status(400).json({ message: error.message }); }
  });

  app.post("/api/vendor-wallet/recharge", requireAuth, async (req, res) => {
    try {
      const schema = z.object({ vendorId: z.number().int().positive(), amount: z.union([z.number(), z.string()]).transform(v => parseFloat(String(v))).refine(v => v > 0, "Amount must be positive"), reference: z.string().optional(), paymentMethod: z.string().optional(), performedBy: z.string().optional(), approvedBy: z.string().optional(), notes: z.string().optional() });
      const parsed = schema.safeParse(req.body);
      if (!parsed.success) return res.status(400).json({ message: "Invalid data", errors: parsed.error.flatten() });
      const vendor = await storage.getVendor(parsed.data.vendorId);
      if (!vendor) return res.status(404).json({ message: "Vendor not found" });
      const updated = await storage.rechargeVendorWallet(parsed.data.vendorId, parsed.data.amount, parsed.data.reference, parsed.data.paymentMethod, parsed.data.performedBy, parsed.data.approvedBy, parsed.data.notes);
      res.json(updated);
    } catch (error: any) { res.status(400).json({ message: error.message }); }
  });

  app.post("/api/vendor-wallet/deduct", requireAuth, async (req, res) => {
    try {
      const schema = z.object({ vendorId: z.number().int().positive(), amount: z.union([z.number(), z.string()]).transform(v => parseFloat(String(v))).refine(v => v > 0, "Amount must be positive"), reference: z.string().optional(), customerId: z.number().int().optional(), resellerId: z.number().int().optional(), reason: z.string().optional(), performedBy: z.string().optional(), approvedBy: z.string().optional(), notes: z.string().optional() });
      const parsed = schema.safeParse(req.body);
      if (!parsed.success) return res.status(400).json({ message: "Invalid data", errors: parsed.error.flatten() });
      const vendor = await storage.getVendor(parsed.data.vendorId);
      if (!vendor) return res.status(404).json({ message: "Vendor not found" });
      const updated = await storage.deductVendorWallet(parsed.data.vendorId, parsed.data.amount, parsed.data.reference, parsed.data.customerId, parsed.data.resellerId, parsed.data.reason, parsed.data.performedBy, parsed.data.approvedBy, parsed.data.notes);
      res.json(updated);
    } catch (error: any) { res.status(400).json({ message: error.message }); }
  });

  app.get("/api/reseller-wallet-transactions/:resellerId", requireAuth, async (req, res) => {
    try {
      const resellerId = parseInt(req.params.resellerId);
      res.json(await storage.getResellerWalletTransactions(resellerId));
    } catch (error: any) { res.status(500).json({ message: error.message }); }
  });

  app.post("/api/reseller-wallet/recharge", requireAuth, async (req, res) => {
    try {
      const schema = z.object({ resellerId: z.number().int().positive(), amount: z.union([z.number(), z.string()]).transform(v => parseFloat(String(v))).refine(v => v > 0, "Amount must be positive"), reference: z.string().optional() });
      const parsed = schema.safeParse(req.body);
      if (!parsed.success) return res.status(400).json({ message: "Invalid data", errors: parsed.error.flatten() });
      const reseller = await storage.rechargeResellerWallet(parsed.data.resellerId, parsed.data.amount, parsed.data.reference);
      res.json(reseller);
    } catch (error: any) { res.status(400).json({ message: error.message }); }
  });

  app.post("/api/reseller-wallet/deduct", requireAuth, async (req, res) => {
    try {
      const schema = z.object({ resellerId: z.number().int().positive(), amount: z.union([z.number(), z.string()]).transform(v => parseFloat(String(v))).refine(v => v > 0, "Amount must be positive"), reference: z.string().optional(), vendorId: z.number().int().optional(), customerId: z.number().int().optional() });
      const parsed = schema.safeParse(req.body);
      if (!parsed.success) return res.status(400).json({ message: "Invalid data", errors: parsed.error.flatten() });
      const reseller = await storage.deductResellerWallet(parsed.data.resellerId, parsed.data.amount, parsed.data.vendorId, parsed.data.customerId, parsed.data.reference);
      res.json(reseller);
    } catch (error: any) { res.status(400).json({ message: error.message }); }
  });

  crudRoutes(app, "vendor-packages", insertVendorPackageSchema,
    () => storage.getVendorPackages(),
    (id) => storage.getVendorPackage(id),
    (data) => storage.createVendorPackage(data),
    (id, data) => storage.updateVendorPackage(id, data),
    (id) => storage.deleteVendorPackage(id),
  );

  app.get("/api/vendor-packages/by-vendor/:vendorId", requireAuth, async (req, res) => {
    try {
      const vendorId = parseInt(req.params.vendorId);
      res.json(await storage.getVendorPackages(vendorId));
    } catch (error: any) { res.status(500).json({ message: error.message }); }
  });

  crudRoutes(app, "vendor-bandwidth-links", insertVendorBandwidthLinkSchema,
    () => storage.getVendorBandwidthLinks(),
    (id) => storage.getVendorBandwidthLink(id),
    (data) => storage.createVendorBandwidthLink(data),
    (id, data) => storage.updateVendorBandwidthLink(id, data),
    (id) => storage.deleteVendorBandwidthLink(id),
  );

  app.get("/api/vendor-bandwidth-links/by-vendor/:vendorId", requireAuth, async (req, res) => {
    try {
      const vendorId = parseInt(req.params.vendorId);
      res.json(await storage.getVendorBandwidthLinks(vendorId));
    } catch (error: any) { res.status(500).json({ message: error.message }); }
  });

  crudRoutes(app, "bandwidth-change-history", insertBandwidthChangeHistorySchema,
    () => storage.getBandwidthChangeHistory(),
    (id) => storage.getBandwidthChange(id),
    (data) => storage.createBandwidthChange(data),
    (id, data) => storage.updateBandwidthChange(id, data),
    (id) => storage.deleteBandwidthChange(id),
  );

  app.get("/api/bandwidth-change-history/by-vendor/:vendorId", requireAuth, async (req, res) => {
    try {
      const vendorId = parseInt(req.params.vendorId);
      res.json(await storage.getBandwidthChangeHistory(vendorId));
    } catch (error: any) { res.status(500).json({ message: error.message }); }
  });

  app.get("/api/bandwidth-change-history/by-link/:linkId", requireAuth, async (req, res) => {
    try {
      const linkId = parseInt(req.params.linkId);
      res.json(await storage.getBandwidthChangeHistoryByLink(linkId));
    } catch (error: any) { res.status(500).json({ message: error.message }); }
  });

  app.post("/api/bandwidth-upgrade-downgrade", requireAuth, async (req, res) => {
    try {
      const { linkId, newMbps, newRate, reason, requestedBy, effectiveDate, notes } = req.body;
      const link = await storage.getVendorBandwidthLink(linkId);
      if (!link) return res.status(404).json({ message: "Link not found" });

      const previousMbps = Number(link.bandwidthMbps);
      const previousRate = Number(link.bandwidthRate);
      const previousCost = Number(link.totalMonthlyCost);
      const newMbpsNum = Number(newMbps);
      const newRateNum = Number(newRate);
      const newCost = newMbpsNum * newRateNum;

      const changeType = newMbpsNum > previousMbps ? "upgrade" : newMbpsNum < previousMbps ? "downgrade" : "rate_change";

      const historyRecord = await storage.createBandwidthChange({
        vendorId: link.vendorId,
        linkId: link.id,
        changeType,
        previousMbps: String(previousMbps),
        newMbps: String(newMbpsNum),
        previousRate: String(previousRate),
        newRate: String(newRateNum),
        previousCost: String(previousCost),
        newCost: String(newCost),
        reason: reason || null,
        requestedBy: requestedBy || null,
        approvedBy: null,
        status: "completed",
        effectiveDate: effectiveDate || new Date().toISOString().split("T")[0],
        notes: notes || null,
      });

      await storage.updateVendorBandwidthLink(link.id, {
        bandwidthMbps: String(newMbpsNum),
        bandwidthRate: String(newRateNum),
        totalMonthlyCost: String(newCost),
      });

      res.status(201).json(historyRecord);
    } catch (error: any) { res.status(500).json({ message: error.message }); }
  });

  crudRoutes(app, "accounts", insertAccountSchema,
    () => storage.getAccounts(),
    (id) => storage.getAccount(id),
    (data) => storage.createAccount(data),
    (id, data) => storage.updateAccount(id, data),
    (id) => storage.deleteAccount(id),
  );

  crudRoutes(app, "transactions", insertTransactionSchema,
    () => storage.getTransactions(),
    (id) => storage.getTransaction(id),
    (data) => storage.createTransaction(data),
    (id, data) => storage.updateTransaction(id, data),
    (id) => storage.deleteTransaction(id),
  );

  crudRoutes(app, "tasks", insertTaskSchema,
    () => storage.getTasks(),
    (id) => storage.getTask(id),
    (data) => storage.createTask(data),
    (id, data) => storage.updateTask(id, data),
    (id) => storage.deleteTask(id),
  );

  crudRoutes(app, "assets", insertAssetSchema,
    () => storage.getAssets(),
    (id) => storage.getAsset(id),
    (data) => storage.createAsset(data),
    (id, data) => storage.updateAsset(id, data),
    (id) => storage.deleteAsset(id),
  );

  crudRoutes(app, "inventory", insertInventoryItemSchema,
    () => storage.getInventoryItems(),
    (id) => storage.getInventoryItem(id),
    (data) => storage.createInventoryItem(data),
    (id, data) => storage.updateInventoryItem(id, data),
    (id) => storage.deleteInventoryItem(id),
  );

  crudRoutes(app, "employees", insertEmployeeSchema,
    () => storage.getEmployees(),
    (id) => storage.getEmployee(id),
    (data) => storage.createEmployee(data),
    (id, data) => storage.updateEmployee(id, data),
    (id) => storage.deleteEmployee(id),
  );

  app.get("/api/employees/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) return res.status(400).json({ message: "Invalid employee ID" });
      const employee = await storage.getEmployee(id);
      if (!employee) return res.status(404).json({ message: "Employee not found" });
      res.json(employee);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch employee" });
    }
  });

  app.get("/api/employees/:id/salary-history", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) return res.status(400).json({ message: "Invalid employee ID" });
      const entries = await storage.getSalaryHistory(id);
      res.json(entries);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch salary history" });
    }
  });

  app.post("/api/salary-history", requireAuth, async (req, res) => {
    try {
      const { insertSalaryHistorySchema } = await import("@shared/schema");
      const parsed = insertSalaryHistorySchema.safeParse(req.body);
      if (!parsed.success) return res.status(400).json({ message: "Invalid data", errors: parsed.error.flatten() });
      const entry = await storage.createSalaryHistoryEntry(parsed.data);
      res.status(201).json(entry);
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Failed to create salary entry" });
    }
  });

  app.patch("/api/salary-history/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { insertSalaryHistorySchema } = await import("@shared/schema");
      const parsed = insertSalaryHistorySchema.partial().safeParse(req.body);
      if (!parsed.success) return res.status(400).json({ message: "Invalid data", errors: parsed.error.flatten() });
      const updated = await storage.updateSalaryHistoryEntry(id, parsed.data);
      if (!updated) return res.status(404).json({ message: "Not found" });
      res.json(updated);
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Failed to update" });
    }
  });

  app.delete("/api/salary-history/:id", requireAuth, async (req, res) => {
    try {
      await storage.deleteSalaryHistoryEntry(parseInt(req.params.id));
      res.json({ message: "Deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete" });
    }
  });

  crudRoutes(app, "roles", insertRoleSchema,
    () => storage.getRoles(),
    (id) => storage.getRole(id),
    (data) => storage.createRole(data),
    (id, data) => storage.updateRole(id, data),
    (id) => storage.deleteRole(id),
  );

  crudRoutes(app, "notifications", insertNotificationSchema,
    () => storage.getNotifications(),
    (id) => storage.getNotification(id),
    (data) => storage.createNotification(data),
    (id, data) => storage.updateNotification(id, data),
    (id) => storage.deleteNotification(id),
  );

  crudRoutes(app, "reports", insertReportSchema,
    () => storage.getReports(),
    (id) => storage.getReport(id),
    (data) => storage.createReport(data),
    (id, data) => storage.updateReport(id, data),
    (id) => storage.deleteReport(id),
  );

  app.get("/api/company", requireAuth, async (_req, res) => {
    try {
      const settings = await storage.getCompanySettings();
      res.json(settings || null);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch company settings" });
    }
  });

  app.post("/api/company", requireAuth, async (req, res) => {
    try {
      const parsed = insertCompanySettingsSchema.safeParse(req.body);
      if (!parsed.success) return res.status(400).json({ message: "Invalid data", errors: parsed.error.flatten() });
      const result = await storage.upsertCompanySettings(parsed.data);
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Failed to save company settings" });
    }
  });

  app.post("/api/upload/logo", requireAuth, uploadLogo.single("logo"), (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      const fileUrl = `/uploads/${req.file.filename}`;
      res.json({ url: fileUrl, filename: req.file.filename });
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Upload failed" });
    }
  });

  const docStorage = multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, uploadsDir),
    filename: (_req, file, cb) => {
      const ext = path.extname(file.originalname);
      cb(null, `doc-${Date.now()}-${Math.random().toString(36).slice(2, 8)}${ext}`);
    },
  });
  const uploadDoc = multer({
    storage: docStorage,
    limits: { fileSize: 10 * 1024 * 1024 },
    fileFilter: (_req, file, cb) => {
      const allowed = [".png", ".jpg", ".jpeg", ".gif", ".webp", ".pdf"];
      const ext = path.extname(file.originalname).toLowerCase();
      cb(null, allowed.includes(ext));
    },
  });

  app.post("/api/upload/document", requireAuth, uploadDoc.single("file"), (req: Request, res: Response) => {
    try {
      if (!req.file) return res.status(400).json({ message: "No file uploaded" });
      res.json({ url: `/uploads/${req.file.filename}`, filename: req.file.filename });
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Upload failed" });
    }
  });

  app.get("/api/customer-queries", requireAuth, async (_req, res) => {
    try {
      res.json(await storage.getCustomerQueries());
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Failed to fetch customer queries" });
    }
  });

  app.get("/api/customer-queries/:id", requireAuth, async (req, res) => {
    try {
      const q = await storage.getCustomerQuery(Number(req.params.id));
      if (!q) return res.status(404).json({ message: "Not found" });
      res.json(q);
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Failed to fetch query" });
    }
  });

  app.post("/api/customer-queries", requireAuth, async (req, res) => {
    try {
      const parsed = insertCustomerQuerySchema.safeParse(req.body);
      if (!parsed.success) return res.status(400).json({ message: "Invalid data", errors: parsed.error.flatten() });
      const result = await storage.createCustomerQuery(parsed.data);
      res.status(201).json(result);
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Failed to create query" });
    }
  });

  app.patch("/api/customer-queries/:id", requireAuth, async (req, res) => {
    try {
      const result = await storage.updateCustomerQuery(Number(req.params.id), req.body);
      if (!result) return res.status(404).json({ message: "Not found" });
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Failed to update query" });
    }
  });

  app.delete("/api/customer-queries/:id", requireAuth, async (req, res) => {
    try {
      await storage.deleteCustomerQuery(Number(req.params.id));
      res.json({ message: "Deleted" });
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Failed to delete query" });
    }
  });

  app.get("/api/settings", requireAuth, async (_req, res) => {
    try {
      res.json(await storage.getSettings());
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch settings" });
    }
  });

  app.post("/api/settings", requireAuth, async (req, res) => {
    try {
      const parsed = insertSettingSchema.safeParse(req.body);
      if (!parsed.success) return res.status(400).json({ message: "Invalid data", errors: parsed.error.flatten() });
      const result = await storage.upsertSetting(parsed.data);
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Failed to save setting" });
    }
  });

  app.patch("/api/settings/:id", requireAuth, async (req, res) => {
    try {
      const result = await storage.updateSetting(parseInt(req.params.id), req.body);
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Failed to update setting" });
    }
  });

  app.delete("/api/settings/:id", requireAuth, async (req, res) => {
    try {
      await storage.deleteSetting(parseInt(req.params.id));
      res.json({ message: "Deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete setting" });
    }
  });

  app.get("/api/customer-connections/:customerId", requireAuth, async (req, res) => {
    try {
      const connections = await storage.getCustomerConnections(parseInt(req.params.customerId));
      res.json(connections);
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Failed to get connections" });
    }
  });

  app.post("/api/customer-connections", requireAuth, async (req, res) => {
    try {
      const parsed = insertCustomerConnectionSchema.safeParse(req.body);
      if (!parsed.success) return res.status(400).json({ message: "Invalid data", errors: parsed.error.flatten() });
      const conn = await storage.createCustomerConnection(parsed.data);
      res.status(201).json(conn);
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Failed to create connection" });
    }
  });

  app.patch("/api/customer-connections/:id", requireAuth, async (req, res) => {
    try {
      const updated = await storage.updateCustomerConnection(parseInt(req.params.id), req.body);
      if (!updated) return res.status(404).json({ message: "Not found" });
      res.json(updated);
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Failed to update connection" });
    }
  });

  app.delete("/api/customer-connections/:id", requireAuth, async (req, res) => {
    try {
      await storage.deleteCustomerConnection(parseInt(req.params.id));
      res.json({ message: "Deleted" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete connection" });
    }
  });

  crudRoutes(
    app, "notification-templates", insertNotificationTemplateSchema,
    () => storage.getNotificationTemplates(),
    (id) => storage.getNotificationTemplate(id),
    (data) => storage.createNotificationTemplate(data),
    (id, data) => storage.updateNotificationTemplate(id, data),
    (id) => storage.deleteNotificationTemplate(id),
  );

  crudRoutes(
    app, "branches", insertBranchSchema,
    () => storage.getBranches(),
    (id) => storage.getBranch(id),
    (data) => storage.createBranch(data),
    (id, data) => storage.updateBranch(id, data),
    (id) => storage.deleteBranch(id),
  );

  app.get("/api/smtp-settings", requireAuth, async (_req, res) => {
    try {
      const s = await storage.getSmtpSettings();
      res.json(s || null);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch SMTP settings" });
    }
  });

  app.post("/api/smtp-settings", requireAuth, async (req, res) => {
    try {
      const parsed = insertSmtpSettingsSchema.safeParse(req.body);
      if (!parsed.success) return res.status(400).json({ message: "Invalid data", errors: parsed.error.flatten() });
      const result = await storage.upsertSmtpSettings(parsed.data);
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Failed to save SMTP settings" });
    }
  });

  app.get("/api/sms-settings", requireAuth, async (_req, res) => {
    try {
      const s = await storage.getSmsSettings();
      res.json(s || null);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch SMS settings" });
    }
  });

  app.post("/api/sms-settings", requireAuth, async (req, res) => {
    try {
      const parsed = insertSmsSettingsSchema.safeParse(req.body);
      if (!parsed.success) return res.status(400).json({ message: "Invalid data", errors: parsed.error.flatten() });
      const result = await storage.upsertSmsSettings(parsed.data);
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Failed to save SMS settings" });
    }
  });

  app.get("/api/notification-dispatches", requireAuth, async (_req, res) => {
    try {
      res.json(await storage.getNotificationDispatches());
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dispatches" });
    }
  });

  app.get("/api/activity-logs", requireAuth, async (_req, res) => {
    try {
      res.json(await storage.getActivityLogs());
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch activity logs" });
    }
  });

  app.post("/api/notifications/send-email", requireAuth, async (req, res) => {
    try {
      const { to, subject, body, templateId } = req.body;
      if (!to || !subject || !body) {
        return res.status(400).json({ message: "Missing required fields: to, subject, body" });
      }
      const smtpConfig = await storage.getSmtpSettings();
      if (!smtpConfig || !smtpConfig.isActive) {
        return res.status(400).json({ message: "SMTP is not configured. Please set up SMTP settings first." });
      }
      const nodemailer = await import("nodemailer");
      const transporter = nodemailer.createTransport({
        host: smtpConfig.host,
        port: smtpConfig.port,
        secure: smtpConfig.encryption === "ssl",
        auth: { user: smtpConfig.username, pass: smtpConfig.password },
      });
      await transporter.sendMail({
        from: smtpConfig.fromName ? `"${smtpConfig.fromName}" <${smtpConfig.fromEmail}>` : smtpConfig.fromEmail,
        to,
        subject,
        html: body,
      });
      const dispatch = await storage.createNotificationDispatch({
        templateId: templateId || null,
        channel: "email",
        recipient: to,
        subject,
        body,
        status: "sent",
        sentAt: new Date().toISOString(),
        createdAt: new Date().toISOString(),
      });
      res.json({ success: true, dispatch });
    } catch (error: any) {
      const dispatch = await storage.createNotificationDispatch({
        channel: "email",
        recipient: req.body.to || "",
        subject: req.body.subject || "",
        body: req.body.body || "",
        status: "failed",
        errorMessage: error.message,
        createdAt: new Date().toISOString(),
      });
      res.status(500).json({ message: error.message || "Failed to send email", dispatch });
    }
  });

  app.post("/api/notifications/send-sms", requireAuth, async (req, res) => {
    try {
      const { to, message, templateId } = req.body;
      if (!to || !message) {
        return res.status(400).json({ message: "Missing required fields: to, message" });
      }
      const smsConfig = await storage.getSmsSettings();
      if (!smsConfig || !smsConfig.isActive) {
        return res.status(400).json({ message: "SMS API is not configured. Please set up SMS settings first." });
      }
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      if (smsConfig.headerParams) {
        try {
          const extra = JSON.parse(smsConfig.headerParams);
          Object.assign(headers, extra);
        } catch {}
      }
      if (smsConfig.apiKey) {
        headers["Authorization"] = `Bearer ${smsConfig.apiKey}`;
      }
      let bodyPayload = smsConfig.bodyTemplate
        ? smsConfig.bodyTemplate.replace("{{to}}", to).replace("{{message}}", message).replace("{{sender_id}}", smsConfig.senderId || "")
        : JSON.stringify({ to, message, sender_id: smsConfig.senderId });

      const response = await fetch(smsConfig.apiUrl, {
        method: smsConfig.httpMethod || "POST",
        headers,
        body: smsConfig.httpMethod === "GET" ? undefined : bodyPayload,
      });
      const responseData = await response.text();
      const dispatch = await storage.createNotificationDispatch({
        templateId: templateId || null,
        channel: "sms",
        recipient: to,
        body: message,
        status: response.ok ? "sent" : "failed",
        errorMessage: response.ok ? undefined : responseData,
        sentAt: response.ok ? new Date().toISOString() : undefined,
        createdAt: new Date().toISOString(),
      });
      if (response.ok) {
        res.json({ success: true, dispatch });
      } else {
        res.status(500).json({ message: `SMS API returned error: ${responseData}`, dispatch });
      }
    } catch (error: any) {
      const dispatch = await storage.createNotificationDispatch({
        channel: "sms",
        recipient: req.body.to || "",
        body: req.body.message || "",
        status: "failed",
        errorMessage: error.message,
        createdAt: new Date().toISOString(),
      });
      res.status(500).json({ message: error.message || "Failed to send SMS", dispatch });
    }
  });

  app.post("/api/notifications/send-bulk", requireAuth, async (req, res) => {
    try {
      const { channel, recipients, subject, body, templateId } = req.body;
      if (!channel || !recipients || !Array.isArray(recipients) || recipients.length === 0 || !body) {
        return res.status(400).json({ message: "Missing required fields: channel, recipients[], body" });
      }
      const results = [];
      for (const recipient of recipients) {
        try {
          if (channel === "email") {
            const smtpConfig = await storage.getSmtpSettings();
            if (smtpConfig && smtpConfig.isActive) {
              const nodemailer = await import("nodemailer");
              const transporter = nodemailer.createTransport({
                host: smtpConfig.host,
                port: smtpConfig.port,
                secure: smtpConfig.encryption === "ssl",
                auth: { user: smtpConfig.username, pass: smtpConfig.password },
              });
              await transporter.sendMail({
                from: smtpConfig.fromName ? `"${smtpConfig.fromName}" <${smtpConfig.fromEmail}>` : smtpConfig.fromEmail,
                to: recipient,
                subject: subject || "Notification",
                html: body,
              });
            }
          } else if (channel === "sms") {
            const smsConfig = await storage.getSmsSettings();
            if (smsConfig && smsConfig.isActive) {
              const smsHeaders: Record<string, string> = { "Content-Type": "application/json" };
              if (smsConfig.apiKey) smsHeaders["Authorization"] = `Bearer ${smsConfig.apiKey}`;
              const smsBody = smsConfig.bodyTemplate
                ? smsConfig.bodyTemplate.replace("{{to}}", recipient).replace("{{message}}", body)
                : JSON.stringify({ to: recipient, message: body, sender_id: smsConfig.senderId });
              await fetch(smsConfig.apiUrl, { method: smsConfig.httpMethod || "POST", headers: smsHeaders, body: smsBody });
            }
          }
          const dispatch = await storage.createNotificationDispatch({
            templateId: templateId || null,
            channel,
            recipient,
            subject: subject || undefined,
            body,
            status: "sent",
            sentAt: new Date().toISOString(),
            createdAt: new Date().toISOString(),
          });
          results.push({ recipient, status: "sent", dispatch });
        } catch (err: any) {
          const dispatch = await storage.createNotificationDispatch({
            channel,
            recipient,
            body,
            status: "failed",
            errorMessage: err.message,
            createdAt: new Date().toISOString(),
          });
          results.push({ recipient, status: "failed", error: err.message, dispatch });
        }
      }
      res.json({ total: recipients.length, sent: results.filter(r => r.status === "sent").length, results });
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Failed to send bulk notifications" });
    }
  });

  // Expenses CRUD
  crudRoutes(app, "expenses", insertExpenseSchema,
    () => storage.getExpenses(),
    (id) => storage.getExpense(id),
    (data) => storage.createExpense(data),
    (id, data) => storage.updateExpense(id, data),
    (id) => storage.deleteExpense(id),
  );

  // Attendance CRUD
  app.get("/api/attendance", requireAuth, async (req, res) => {
    try {
      const employeeId = req.query.employeeId ? parseInt(req.query.employeeId as string) : undefined;
      res.json(await storage.getAttendanceRecords(employeeId));
    } catch (error) { res.status(500).json({ message: "Failed to fetch attendance" }); }
  });
  app.post("/api/attendance", requireAuth, async (req, res) => {
    try {
      const parsed = insertAttendanceSchema.safeParse(req.body);
      if (!parsed.success) return res.status(400).json({ message: "Invalid data", errors: parsed.error.flatten() });
      res.status(201).json(await storage.createAttendance(parsed.data));
    } catch (error: any) { res.status(500).json({ message: error.message || "Failed to create attendance" }); }
  });
  app.patch("/api/attendance/:id", requireAuth, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updated = await storage.updateAttendance(id, req.body);
      if (!updated) return res.status(404).json({ message: "Not found" });
      res.json(updated);
    } catch (error: any) { res.status(500).json({ message: error.message }); }
  });
  app.delete("/api/attendance/:id", requireAuth, async (req, res) => {
    try {
      await storage.deleteAttendance(parseInt(req.params.id));
      res.status(204).send();
    } catch (error) { res.status(500).json({ message: "Failed to delete" }); }
  });

  // Audit Logs
  app.get("/api/audit-logs", requireAuth, async (_req, res) => {
    try { res.json(await storage.getAuditLogs()); }
    catch (error) { res.status(500).json({ message: "Failed to fetch audit logs" }); }
  });
  app.post("/api/audit-logs", requireAuth, async (req, res) => {
    try {
      const parsed = insertAuditLogSchema.safeParse(req.body);
      if (!parsed.success) return res.status(400).json({ message: "Invalid data" });
      res.status(201).json(await storage.createAuditLog(parsed.data));
    } catch (error: any) { res.status(500).json({ message: error.message }); }
  });

  // Credit Notes CRUD
  crudRoutes(app, "credit-notes", insertCreditNoteSchema,
    () => storage.getCreditNotes(),
    (id) => storage.getCreditNote(id),
    (data) => storage.createCreditNote(data),
    (id, data) => storage.updateCreditNote(id, data),
    (id) => storage.deleteCreditNote(id),
  );

  // Bulk Messages CRUD
  crudRoutes(app, "bulk-messages", insertBulkMessageSchema,
    () => storage.getBulkMessages(),
    (id) => storage.getBulkMessage(id),
    (data) => storage.createBulkMessage(data),
    (id, data) => storage.updateBulkMessage(id, data),
    (id) => storage.deleteBulkMessage(id),
  );

  // IP Addresses CRUD
  crudRoutes(app, "ip-addresses", insertIpAddressSchema,
    () => storage.getIpAddresses(),
    (id) => storage.getIpAddress(id),
    (data) => storage.createIpAddress(data),
    (id, data) => storage.updateIpAddress(id, data),
    (id) => storage.deleteIpAddress(id),
  );

  // Outages CRUD
  crudRoutes(app, "outages", insertOutageSchema,
    () => storage.getOutages(),
    (id) => storage.getOutage(id),
    (data) => storage.createOutage(data),
    (id, data) => storage.updateOutage(id, data),
    (id) => storage.deleteOutage(id),
  );

  // Network Devices CRUD
  crudRoutes(app, "network-devices", insertNetworkDeviceSchema,
    () => storage.getNetworkDevices(),
    (id) => storage.getNetworkDevice(id),
    (data) => storage.createNetworkDevice(data),
    (id, data) => storage.updateNetworkDevice(id, data),
    (id) => storage.deleteNetworkDevice(id),
  );

  // PPPoE Users CRUD
  crudRoutes(app, "pppoe-users", insertPppoeUserSchema,
    () => storage.getPppoeUsers(),
    (id) => storage.getPppoeUser(id),
    (data) => storage.createPppoeUser(data),
    (id, data) => storage.updatePppoeUser(id, data),
    (id) => storage.deletePppoeUser(id),
  );

  // RADIUS Profiles CRUD
  crudRoutes(app, "radius-profiles", insertRadiusProfileSchema,
    () => storage.getRadiusProfiles(),
    (id) => storage.getRadiusProfile(id),
    (data) => storage.createRadiusProfile(data),
    (id, data) => storage.updateRadiusProfile(id, data),
    (id) => storage.deleteRadiusProfile(id),
  );

  // Payment Gateways CRUD
  crudRoutes(app, "payment-gateways", insertPaymentGatewaySchema,
    () => storage.getPaymentGateways(),
    (id) => storage.getPaymentGateway(id),
    (data) => storage.createPaymentGateway(data),
    (id, data) => storage.updatePaymentGateway(id, data),
    (id) => storage.deletePaymentGateway(id),
  );

  // Payments CRUD
  crudRoutes(app, "payments", insertPaymentSchema,
    () => storage.getPayments(),
    (id) => storage.getPayment(id),
    (data) => storage.createPayment(data),
    (id, data) => storage.updatePayment(id, data),
    (id) => storage.deletePayment(id),
  );

  // Billing Rules CRUD
  crudRoutes(app, "billing-rules", insertBillingRuleSchema,
    () => storage.getBillingRules(),
    (id) => storage.getBillingRule(id),
    (data) => storage.createBillingRule(data),
    (id, data) => storage.updateBillingRule(id, data),
    (id) => storage.deleteBillingRule(id),
  );

  // Bandwidth Usage CRUD
  crudRoutes(app, "bandwidth-usage", insertBandwidthUsageSchema,
    () => storage.getBandwidthUsage(),
    (id) => storage.getBandwidthUsageById(id),
    (data) => storage.createBandwidthUsage(data),
    (id, data) => storage.updateBandwidthUsage(id, data),
    (id) => storage.deleteBandwidthUsage(id),
  );

  app.get("/api/bandwidth-usage/customer/:customerId", requireAuth, async (req, res) => {
    try {
      res.json(await storage.getBandwidthUsageByCustomer(parseInt(req.params.customerId)));
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch bandwidth usage" });
    }
  });

  // Daily Collections CRUD
  crudRoutes(app, "daily-collections", insertDailyCollectionSchema,
    () => storage.getDailyCollections(),
    (id) => storage.getDailyCollection(id),
    (data) => storage.createDailyCollection(data),
    (id, data) => storage.updateDailyCollection(id, data),
    (id) => storage.deleteDailyCollection(id),
  );

  // Users management
  app.get("/api/users", requireAuth, async (_req, res) => {
    try { res.json(await storage.getUsers()); }
    catch (error) { res.status(500).json({ message: "Failed to fetch users" }); }
  });

  // CSV Export
  app.get("/api/export/:entity", requireAuth, async (req, res) => {
    try {
      const entity = req.params.entity;
      let data: any[] = [];
      switch (entity) {
        case "customers": data = await storage.getCustomers(); break;
        case "invoices": data = await storage.getInvoices(); break;
        case "tickets": data = await storage.getTickets(); break;
        case "transactions": data = await storage.getTransactions(); break;
        case "expenses": data = await storage.getExpenses(); break;
        case "attendance": data = await storage.getAttendanceRecords(); break;
        case "credit-notes": data = await storage.getCreditNotes(); break;
        case "ip-addresses": data = await storage.getIpAddresses(); break;
        case "outages": data = await storage.getOutages(); break;
        case "network-devices": data = await storage.getNetworkDevices(); break;
        case "payments": data = await storage.getPayments(); break;
        default: return res.status(400).json({ message: "Unknown entity" });
      }
      if (data.length === 0) return res.status(200).send("No data");
      const headers = Object.keys(data[0]);
      const csv = [
        headers.join(","),
        ...data.map(row => headers.map(h => {
          const val = (row as any)[h];
          if (val === null || val === undefined) return "";
          const str = String(val);
          return str.includes(",") || str.includes('"') || str.includes("\n") ? `"${str.replace(/"/g, '""')}"` : str;
        }).join(","))
      ].join("\n");
      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", `attachment; filename=${entity}-${new Date().toISOString().split("T")[0]}.csv`);
      res.send(csv);
    } catch (error: any) {
      res.status(500).json({ message: error.message || "Export failed" });
    }
  });

  return httpServer;
}
