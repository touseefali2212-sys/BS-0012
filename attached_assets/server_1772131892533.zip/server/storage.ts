import { eq, desc, sql, and, count } from "drizzle-orm";
import { db } from "./db";
import {
  users, customers, packages, invoices, tickets, activityLogs,
  areas, vendors, resellers, accounts, transactions, tasks,
  assets, inventoryItems, employees, roles, companySettings,
  notifications, reports, settings, customerConnections,
  notificationTemplates, smtpSettings, smsSettings, notificationDispatches, branches,
  vendorWalletTransactions, resellerWalletTransactions, vendorPackages, vendorBandwidthLinks, bandwidthChangeHistory, customerQueries, supportCategories, invoiceItems,
  expenses, attendance, auditLogs, creditNotes, bulkMessages, ipAddresses, outages,
  networkDevices, pppoeUsers, radiusProfiles, paymentGateways, payments, billingRules, bandwidthUsage, dailyCollections, salaryHistory,
  type User, type InsertUser,
  type Customer, type InsertCustomer,
  type Package, type InsertPackage,
  type Invoice, type InsertInvoice,
  type Ticket, type InsertTicket,
  type ActivityLog, type InsertActivityLog,
  type Area, type InsertArea,
  type Vendor, type InsertVendor,
  type Reseller, type InsertReseller,
  type Account, type InsertAccount,
  type Transaction, type InsertTransaction,
  type Task, type InsertTask,
  type Asset, type InsertAsset,
  type InventoryItem, type InsertInventoryItem,
  type Employee, type InsertEmployee,
  type Role, type InsertRole,
  type CompanySettings, type InsertCompanySettings,
  type Notification, type InsertNotification,
  type Report, type InsertReport,
  type Setting, type InsertSetting,
  type CustomerConnection, type InsertCustomerConnection,
  type NotificationTemplate, type InsertNotificationTemplate,
  type SmtpSettings, type InsertSmtpSettings,
  type SmsSettings, type InsertSmsSettings,
  type NotificationDispatch, type InsertNotificationDispatch,
  type Branch, type InsertBranch,
  type VendorWalletTransaction, type InsertVendorWalletTransaction,
  type ResellerWalletTransaction, type InsertResellerWalletTransaction,
  type VendorPackage, type InsertVendorPackage,
  type VendorBandwidthLink, type InsertVendorBandwidthLink,
  type BandwidthChangeHistory, type InsertBandwidthChangeHistory,
  type CustomerQuery, type InsertCustomerQuery,
  type SupportCategory, type InsertSupportCategory,
  type InvoiceItem, type InsertInvoiceItem,
  type Expense, type InsertExpense,
  type Attendance, type InsertAttendance,
  type AuditLog, type InsertAuditLog,
  type CreditNote, type InsertCreditNote,
  type BulkMessage, type InsertBulkMessage,
  type IpAddress, type InsertIpAddress,
  type Outage, type InsertOutage,
  type NetworkDevice, type InsertNetworkDevice,
  type PppoeUser, type InsertPppoeUser,
  type RadiusProfile, type InsertRadiusProfile,
  type PaymentGateway, type InsertPaymentGateway,
  type Payment, type InsertPayment,
  type BillingRule, type InsertBillingRule,
  type BandwidthUsage, type InsertBandwidthUsage,
  type DailyCollection, type InsertDailyCollection,
  type SalaryHistory, type InsertSalaryHistory,
} from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  getCustomers(): Promise<Customer[]>;
  getCustomer(id: number): Promise<Customer | undefined>;
  createCustomer(c: InsertCustomer): Promise<Customer>;
  updateCustomer(id: number, c: Partial<InsertCustomer>): Promise<Customer | undefined>;
  deleteCustomer(id: number): Promise<void>;

  getPackages(): Promise<Package[]>;
  getPackage(id: number): Promise<Package | undefined>;
  createPackage(p: InsertPackage): Promise<Package>;
  updatePackage(id: number, p: Partial<InsertPackage>): Promise<Package | undefined>;
  deletePackage(id: number): Promise<void>;

  getInvoices(): Promise<(Invoice & { customerName?: string; customerCode?: string; customerPhone?: string; customerArea?: string; customerZone?: string; customerType?: string; connectionType?: string; packageName?: string; packageSpeed?: string; customerServer?: string; customerUsernameIp?: string; customerExpireDate?: string; customerMonthlyBill?: string; customerBillingStatus?: string; customerStatus?: string })[]>;
  getInvoice(id: number): Promise<Invoice | undefined>;
  getInvoicesByCustomer(customerId: number): Promise<Invoice[]>;
  createInvoice(i: InsertInvoice): Promise<Invoice>;
  updateInvoice(id: number, i: Partial<InsertInvoice>): Promise<Invoice | undefined>;
  deleteInvoice(id: number): Promise<void>;

  getInvoiceItems(invoiceId: number): Promise<InvoiceItem[]>;
  createInvoiceItem(item: InsertInvoiceItem): Promise<InvoiceItem>;
  updateInvoiceItem(id: number, item: Partial<InsertInvoiceItem>): Promise<InvoiceItem | undefined>;
  deleteInvoiceItem(id: number): Promise<void>;
  deleteInvoiceItemsByInvoiceId(invoiceId: number): Promise<void>;

  getTickets(): Promise<(Ticket & { customerName?: string; customerCode?: string; customerPhone?: string; customerArea?: string })[]>;
  getTicket(id: number): Promise<Ticket | undefined>;
  getTicketsByCustomer(customerId: number): Promise<Ticket[]>;
  createTicket(t: InsertTicket): Promise<Ticket>;
  updateTicket(id: number, t: Partial<InsertTicket>): Promise<Ticket | undefined>;
  deleteTicket(id: number): Promise<void>;

  getAreas(): Promise<Area[]>;
  getArea(id: number): Promise<Area | undefined>;
  createArea(a: InsertArea): Promise<Area>;
  updateArea(id: number, a: Partial<InsertArea>): Promise<Area | undefined>;
  deleteArea(id: number): Promise<void>;

  getVendors(): Promise<Vendor[]>;
  getVendor(id: number): Promise<Vendor | undefined>;
  createVendor(v: InsertVendor): Promise<Vendor>;
  updateVendor(id: number, v: Partial<InsertVendor>): Promise<Vendor | undefined>;
  deleteVendor(id: number): Promise<void>;

  getResellers(): Promise<Reseller[]>;
  getReseller(id: number): Promise<Reseller | undefined>;
  createReseller(r: InsertReseller): Promise<Reseller>;
  updateReseller(id: number, r: Partial<InsertReseller>): Promise<Reseller | undefined>;
  deleteReseller(id: number): Promise<void>;

  getVendorWalletTransactions(vendorId: number): Promise<VendorWalletTransaction[]>;
  getAllVendorWalletTransactions(): Promise<VendorWalletTransaction[]>;
  createVendorWalletTransaction(t: InsertVendorWalletTransaction): Promise<VendorWalletTransaction>;
  updateVendorWalletTransaction(id: number, data: Partial<InsertVendorWalletTransaction>): Promise<VendorWalletTransaction | undefined>;
  updateVendorWalletTransactionWithAmount(id: number, newAmount: number, data: Partial<InsertVendorWalletTransaction>): Promise<VendorWalletTransaction | undefined>;
  rechargeVendorWallet(vendorId: number, amount: number, reference?: string, paymentMethod?: string, performedBy?: string, approvedBy?: string, notes?: string): Promise<Vendor>;
  deductVendorWallet(vendorId: number, amount: number, reference?: string, customerId?: number, resellerId?: number, reason?: string, performedBy?: string, approvedBy?: string, notes?: string): Promise<Vendor>;

  getResellerWalletTransactions(resellerId: number): Promise<ResellerWalletTransaction[]>;
  getAllResellerWalletTransactions(): Promise<ResellerWalletTransaction[]>;
  createResellerWalletTransaction(t: InsertResellerWalletTransaction): Promise<ResellerWalletTransaction>;
  rechargeResellerWallet(resellerId: number, amount: number, reference?: string): Promise<Reseller>;
  deductResellerWallet(resellerId: number, amount: number, vendorId?: number, customerId?: number, reference?: string): Promise<Reseller>;

  getVendorPackages(vendorId?: number): Promise<VendorPackage[]>;
  getVendorPackage(id: number): Promise<VendorPackage | undefined>;
  createVendorPackage(p: InsertVendorPackage): Promise<VendorPackage>;
  updateVendorPackage(id: number, p: Partial<InsertVendorPackage>): Promise<VendorPackage | undefined>;
  deleteVendorPackage(id: number): Promise<void>;

  getVendorBandwidthLinks(vendorId?: number): Promise<VendorBandwidthLink[]>;
  getVendorBandwidthLink(id: number): Promise<VendorBandwidthLink | undefined>;
  createVendorBandwidthLink(l: InsertVendorBandwidthLink): Promise<VendorBandwidthLink>;
  updateVendorBandwidthLink(id: number, l: Partial<InsertVendorBandwidthLink>): Promise<VendorBandwidthLink | undefined>;
  deleteVendorBandwidthLink(id: number): Promise<void>;

  getCustomerQueries(): Promise<CustomerQuery[]>;
  getCustomerQuery(id: number): Promise<CustomerQuery | undefined>;
  createCustomerQuery(q: InsertCustomerQuery): Promise<CustomerQuery>;
  updateCustomerQuery(id: number, q: Partial<InsertCustomerQuery>): Promise<CustomerQuery | undefined>;
  deleteCustomerQuery(id: number): Promise<void>;

  getSupportCategories(): Promise<SupportCategory[]>;
  getSupportCategory(id: number): Promise<SupportCategory | undefined>;
  createSupportCategory(c: InsertSupportCategory): Promise<SupportCategory>;
  updateSupportCategory(id: number, c: Partial<InsertSupportCategory>): Promise<SupportCategory | undefined>;
  deleteSupportCategory(id: number): Promise<void>;

  getAccounts(): Promise<Account[]>;
  getAccount(id: number): Promise<Account | undefined>;
  createAccount(a: InsertAccount): Promise<Account>;
  updateAccount(id: number, a: Partial<InsertAccount>): Promise<Account | undefined>;
  deleteAccount(id: number): Promise<void>;

  getTransactions(): Promise<(Transaction & { customerName?: string; accountName?: string })[]>;
  getTransaction(id: number): Promise<Transaction | undefined>;
  getTransactionsByCustomer(customerId: number): Promise<Transaction[]>;
  createTransaction(t: InsertTransaction): Promise<Transaction>;
  updateTransaction(id: number, t: Partial<InsertTransaction>): Promise<Transaction | undefined>;
  deleteTransaction(id: number): Promise<void>;

  getTasks(): Promise<(Task & { customerName?: string })[]>;
  getTask(id: number): Promise<Task | undefined>;
  createTask(t: InsertTask): Promise<Task>;
  updateTask(id: number, t: Partial<InsertTask>): Promise<Task | undefined>;
  deleteTask(id: number): Promise<void>;

  getAssets(): Promise<Asset[]>;
  getAsset(id: number): Promise<Asset | undefined>;
  createAsset(a: InsertAsset): Promise<Asset>;
  updateAsset(id: number, a: Partial<InsertAsset>): Promise<Asset | undefined>;
  deleteAsset(id: number): Promise<void>;

  getInventoryItems(): Promise<InventoryItem[]>;
  getInventoryItem(id: number): Promise<InventoryItem | undefined>;
  createInventoryItem(i: InsertInventoryItem): Promise<InventoryItem>;
  updateInventoryItem(id: number, i: Partial<InsertInventoryItem>): Promise<InventoryItem | undefined>;
  deleteInventoryItem(id: number): Promise<void>;

  getEmployees(): Promise<Employee[]>;
  getEmployee(id: number): Promise<Employee | undefined>;
  createEmployee(e: InsertEmployee): Promise<Employee>;
  updateEmployee(id: number, e: Partial<InsertEmployee>): Promise<Employee | undefined>;
  deleteEmployee(id: number): Promise<void>;

  getSalaryHistory(employeeId: number): Promise<SalaryHistory[]>;
  getSalaryHistoryEntry(id: number): Promise<SalaryHistory | undefined>;
  createSalaryHistoryEntry(data: InsertSalaryHistory): Promise<SalaryHistory>;
  updateSalaryHistoryEntry(id: number, data: Partial<InsertSalaryHistory>): Promise<SalaryHistory | undefined>;
  deleteSalaryHistoryEntry(id: number): Promise<void>;

  getRoles(): Promise<Role[]>;
  getRole(id: number): Promise<Role | undefined>;
  createRole(r: InsertRole): Promise<Role>;
  updateRole(id: number, r: Partial<InsertRole>): Promise<Role | undefined>;
  deleteRole(id: number): Promise<void>;

  getCompanySettings(): Promise<CompanySettings | undefined>;
  upsertCompanySettings(s: InsertCompanySettings): Promise<CompanySettings>;

  getNotifications(): Promise<Notification[]>;
  getNotification(id: number): Promise<Notification | undefined>;
  createNotification(n: InsertNotification): Promise<Notification>;
  updateNotification(id: number, n: Partial<InsertNotification>): Promise<Notification | undefined>;
  deleteNotification(id: number): Promise<void>;

  getReports(): Promise<Report[]>;
  getReport(id: number): Promise<Report | undefined>;
  createReport(r: InsertReport): Promise<Report>;
  updateReport(id: number, r: Partial<InsertReport>): Promise<Report | undefined>;
  deleteReport(id: number): Promise<void>;

  getSettings(): Promise<Setting[]>;
  getSetting(key: string): Promise<Setting | undefined>;
  upsertSetting(s: InsertSetting): Promise<Setting>;
  updateSetting(id: number, data: Partial<InsertSetting>): Promise<Setting>;
  deleteSetting(id: number): Promise<void>;

  getCustomerConnections(customerId: number): Promise<CustomerConnection[]>;
  createCustomerConnection(c: InsertCustomerConnection): Promise<CustomerConnection>;
  updateCustomerConnection(id: number, c: Partial<InsertCustomerConnection>): Promise<CustomerConnection | undefined>;
  deleteCustomerConnection(id: number): Promise<void>;

  getDashboardStats(): Promise<{
    totalCustomers: number;
    activeCustomers: number;
    totalRevenue: string;
    pendingInvoices: number;
    openTickets: number;
    totalPackages: number;
    overdueAmount: string;
    collectedAmount: string;
  }>;

  createActivityLog(log: InsertActivityLog): Promise<ActivityLog>;
  getActivityLogs(): Promise<ActivityLog[]>;

  getNotificationTemplates(): Promise<NotificationTemplate[]>;
  getNotificationTemplate(id: number): Promise<NotificationTemplate | undefined>;
  createNotificationTemplate(t: InsertNotificationTemplate): Promise<NotificationTemplate>;
  updateNotificationTemplate(id: number, t: Partial<InsertNotificationTemplate>): Promise<NotificationTemplate | undefined>;
  deleteNotificationTemplate(id: number): Promise<void>;

  getSmtpSettings(): Promise<SmtpSettings | undefined>;
  upsertSmtpSettings(s: InsertSmtpSettings): Promise<SmtpSettings>;

  getSmsSettings(): Promise<SmsSettings | undefined>;
  upsertSmsSettings(s: InsertSmsSettings): Promise<SmsSettings>;

  getNotificationDispatches(): Promise<NotificationDispatch[]>;
  createNotificationDispatch(d: InsertNotificationDispatch): Promise<NotificationDispatch>;

  getBranches(): Promise<Branch[]>;
  getBranch(id: number): Promise<Branch | undefined>;
  createBranch(b: InsertBranch): Promise<Branch>;
  updateBranch(id: number, b: Partial<InsertBranch>): Promise<Branch | undefined>;
  deleteBranch(id: number): Promise<void>;

  getExpenses(): Promise<Expense[]>;
  getExpense(id: number): Promise<Expense | undefined>;
  createExpense(e: InsertExpense): Promise<Expense>;
  updateExpense(id: number, e: Partial<InsertExpense>): Promise<Expense | undefined>;
  deleteExpense(id: number): Promise<void>;

  getAttendanceRecords(employeeId?: number): Promise<(Attendance & { employeeName?: string })[]>;
  createAttendance(a: InsertAttendance): Promise<Attendance>;
  updateAttendance(id: number, a: Partial<InsertAttendance>): Promise<Attendance | undefined>;
  deleteAttendance(id: number): Promise<void>;

  getAuditLogs(): Promise<AuditLog[]>;
  createAuditLog(log: InsertAuditLog): Promise<AuditLog>;

  getCreditNotes(): Promise<(CreditNote & { customerName?: string })[]>;
  getCreditNote(id: number): Promise<CreditNote | undefined>;
  createCreditNote(cn: InsertCreditNote): Promise<CreditNote>;
  updateCreditNote(id: number, cn: Partial<InsertCreditNote>): Promise<CreditNote | undefined>;
  deleteCreditNote(id: number): Promise<void>;

  getBulkMessages(): Promise<BulkMessage[]>;
  getBulkMessage(id: number): Promise<BulkMessage | undefined>;
  createBulkMessage(m: InsertBulkMessage): Promise<BulkMessage>;
  updateBulkMessage(id: number, m: Partial<InsertBulkMessage>): Promise<BulkMessage | undefined>;
  deleteBulkMessage(id: number): Promise<void>;

  getIpAddresses(): Promise<(IpAddress & { customerName?: string })[]>;
  getIpAddress(id: number): Promise<IpAddress | undefined>;
  createIpAddress(ip: InsertIpAddress): Promise<IpAddress>;
  updateIpAddress(id: number, ip: Partial<InsertIpAddress>): Promise<IpAddress | undefined>;
  deleteIpAddress(id: number): Promise<void>;

  getOutages(): Promise<Outage[]>;
  getOutage(id: number): Promise<Outage | undefined>;
  createOutage(o: InsertOutage): Promise<Outage>;
  updateOutage(id: number, o: Partial<InsertOutage>): Promise<Outage | undefined>;
  deleteOutage(id: number): Promise<void>;

  getNetworkDevices(): Promise<NetworkDevice[]>;
  getNetworkDevice(id: number): Promise<NetworkDevice | undefined>;
  createNetworkDevice(d: InsertNetworkDevice): Promise<NetworkDevice>;
  updateNetworkDevice(id: number, d: Partial<InsertNetworkDevice>): Promise<NetworkDevice | undefined>;
  deleteNetworkDevice(id: number): Promise<void>;

  getPppoeUsers(): Promise<(PppoeUser & { customerName?: string })[]>;
  getPppoeUser(id: number): Promise<PppoeUser | undefined>;
  createPppoeUser(u: InsertPppoeUser): Promise<PppoeUser>;
  updatePppoeUser(id: number, u: Partial<InsertPppoeUser>): Promise<PppoeUser | undefined>;
  deletePppoeUser(id: number): Promise<void>;

  getRadiusProfiles(): Promise<RadiusProfile[]>;
  getRadiusProfile(id: number): Promise<RadiusProfile | undefined>;
  createRadiusProfile(p: InsertRadiusProfile): Promise<RadiusProfile>;
  updateRadiusProfile(id: number, p: Partial<InsertRadiusProfile>): Promise<RadiusProfile | undefined>;
  deleteRadiusProfile(id: number): Promise<void>;

  getPaymentGateways(): Promise<PaymentGateway[]>;
  getPaymentGateway(id: number): Promise<PaymentGateway | undefined>;
  createPaymentGateway(g: InsertPaymentGateway): Promise<PaymentGateway>;
  updatePaymentGateway(id: number, g: Partial<InsertPaymentGateway>): Promise<PaymentGateway | undefined>;
  deletePaymentGateway(id: number): Promise<void>;

  getPayments(): Promise<(Payment & { customerName?: string })[]>;
  getPayment(id: number): Promise<Payment | undefined>;
  createPayment(p: InsertPayment): Promise<Payment>;
  updatePayment(id: number, p: Partial<InsertPayment>): Promise<Payment | undefined>;
  deletePayment(id: number): Promise<void>;

  getBillingRules(): Promise<BillingRule[]>;
  getBillingRule(id: number): Promise<BillingRule | undefined>;
  createBillingRule(r: InsertBillingRule): Promise<BillingRule>;
  updateBillingRule(id: number, r: Partial<InsertBillingRule>): Promise<BillingRule | undefined>;
  deleteBillingRule(id: number): Promise<void>;

  getBandwidthUsage(): Promise<(BandwidthUsage & { customerName?: string })[]>;
  getBandwidthUsageById(id: number): Promise<BandwidthUsage | undefined>;
  getBandwidthUsageByCustomer(customerId: number): Promise<BandwidthUsage[]>;
  createBandwidthUsage(u: InsertBandwidthUsage): Promise<BandwidthUsage>;
  updateBandwidthUsage(id: number, u: Partial<InsertBandwidthUsage>): Promise<BandwidthUsage | undefined>;
  deleteBandwidthUsage(id: number): Promise<void>;

  getDailyCollections(): Promise<(DailyCollection & { customerName?: string; customerCode?: string; customerPhone?: string; customerUsername?: string; monthlyBill?: string })[]>;
  getDailyCollection(id: number): Promise<DailyCollection | undefined>;
  createDailyCollection(d: InsertDailyCollection): Promise<DailyCollection>;
  updateDailyCollection(id: number, d: Partial<InsertDailyCollection>): Promise<DailyCollection | undefined>;
  deleteDailyCollection(id: number): Promise<void>;

  getUsers(): Promise<User[]>;
  updateUser(id: number, data: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [created] = await db.insert(users).values(user).returning();
    return created;
  }

  async getCustomers(): Promise<Customer[]> {
    return db.select().from(customers).orderBy(desc(customers.id));
  }

  async getCustomer(id: number): Promise<Customer | undefined> {
    const [c] = await db.select().from(customers).where(eq(customers.id, id));
    return c;
  }

  async createCustomer(c: InsertCustomer): Promise<Customer> {
    const [created] = await db.insert(customers).values(c).returning();
    return created;
  }

  async updateCustomer(id: number, data: Partial<InsertCustomer>): Promise<Customer | undefined> {
    const [updated] = await db.update(customers).set(data).where(eq(customers.id, id)).returning();
    return updated;
  }

  async deleteCustomer(id: number): Promise<void> {
    await db.delete(customers).where(eq(customers.id, id));
  }

  async getPackages(): Promise<Package[]> {
    return db.select().from(packages).orderBy(desc(packages.id));
  }

  async getPackage(id: number): Promise<Package | undefined> {
    const [p] = await db.select().from(packages).where(eq(packages.id, id));
    return p;
  }

  async createPackage(p: InsertPackage): Promise<Package> {
    const [created] = await db.insert(packages).values(p).returning();
    return created;
  }

  async updatePackage(id: number, data: Partial<InsertPackage>): Promise<Package | undefined> {
    const [updated] = await db.update(packages).set(data).where(eq(packages.id, id)).returning();
    return updated;
  }

  async deletePackage(id: number): Promise<void> {
    await db.delete(packages).where(eq(packages.id, id));
  }

  async getInvoices(): Promise<(Invoice & { customerName?: string; customerCode?: string; customerPhone?: string; customerArea?: string; customerZone?: string; customerType?: string; connectionType?: string; packageName?: string; packageSpeed?: string; customerServer?: string; customerUsernameIp?: string; customerExpireDate?: string; customerMonthlyBill?: string; customerBillingStatus?: string; customerStatus?: string })[]> {
    const result = await db
      .select({
        id: invoices.id,
        invoiceNumber: invoices.invoiceNumber,
        customerId: invoices.customerId,
        amount: invoices.amount,
        tax: invoices.tax,
        totalAmount: invoices.totalAmount,
        status: invoices.status,
        dueDate: invoices.dueDate,
        issueDate: invoices.issueDate,
        paidDate: invoices.paidDate,
        description: invoices.description,
        isRecurring: invoices.isRecurring,
        serviceType: invoices.serviceType,
        customerName: customers.fullName,
        customerCode: customers.customerId,
        customerPhone: customers.phone,
        customerArea: customers.area,
        customerZone: customers.zone,
        customerType: customers.customerType,
        connectionType: customers.connectionType,
        packageName: packages.name,
        packageSpeed: packages.speed,
        customerServer: customers.server,
        customerUsernameIp: customers.usernameIp,
        customerExpireDate: customers.expireDate,
        customerMonthlyBill: customers.monthlyBill,
        customerBillingStatus: customers.billingStatus,
        customerStatus: customers.status,
      })
      .from(invoices)
      .leftJoin(customers, eq(invoices.customerId, customers.id))
      .leftJoin(packages, eq(customers.packageId, packages.id))
      .orderBy(desc(invoices.id));
    return result.map(r => ({
      ...r,
      customerName: r.customerName || undefined,
      customerCode: r.customerCode || undefined,
      customerPhone: r.customerPhone || undefined,
      customerArea: r.customerArea || undefined,
      customerZone: r.customerZone || undefined,
      customerType: r.customerType || undefined,
      connectionType: r.connectionType || undefined,
      packageName: r.packageName || undefined,
      packageSpeed: r.packageSpeed || undefined,
      customerServer: r.customerServer || undefined,
      customerUsernameIp: r.customerUsernameIp || undefined,
      customerExpireDate: r.customerExpireDate || undefined,
      customerMonthlyBill: r.customerMonthlyBill || undefined,
      customerBillingStatus: r.customerBillingStatus || undefined,
      customerStatus: r.customerStatus || undefined,
    }));
  }

  async getInvoice(id: number): Promise<Invoice | undefined> {
    const [inv] = await db.select().from(invoices).where(eq(invoices.id, id));
    return inv;
  }

  async getInvoicesByCustomer(customerId: number): Promise<Invoice[]> {
    return db.select().from(invoices).where(eq(invoices.customerId, customerId)).orderBy(desc(invoices.id));
  }

  async createInvoice(i: InsertInvoice): Promise<Invoice> {
    const [created] = await db.insert(invoices).values(i).returning();
    return created;
  }

  async updateInvoice(id: number, data: Partial<InsertInvoice>): Promise<Invoice | undefined> {
    const [updated] = await db.update(invoices).set(data).where(eq(invoices.id, id)).returning();
    return updated;
  }

  async deleteInvoice(id: number): Promise<void> {
    await db.delete(invoiceItems).where(eq(invoiceItems.invoiceId, id));
    await db.delete(invoices).where(eq(invoices.id, id));
  }

  async getInvoiceItems(invoiceId: number): Promise<InvoiceItem[]> {
    return db.select().from(invoiceItems).where(eq(invoiceItems.invoiceId, invoiceId)).orderBy(invoiceItems.sortOrder);
  }

  async createInvoiceItem(item: InsertInvoiceItem): Promise<InvoiceItem> {
    const [created] = await db.insert(invoiceItems).values(item).returning();
    return created;
  }

  async updateInvoiceItem(id: number, data: Partial<InsertInvoiceItem>): Promise<InvoiceItem | undefined> {
    const [updated] = await db.update(invoiceItems).set(data).where(eq(invoiceItems.id, id)).returning();
    return updated;
  }

  async deleteInvoiceItem(id: number): Promise<void> {
    await db.delete(invoiceItems).where(eq(invoiceItems.id, id));
  }

  async deleteInvoiceItemsByInvoiceId(invoiceId: number): Promise<void> {
    await db.delete(invoiceItems).where(eq(invoiceItems.invoiceId, invoiceId));
  }

  async getTickets(): Promise<(Ticket & { customerName?: string; customerCode?: string; customerPhone?: string; customerArea?: string })[]> {
    const result = await db
      .select({
        id: tickets.id,
        ticketNumber: tickets.ticketNumber,
        customerId: tickets.customerId,
        subject: tickets.subject,
        description: tickets.description,
        priority: tickets.priority,
        status: tickets.status,
        category: tickets.category,
        assignedTo: tickets.assignedTo,
        createdAt: tickets.createdAt,
        resolvedAt: tickets.resolvedAt,
        customerName: customers.fullName,
        customerCode: customers.customerId,
        customerPhone: customers.phone,
        customerArea: customers.area,
      })
      .from(tickets)
      .leftJoin(customers, eq(tickets.customerId, customers.id))
      .orderBy(desc(tickets.id));
    return result.map(r => ({
      ...r,
      customerName: r.customerName || undefined,
      customerCode: r.customerCode || undefined,
      customerPhone: r.customerPhone || undefined,
      customerArea: r.customerArea || undefined,
    }));
  }

  async getTicket(id: number): Promise<Ticket | undefined> {
    const [t] = await db.select().from(tickets).where(eq(tickets.id, id));
    return t;
  }

  async getTicketsByCustomer(customerId: number): Promise<Ticket[]> {
    return db.select().from(tickets).where(eq(tickets.customerId, customerId)).orderBy(desc(tickets.id));
  }

  async createTicket(t: InsertTicket): Promise<Ticket> {
    const [created] = await db.insert(tickets).values(t).returning();
    return created;
  }

  async updateTicket(id: number, data: Partial<InsertTicket>): Promise<Ticket | undefined> {
    const [updated] = await db.update(tickets).set(data).where(eq(tickets.id, id)).returning();
    return updated;
  }

  async deleteTicket(id: number): Promise<void> {
    await db.delete(tickets).where(eq(tickets.id, id));
  }

  async getAreas(): Promise<Area[]> {
    return db.select().from(areas).orderBy(desc(areas.id));
  }

  async getArea(id: number): Promise<Area | undefined> {
    const [a] = await db.select().from(areas).where(eq(areas.id, id));
    return a;
  }

  async createArea(a: InsertArea): Promise<Area> {
    const [created] = await db.insert(areas).values(a).returning();
    return created;
  }

  async updateArea(id: number, data: Partial<InsertArea>): Promise<Area | undefined> {
    const [updated] = await db.update(areas).set(data).where(eq(areas.id, id)).returning();
    return updated;
  }

  async deleteArea(id: number): Promise<void> {
    await db.delete(areas).where(eq(areas.id, id));
  }

  async getVendors(): Promise<Vendor[]> {
    return db.select().from(vendors).orderBy(desc(vendors.id));
  }

  async getVendor(id: number): Promise<Vendor | undefined> {
    const [v] = await db.select().from(vendors).where(eq(vendors.id, id));
    return v;
  }

  async createVendor(v: InsertVendor): Promise<Vendor> {
    const [created] = await db.insert(vendors).values(v).returning();
    return created;
  }

  async updateVendor(id: number, data: Partial<InsertVendor>): Promise<Vendor | undefined> {
    const [updated] = await db.update(vendors).set(data).where(eq(vendors.id, id)).returning();
    return updated;
  }

  async deleteVendor(id: number): Promise<void> {
    await db.delete(vendors).where(eq(vendors.id, id));
  }

  async getResellers(): Promise<Reseller[]> {
    return db.select().from(resellers).orderBy(desc(resellers.id));
  }

  async getReseller(id: number): Promise<Reseller | undefined> {
    const [r] = await db.select().from(resellers).where(eq(resellers.id, id));
    return r;
  }

  async createReseller(r: InsertReseller): Promise<Reseller> {
    const [created] = await db.insert(resellers).values(r).returning();
    return created;
  }

  async updateReseller(id: number, data: Partial<InsertReseller>): Promise<Reseller | undefined> {
    const [updated] = await db.update(resellers).set(data).where(eq(resellers.id, id)).returning();
    return updated;
  }

  async deleteReseller(id: number): Promise<void> {
    await db.delete(resellers).where(eq(resellers.id, id));
  }

  async getVendorWalletTransactions(vendorId: number): Promise<VendorWalletTransaction[]> {
    return db.select().from(vendorWalletTransactions).where(eq(vendorWalletTransactions.vendorId, vendorId)).orderBy(desc(vendorWalletTransactions.id));
  }

  async getAllVendorWalletTransactions(): Promise<VendorWalletTransaction[]> {
    return db.select().from(vendorWalletTransactions).orderBy(desc(vendorWalletTransactions.id));
  }

  async createVendorWalletTransaction(t: InsertVendorWalletTransaction): Promise<VendorWalletTransaction> {
    const [created] = await db.insert(vendorWalletTransactions).values(t).returning();
    return created;
  }

  async updateVendorWalletTransaction(id: number, data: Partial<InsertVendorWalletTransaction>): Promise<VendorWalletTransaction | undefined> {
    const [updated] = await db.update(vendorWalletTransactions).set(data).where(eq(vendorWalletTransactions.id, id)).returning();
    return updated;
  }

  async updateVendorWalletTransactionWithAmount(id: number, newAmount: number, data: Partial<InsertVendorWalletTransaction>): Promise<VendorWalletTransaction | undefined> {
    const existing = await db.select().from(vendorWalletTransactions).where(eq(vendorWalletTransactions.id, id));
    if (!existing.length) return undefined;
    const txn = existing[0];
    const oldAmount = parseFloat(txn.amount);
    const amountDiff = newAmount - oldAmount;
    const isCredit = txn.type === "credit" || txn.type === "recharge";
    const newBalanceAfter = parseFloat(txn.balanceAfter) + amountDiff;
    const [updated] = await db.update(vendorWalletTransactions).set({ ...data, amount: newAmount.toString(), balanceAfter: newBalanceAfter.toString() }).where(eq(vendorWalletTransactions.id, id)).returning();
    const vendor = await this.getVendor(txn.vendorId);
    if (vendor) {
      const currentBalance = parseFloat(vendor.walletBalance || "0");
      const adjustedBalance = isCredit ? currentBalance + amountDiff : currentBalance - amountDiff;
      await db.update(vendors).set({ walletBalance: adjustedBalance.toString() }).where(eq(vendors.id, txn.vendorId));
    }
    return updated;
  }

  async rechargeVendorWallet(vendorId: number, amount: number, reference?: string, paymentMethod?: string, performedBy?: string, approvedBy?: string, notes?: string): Promise<Vendor> {
    const vendor = await this.getVendor(vendorId);
    if (!vendor) throw new Error("Vendor not found");
    const currentBalance = parseFloat(vendor.walletBalance || "0");
    const newBalance = currentBalance + amount;
    const now = new Date().toISOString();
    await this.createVendorWalletTransaction({
      vendorId,
      type: "credit",
      amount: amount.toString(),
      balanceAfter: newBalance.toString(),
      reference: reference || `Recharge-${Date.now()}`,
      description: `Wallet recharge of ${amount}`,
      paymentMethod: paymentMethod || null,
      performedBy: performedBy || null,
      approvedBy: approvedBy || null,
      notes: notes || null,
      createdAt: now,
    });
    const [updated] = await db.update(vendors).set({ walletBalance: newBalance.toString(), lastRechargeDate: now }).where(eq(vendors.id, vendorId)).returning();
    return updated;
  }

  async deductVendorWallet(vendorId: number, amount: number, reference?: string, customerId?: number, resellerId?: number, reason?: string, performedBy?: string, approvedBy?: string, notes?: string): Promise<Vendor> {
    const vendor = await this.getVendor(vendorId);
    if (!vendor) throw new Error("Vendor not found");
    const currentBalance = parseFloat(vendor.walletBalance || "0");
    if (currentBalance < amount) throw new Error("Insufficient vendor wallet balance");
    const newBalance = currentBalance - amount;
    const now = new Date().toISOString();
    await this.createVendorWalletTransaction({
      vendorId,
      type: "debit",
      amount: amount.toString(),
      balanceAfter: newBalance.toString(),
      reference: reference || `Deduction-${Date.now()}`,
      description: `Wallet deduction of ${amount}`,
      reason: reason || null,
      performedBy: performedBy || null,
      approvedBy: approvedBy || null,
      notes: notes || null,
      customerId,
      resellerId,
      createdAt: now,
    });
    const [updated] = await db.update(vendors).set({ walletBalance: newBalance.toString() }).where(eq(vendors.id, vendorId)).returning();
    return updated;
  }

  async getResellerWalletTransactions(resellerId: number): Promise<ResellerWalletTransaction[]> {
    return db.select().from(resellerWalletTransactions).where(eq(resellerWalletTransactions.resellerId, resellerId)).orderBy(desc(resellerWalletTransactions.id));
  }

  async getAllResellerWalletTransactions(): Promise<ResellerWalletTransaction[]> {
    return db.select().from(resellerWalletTransactions).orderBy(desc(resellerWalletTransactions.id));
  }

  async createResellerWalletTransaction(t: InsertResellerWalletTransaction): Promise<ResellerWalletTransaction> {
    const [created] = await db.insert(resellerWalletTransactions).values(t).returning();
    return created;
  }

  async rechargeResellerWallet(resellerId: number, amount: number, reference?: string): Promise<Reseller> {
    const reseller = await this.getReseller(resellerId);
    if (!reseller) throw new Error("Reseller not found");
    const currentBalance = parseFloat(reseller.walletBalance || "0");
    const newBalance = currentBalance + amount;
    const now = new Date().toISOString();
    await this.createResellerWalletTransaction({
      resellerId,
      type: "credit",
      amount: amount.toString(),
      balanceAfter: newBalance.toString(),
      reference: reference || `Recharge-${Date.now()}`,
      description: `Wallet recharge of ${amount}`,
      createdAt: now,
    });
    const [updated] = await db.update(resellers).set({ walletBalance: newBalance.toString() }).where(eq(resellers.id, resellerId)).returning();
    return updated;
  }

  async deductResellerWallet(resellerId: number, amount: number, vendorId?: number, customerId?: number, reference?: string): Promise<Reseller> {
    const reseller = await this.getReseller(resellerId);
    if (!reseller) throw new Error("Reseller not found");
    const currentBalance = parseFloat(reseller.walletBalance || "0");
    if (currentBalance < amount) throw new Error("Insufficient reseller wallet balance");
    const newBalance = currentBalance - amount;
    const now = new Date().toISOString();
    await this.createResellerWalletTransaction({
      resellerId,
      type: "debit",
      amount: amount.toString(),
      balanceAfter: newBalance.toString(),
      reference: reference || `Deduction-${Date.now()}`,
      description: `Wallet deduction of ${amount}`,
      vendorId,
      customerId,
      createdAt: now,
    });
    const [updated] = await db.update(resellers).set({ walletBalance: newBalance.toString() }).where(eq(resellers.id, resellerId)).returning();
    return updated;
  }

  async getVendorPackages(vendorId?: number): Promise<VendorPackage[]> {
    if (vendorId) {
      return db.select().from(vendorPackages).where(eq(vendorPackages.vendorId, vendorId)).orderBy(desc(vendorPackages.id));
    }
    return db.select().from(vendorPackages).orderBy(desc(vendorPackages.id));
  }

  async getVendorPackage(id: number): Promise<VendorPackage | undefined> {
    const [p] = await db.select().from(vendorPackages).where(eq(vendorPackages.id, id));
    return p;
  }

  async createVendorPackage(p: InsertVendorPackage): Promise<VendorPackage> {
    const ispMargin = (parseFloat(p.ispSellingPrice) - parseFloat(p.vendorPrice)).toString();
    const resellerMargin = p.resellerPrice ? (parseFloat(p.resellerPrice) - parseFloat(p.vendorPrice)).toString() : null;
    const [created] = await db.insert(vendorPackages).values({ ...p, ispMargin, resellerMargin }).returning();
    return created;
  }

  async updateVendorPackage(id: number, data: Partial<InsertVendorPackage>): Promise<VendorPackage | undefined> {
    const updates: any = { ...data };
    if (data.vendorPrice && data.ispSellingPrice) {
      updates.ispMargin = (parseFloat(data.ispSellingPrice) - parseFloat(data.vendorPrice)).toString();
    }
    if (data.vendorPrice && data.resellerPrice) {
      updates.resellerMargin = (parseFloat(data.resellerPrice) - parseFloat(data.vendorPrice)).toString();
    }
    const [updated] = await db.update(vendorPackages).set(updates).where(eq(vendorPackages.id, id)).returning();
    return updated;
  }

  async deleteVendorPackage(id: number): Promise<void> {
    await db.delete(vendorPackages).where(eq(vendorPackages.id, id));
  }

  async getVendorBandwidthLinks(vendorId?: number): Promise<VendorBandwidthLink[]> {
    if (vendorId) {
      return db.select().from(vendorBandwidthLinks).where(eq(vendorBandwidthLinks.vendorId, vendorId)).orderBy(desc(vendorBandwidthLinks.id));
    }
    return db.select().from(vendorBandwidthLinks).orderBy(desc(vendorBandwidthLinks.id));
  }

  async getVendorBandwidthLink(id: number): Promise<VendorBandwidthLink | undefined> {
    const [link] = await db.select().from(vendorBandwidthLinks).where(eq(vendorBandwidthLinks.id, id));
    return link;
  }

  async createVendorBandwidthLink(l: InsertVendorBandwidthLink): Promise<VendorBandwidthLink> {
    const [created] = await db.insert(vendorBandwidthLinks).values(l).returning();
    return created;
  }

  async updateVendorBandwidthLink(id: number, data: Partial<InsertVendorBandwidthLink>): Promise<VendorBandwidthLink | undefined> {
    const [updated] = await db.update(vendorBandwidthLinks).set(data).where(eq(vendorBandwidthLinks.id, id)).returning();
    return updated;
  }

  async deleteVendorBandwidthLink(id: number): Promise<void> {
    await db.delete(vendorBandwidthLinks).where(eq(vendorBandwidthLinks.id, id));
  }

  async getBandwidthChangeHistory(vendorId?: number): Promise<BandwidthChangeHistory[]> {
    if (vendorId) {
      return db.select().from(bandwidthChangeHistory).where(eq(bandwidthChangeHistory.vendorId, vendorId)).orderBy(desc(bandwidthChangeHistory.id));
    }
    return db.select().from(bandwidthChangeHistory).orderBy(desc(bandwidthChangeHistory.id));
  }

  async getBandwidthChangeHistoryByLink(linkId: number): Promise<BandwidthChangeHistory[]> {
    return db.select().from(bandwidthChangeHistory).where(eq(bandwidthChangeHistory.linkId, linkId)).orderBy(desc(bandwidthChangeHistory.id));
  }

  async getBandwidthChange(id: number): Promise<BandwidthChangeHistory | undefined> {
    const [record] = await db.select().from(bandwidthChangeHistory).where(eq(bandwidthChangeHistory.id, id));
    return record;
  }

  async createBandwidthChange(data: InsertBandwidthChangeHistory): Promise<BandwidthChangeHistory> {
    const [created] = await db.insert(bandwidthChangeHistory).values(data).returning();
    return created;
  }

  async updateBandwidthChange(id: number, data: Partial<InsertBandwidthChangeHistory>): Promise<BandwidthChangeHistory | undefined> {
    const [updated] = await db.update(bandwidthChangeHistory).set(data).where(eq(bandwidthChangeHistory.id, id)).returning();
    return updated;
  }

  async deleteBandwidthChange(id: number): Promise<void> {
    await db.delete(bandwidthChangeHistory).where(eq(bandwidthChangeHistory.id, id));
  }

  async getAccounts(): Promise<Account[]> {
    return db.select().from(accounts).orderBy(accounts.code);
  }

  async getAccount(id: number): Promise<Account | undefined> {
    const [a] = await db.select().from(accounts).where(eq(accounts.id, id));
    return a;
  }

  async createAccount(a: InsertAccount): Promise<Account> {
    const [created] = await db.insert(accounts).values(a).returning();
    return created;
  }

  async updateAccount(id: number, data: Partial<InsertAccount>): Promise<Account | undefined> {
    const [updated] = await db.update(accounts).set(data).where(eq(accounts.id, id)).returning();
    return updated;
  }

  async deleteAccount(id: number): Promise<void> {
    await db.delete(accounts).where(eq(accounts.id, id));
  }

  async getTransactions(): Promise<(Transaction & { customerName?: string; accountName?: string })[]> {
    const result = await db
      .select({
        id: transactions.id,
        txnId: transactions.txnId,
        type: transactions.type,
        amount: transactions.amount,
        accountId: transactions.accountId,
        customerId: transactions.customerId,
        invoiceId: transactions.invoiceId,
        paymentMethod: transactions.paymentMethod,
        reference: transactions.reference,
        description: transactions.description,
        date: transactions.date,
        status: transactions.status,
        customerName: customers.fullName,
        accountName: accounts.name,
      })
      .from(transactions)
      .leftJoin(customers, eq(transactions.customerId, customers.id))
      .leftJoin(accounts, eq(transactions.accountId, accounts.id))
      .orderBy(desc(transactions.id));
    return result.map(r => ({ ...r, customerName: r.customerName || undefined, accountName: r.accountName || undefined }));
  }

  async getTransaction(id: number): Promise<Transaction | undefined> {
    const [t] = await db.select().from(transactions).where(eq(transactions.id, id));
    return t;
  }

  async getTransactionsByCustomer(customerId: number): Promise<Transaction[]> {
    return db.select().from(transactions).where(eq(transactions.customerId, customerId)).orderBy(desc(transactions.id));
  }

  async createTransaction(t: InsertTransaction): Promise<Transaction> {
    const [created] = await db.insert(transactions).values(t).returning();
    return created;
  }

  async updateTransaction(id: number, data: Partial<InsertTransaction>): Promise<Transaction | undefined> {
    const [updated] = await db.update(transactions).set(data).where(eq(transactions.id, id)).returning();
    return updated;
  }

  async deleteTransaction(id: number): Promise<void> {
    await db.delete(transactions).where(eq(transactions.id, id));
  }

  async getTasks(): Promise<(Task & { customerName?: string })[]> {
    const result = await db
      .select({
        id: tasks.id,
        title: tasks.title,
        type: tasks.type,
        description: tasks.description,
        priority: tasks.priority,
        status: tasks.status,
        assignedTo: tasks.assignedTo,
        customerId: tasks.customerId,
        dueDate: tasks.dueDate,
        completedDate: tasks.completedDate,
        notes: tasks.notes,
        customerName: customers.fullName,
      })
      .from(tasks)
      .leftJoin(customers, eq(tasks.customerId, customers.id))
      .orderBy(desc(tasks.id));
    return result.map(r => ({ ...r, customerName: r.customerName || undefined }));
  }

  async getTask(id: number): Promise<Task | undefined> {
    const [t] = await db.select().from(tasks).where(eq(tasks.id, id));
    return t;
  }

  async createTask(t: InsertTask): Promise<Task> {
    const [created] = await db.insert(tasks).values(t).returning();
    return created;
  }

  async updateTask(id: number, data: Partial<InsertTask>): Promise<Task | undefined> {
    const [updated] = await db.update(tasks).set(data).where(eq(tasks.id, id)).returning();
    return updated;
  }

  async deleteTask(id: number): Promise<void> {
    await db.delete(tasks).where(eq(tasks.id, id));
  }

  async getAssets(): Promise<Asset[]> {
    return db.select().from(assets).orderBy(desc(assets.id));
  }

  async getAsset(id: number): Promise<Asset | undefined> {
    const [a] = await db.select().from(assets).where(eq(assets.id, id));
    return a;
  }

  async createAsset(a: InsertAsset): Promise<Asset> {
    const [created] = await db.insert(assets).values(a).returning();
    return created;
  }

  async updateAsset(id: number, data: Partial<InsertAsset>): Promise<Asset | undefined> {
    const [updated] = await db.update(assets).set(data).where(eq(assets.id, id)).returning();
    return updated;
  }

  async deleteAsset(id: number): Promise<void> {
    await db.delete(assets).where(eq(assets.id, id));
  }

  async getInventoryItems(): Promise<InventoryItem[]> {
    return db.select().from(inventoryItems).orderBy(desc(inventoryItems.id));
  }

  async getInventoryItem(id: number): Promise<InventoryItem | undefined> {
    const [i] = await db.select().from(inventoryItems).where(eq(inventoryItems.id, id));
    return i;
  }

  async createInventoryItem(i: InsertInventoryItem): Promise<InventoryItem> {
    const [created] = await db.insert(inventoryItems).values(i).returning();
    return created;
  }

  async updateInventoryItem(id: number, data: Partial<InsertInventoryItem>): Promise<InventoryItem | undefined> {
    const [updated] = await db.update(inventoryItems).set(data).where(eq(inventoryItems.id, id)).returning();
    return updated;
  }

  async deleteInventoryItem(id: number): Promise<void> {
    await db.delete(inventoryItems).where(eq(inventoryItems.id, id));
  }

  async getEmployees(): Promise<Employee[]> {
    return db.select().from(employees).orderBy(desc(employees.id));
  }

  async getEmployee(id: number): Promise<Employee | undefined> {
    const [e] = await db.select().from(employees).where(eq(employees.id, id));
    return e;
  }

  async createEmployee(e: InsertEmployee): Promise<Employee> {
    const [created] = await db.insert(employees).values(e).returning();
    return created;
  }

  async updateEmployee(id: number, data: Partial<InsertEmployee>): Promise<Employee | undefined> {
    const [updated] = await db.update(employees).set(data).where(eq(employees.id, id)).returning();
    return updated;
  }

  async deleteEmployee(id: number): Promise<void> {
    await db.delete(employees).where(eq(employees.id, id));
  }

  async getSalaryHistory(employeeId: number): Promise<SalaryHistory[]> {
    return db.select().from(salaryHistory).where(eq(salaryHistory.employeeId, employeeId)).orderBy(desc(salaryHistory.id));
  }

  async getSalaryHistoryEntry(id: number): Promise<SalaryHistory | undefined> {
    const [entry] = await db.select().from(salaryHistory).where(eq(salaryHistory.id, id));
    return entry;
  }

  async createSalaryHistoryEntry(data: InsertSalaryHistory): Promise<SalaryHistory> {
    const [entry] = await db.insert(salaryHistory).values(data).returning();
    return entry;
  }

  async updateSalaryHistoryEntry(id: number, data: Partial<InsertSalaryHistory>): Promise<SalaryHistory | undefined> {
    const [updated] = await db.update(salaryHistory).set(data).where(eq(salaryHistory.id, id)).returning();
    return updated;
  }

  async deleteSalaryHistoryEntry(id: number): Promise<void> {
    await db.delete(salaryHistory).where(eq(salaryHistory.id, id));
  }

  async getRoles(): Promise<Role[]> {
    return db.select().from(roles).orderBy(roles.name);
  }

  async getRole(id: number): Promise<Role | undefined> {
    const [r] = await db.select().from(roles).where(eq(roles.id, id));
    return r;
  }

  async createRole(r: InsertRole): Promise<Role> {
    const [created] = await db.insert(roles).values(r).returning();
    return created;
  }

  async updateRole(id: number, data: Partial<InsertRole>): Promise<Role | undefined> {
    const [updated] = await db.update(roles).set(data).where(eq(roles.id, id)).returning();
    return updated;
  }

  async deleteRole(id: number): Promise<void> {
    await db.delete(roles).where(eq(roles.id, id));
  }

  async getCompanySettings(): Promise<CompanySettings | undefined> {
    const [s] = await db.select().from(companySettings).limit(1);
    return s;
  }

  async upsertCompanySettings(s: InsertCompanySettings): Promise<CompanySettings> {
    const existing = await this.getCompanySettings();
    if (existing) {
      const [updated] = await db.update(companySettings).set(s).where(eq(companySettings.id, existing.id)).returning();
      return updated;
    }
    const [created] = await db.insert(companySettings).values(s).returning();
    return created;
  }

  async getNotifications(): Promise<Notification[]> {
    return db.select().from(notifications).orderBy(desc(notifications.id));
  }

  async getNotification(id: number): Promise<Notification | undefined> {
    const [n] = await db.select().from(notifications).where(eq(notifications.id, id));
    return n;
  }

  async createNotification(n: InsertNotification): Promise<Notification> {
    const [created] = await db.insert(notifications).values(n).returning();
    return created;
  }

  async updateNotification(id: number, data: Partial<InsertNotification>): Promise<Notification | undefined> {
    const [updated] = await db.update(notifications).set(data).where(eq(notifications.id, id)).returning();
    return updated;
  }

  async deleteNotification(id: number): Promise<void> {
    await db.delete(notifications).where(eq(notifications.id, id));
  }

  async getReports(): Promise<Report[]> {
    return db.select().from(reports).orderBy(desc(reports.id));
  }

  async getReport(id: number): Promise<Report | undefined> {
    const [r] = await db.select().from(reports).where(eq(reports.id, id));
    return r;
  }

  async createReport(r: InsertReport): Promise<Report> {
    const [created] = await db.insert(reports).values(r).returning();
    return created;
  }

  async updateReport(id: number, data: Partial<InsertReport>): Promise<Report | undefined> {
    const [updated] = await db.update(reports).set(data).where(eq(reports.id, id)).returning();
    return updated;
  }

  async deleteReport(id: number): Promise<void> {
    await db.delete(reports).where(eq(reports.id, id));
  }

  async getSettings(): Promise<Setting[]> {
    return db.select().from(settings).orderBy(settings.category, settings.key);
  }

  async getSetting(key: string): Promise<Setting | undefined> {
    const [s] = await db.select().from(settings).where(eq(settings.key, key));
    return s;
  }

  async upsertSetting(s: InsertSetting): Promise<Setting> {
    const existing = await this.getSetting(s.key);
    if (existing) {
      const [updated] = await db.update(settings).set(s).where(eq(settings.id, existing.id)).returning();
      return updated;
    }
    const [created] = await db.insert(settings).values(s).returning();
    return created;
  }

  async updateSetting(id: number, data: Partial<InsertSetting>): Promise<Setting> {
    const [updated] = await db.update(settings).set(data).where(eq(settings.id, id)).returning();
    return updated;
  }

  async deleteSetting(id: number): Promise<void> {
    await db.delete(settings).where(eq(settings.id, id));
  }

  async getCustomerConnections(customerId: number): Promise<CustomerConnection[]> {
    return db.select().from(customerConnections).where(eq(customerConnections.customerId, customerId));
  }

  async createCustomerConnection(c: InsertCustomerConnection): Promise<CustomerConnection> {
    const [created] = await db.insert(customerConnections).values(c).returning();
    return created;
  }

  async updateCustomerConnection(id: number, data: Partial<InsertCustomerConnection>): Promise<CustomerConnection | undefined> {
    const [updated] = await db.update(customerConnections).set(data).where(eq(customerConnections.id, id)).returning();
    return updated;
  }

  async deleteCustomerConnection(id: number): Promise<void> {
    await db.delete(customerConnections).where(eq(customerConnections.id, id));
  }

  async getDashboardStats() {
    const [customerStats] = await db
      .select({
        total: count(),
        active: sql<number>`count(*) filter (where ${customers.status} = 'active')`,
      })
      .from(customers);

    const [invoiceStats] = await db
      .select({
        totalRevenue: sql<string>`coalesce(sum(${invoices.totalAmount}::numeric), 0)::text`,
        pending: sql<number>`count(*) filter (where ${invoices.status} = 'pending')`,
        overdueAmount: sql<string>`coalesce(sum(case when ${invoices.status} = 'overdue' then ${invoices.totalAmount}::numeric else 0 end), 0)::text`,
        collectedAmount: sql<string>`coalesce(sum(case when ${invoices.status} = 'paid' then ${invoices.totalAmount}::numeric else 0 end), 0)::text`,
      })
      .from(invoices);

    const [ticketStats] = await db
      .select({
        open: sql<number>`count(*) filter (where ${tickets.status} in ('open', 'in_progress'))`,
      })
      .from(tickets);

    const [pkgStats] = await db.select({ total: count() }).from(packages);

    return {
      totalCustomers: customerStats.total,
      activeCustomers: Number(customerStats.active),
      totalRevenue: invoiceStats.totalRevenue,
      pendingInvoices: Number(invoiceStats.pending),
      openTickets: Number(ticketStats.open),
      totalPackages: pkgStats.total,
      overdueAmount: invoiceStats.overdueAmount,
      collectedAmount: invoiceStats.collectedAmount,
    };
  }

  async createActivityLog(log: InsertActivityLog): Promise<ActivityLog> {
    const [created] = await db.insert(activityLogs).values(log).returning();
    return created;
  }

  async getActivityLogs(): Promise<ActivityLog[]> {
    return db.select().from(activityLogs).orderBy(desc(activityLogs.id));
  }

  async getNotificationTemplates(): Promise<NotificationTemplate[]> {
    return db.select().from(notificationTemplates).orderBy(desc(notificationTemplates.id));
  }

  async getNotificationTemplate(id: number): Promise<NotificationTemplate | undefined> {
    const [t] = await db.select().from(notificationTemplates).where(eq(notificationTemplates.id, id));
    return t;
  }

  async createNotificationTemplate(t: InsertNotificationTemplate): Promise<NotificationTemplate> {
    const [created] = await db.insert(notificationTemplates).values(t).returning();
    return created;
  }

  async updateNotificationTemplate(id: number, data: Partial<InsertNotificationTemplate>): Promise<NotificationTemplate | undefined> {
    const [updated] = await db.update(notificationTemplates).set(data).where(eq(notificationTemplates.id, id)).returning();
    return updated;
  }

  async deleteNotificationTemplate(id: number): Promise<void> {
    await db.delete(notificationTemplates).where(eq(notificationTemplates.id, id));
  }

  async getSmtpSettings(): Promise<SmtpSettings | undefined> {
    const [s] = await db.select().from(smtpSettings).limit(1);
    return s;
  }

  async upsertSmtpSettings(s: InsertSmtpSettings): Promise<SmtpSettings> {
    const existing = await this.getSmtpSettings();
    if (existing) {
      const [updated] = await db.update(smtpSettings).set(s).where(eq(smtpSettings.id, existing.id)).returning();
      return updated;
    }
    const [created] = await db.insert(smtpSettings).values(s).returning();
    return created;
  }

  async getSmsSettings(): Promise<SmsSettings | undefined> {
    const [s] = await db.select().from(smsSettings).limit(1);
    return s;
  }

  async upsertSmsSettings(s: InsertSmsSettings): Promise<SmsSettings> {
    const existing = await this.getSmsSettings();
    if (existing) {
      const [updated] = await db.update(smsSettings).set(s).where(eq(smsSettings.id, existing.id)).returning();
      return updated;
    }
    const [created] = await db.insert(smsSettings).values(s).returning();
    return created;
  }

  async getNotificationDispatches(): Promise<NotificationDispatch[]> {
    return db.select().from(notificationDispatches).orderBy(desc(notificationDispatches.id));
  }

  async createNotificationDispatch(d: InsertNotificationDispatch): Promise<NotificationDispatch> {
    const [created] = await db.insert(notificationDispatches).values(d).returning();
    return created;
  }

  async getBranches(): Promise<Branch[]> {
    return db.select().from(branches).orderBy(desc(branches.id));
  }

  async getBranch(id: number): Promise<Branch | undefined> {
    const [b] = await db.select().from(branches).where(eq(branches.id, id));
    return b;
  }

  async createBranch(b: InsertBranch): Promise<Branch> {
    const [created] = await db.insert(branches).values(b).returning();
    return created;
  }

  async updateBranch(id: number, data: Partial<InsertBranch>): Promise<Branch | undefined> {
    const [updated] = await db.update(branches).set(data).where(eq(branches.id, id)).returning();
    return updated;
  }

  async deleteBranch(id: number): Promise<void> {
    await db.delete(branches).where(eq(branches.id, id));
  }

  async getCustomerQueries(): Promise<CustomerQuery[]> {
    return db.select().from(customerQueries).orderBy(desc(customerQueries.id));
  }

  async getCustomerQuery(id: number): Promise<CustomerQuery | undefined> {
    const [q] = await db.select().from(customerQueries).where(eq(customerQueries.id, id));
    return q;
  }

  async createCustomerQuery(q: InsertCustomerQuery): Promise<CustomerQuery> {
    const [created] = await db.insert(customerQueries).values(q).returning();
    return created;
  }

  async updateCustomerQuery(id: number, data: Partial<InsertCustomerQuery>): Promise<CustomerQuery | undefined> {
    const [updated] = await db.update(customerQueries).set(data).where(eq(customerQueries.id, id)).returning();
    return updated;
  }

  async deleteCustomerQuery(id: number): Promise<void> {
    await db.delete(customerQueries).where(eq(customerQueries.id, id));
  }

  async getSupportCategories(): Promise<SupportCategory[]> {
    return db.select().from(supportCategories).orderBy(desc(supportCategories.id));
  }

  async getSupportCategory(id: number): Promise<SupportCategory | undefined> {
    const [cat] = await db.select().from(supportCategories).where(eq(supportCategories.id, id));
    return cat;
  }

  async createSupportCategory(c: InsertSupportCategory): Promise<SupportCategory> {
    const [cat] = await db.insert(supportCategories).values(c).returning();
    return cat;
  }

  async updateSupportCategory(id: number, data: Partial<InsertSupportCategory>): Promise<SupportCategory | undefined> {
    const [updated] = await db.update(supportCategories).set(data).where(eq(supportCategories.id, id)).returning();
    return updated;
  }

  async deleteSupportCategory(id: number): Promise<void> {
    await db.delete(supportCategories).where(eq(supportCategories.id, id));
  }

  async getExpenses(): Promise<Expense[]> {
    return db.select().from(expenses).orderBy(desc(expenses.id));
  }
  async getExpense(id: number): Promise<Expense | undefined> {
    const [e] = await db.select().from(expenses).where(eq(expenses.id, id));
    return e;
  }
  async createExpense(e: InsertExpense): Promise<Expense> {
    const [created] = await db.insert(expenses).values(e).returning();
    return created;
  }
  async updateExpense(id: number, data: Partial<InsertExpense>): Promise<Expense | undefined> {
    const [updated] = await db.update(expenses).set(data).where(eq(expenses.id, id)).returning();
    return updated;
  }
  async deleteExpense(id: number): Promise<void> {
    await db.delete(expenses).where(eq(expenses.id, id));
  }

  async getAttendanceRecords(employeeId?: number): Promise<(Attendance & { employeeName?: string })[]> {
    const result = await db
      .select({
        id: attendance.id,
        employeeId: attendance.employeeId,
        date: attendance.date,
        checkIn: attendance.checkIn,
        checkOut: attendance.checkOut,
        status: attendance.status,
        hoursWorked: attendance.hoursWorked,
        overtime: attendance.overtime,
        notes: attendance.notes,
        location: attendance.location,
        employeeName: employees.fullName,
      })
      .from(attendance)
      .leftJoin(employees, eq(attendance.employeeId, employees.id))
      .orderBy(desc(attendance.id));
    if (employeeId) {
      return result.filter(r => r.employeeId === employeeId);
    }
    return result.map(r => ({ ...r, employeeName: r.employeeName || undefined }));
  }
  async createAttendance(a: InsertAttendance): Promise<Attendance> {
    const [created] = await db.insert(attendance).values(a).returning();
    return created;
  }
  async updateAttendance(id: number, data: Partial<InsertAttendance>): Promise<Attendance | undefined> {
    const [updated] = await db.update(attendance).set(data).where(eq(attendance.id, id)).returning();
    return updated;
  }
  async deleteAttendance(id: number): Promise<void> {
    await db.delete(attendance).where(eq(attendance.id, id));
  }

  async getAuditLogs(): Promise<AuditLog[]> {
    return db.select().from(auditLogs).orderBy(desc(auditLogs.id)).limit(500);
  }
  async createAuditLog(log: InsertAuditLog): Promise<AuditLog> {
    const [created] = await db.insert(auditLogs).values(log).returning();
    return created;
  }

  async getCreditNotes(): Promise<(CreditNote & { customerName?: string })[]> {
    const result = await db
      .select({
        id: creditNotes.id,
        creditNoteNumber: creditNotes.creditNoteNumber,
        customerId: creditNotes.customerId,
        invoiceId: creditNotes.invoiceId,
        amount: creditNotes.amount,
        reason: creditNotes.reason,
        status: creditNotes.status,
        issueDate: creditNotes.issueDate,
        appliedDate: creditNotes.appliedDate,
        notes: creditNotes.notes,
        createdBy: creditNotes.createdBy,
        customerName: customers.fullName,
      })
      .from(creditNotes)
      .leftJoin(customers, eq(creditNotes.customerId, customers.id))
      .orderBy(desc(creditNotes.id));
    return result.map(r => ({ ...r, customerName: r.customerName || undefined }));
  }
  async getCreditNote(id: number): Promise<CreditNote | undefined> {
    const [cn] = await db.select().from(creditNotes).where(eq(creditNotes.id, id));
    return cn;
  }
  async createCreditNote(cn: InsertCreditNote): Promise<CreditNote> {
    const [created] = await db.insert(creditNotes).values(cn).returning();
    return created;
  }
  async updateCreditNote(id: number, data: Partial<InsertCreditNote>): Promise<CreditNote | undefined> {
    const [updated] = await db.update(creditNotes).set(data).where(eq(creditNotes.id, id)).returning();
    return updated;
  }
  async deleteCreditNote(id: number): Promise<void> {
    await db.delete(creditNotes).where(eq(creditNotes.id, id));
  }

  async getBulkMessages(): Promise<BulkMessage[]> {
    return db.select().from(bulkMessages).orderBy(desc(bulkMessages.id));
  }
  async getBulkMessage(id: number): Promise<BulkMessage | undefined> {
    const [m] = await db.select().from(bulkMessages).where(eq(bulkMessages.id, id));
    return m;
  }
  async createBulkMessage(m: InsertBulkMessage): Promise<BulkMessage> {
    const [created] = await db.insert(bulkMessages).values(m).returning();
    return created;
  }
  async updateBulkMessage(id: number, data: Partial<InsertBulkMessage>): Promise<BulkMessage | undefined> {
    const [updated] = await db.update(bulkMessages).set(data).where(eq(bulkMessages.id, id)).returning();
    return updated;
  }
  async deleteBulkMessage(id: number): Promise<void> {
    await db.delete(bulkMessages).where(eq(bulkMessages.id, id));
  }

  async getIpAddresses(): Promise<(IpAddress & { customerName?: string })[]> {
    const result = await db
      .select({
        id: ipAddresses.id,
        ipAddress: ipAddresses.ipAddress,
        subnet: ipAddresses.subnet,
        gateway: ipAddresses.gateway,
        type: ipAddresses.type,
        status: ipAddresses.status,
        customerId: ipAddresses.customerId,
        assignedDate: ipAddresses.assignedDate,
        vlan: ipAddresses.vlan,
        pool: ipAddresses.pool,
        notes: ipAddresses.notes,
        customerName: customers.fullName,
      })
      .from(ipAddresses)
      .leftJoin(customers, eq(ipAddresses.customerId, customers.id))
      .orderBy(ipAddresses.ipAddress);
    return result.map(r => ({ ...r, customerName: r.customerName || undefined }));
  }
  async getIpAddress(id: number): Promise<IpAddress | undefined> {
    const [ip] = await db.select().from(ipAddresses).where(eq(ipAddresses.id, id));
    return ip;
  }
  async createIpAddress(ip: InsertIpAddress): Promise<IpAddress> {
    const [created] = await db.insert(ipAddresses).values(ip).returning();
    return created;
  }
  async updateIpAddress(id: number, data: Partial<InsertIpAddress>): Promise<IpAddress | undefined> {
    const [updated] = await db.update(ipAddresses).set(data).where(eq(ipAddresses.id, id)).returning();
    return updated;
  }
  async deleteIpAddress(id: number): Promise<void> {
    await db.delete(ipAddresses).where(eq(ipAddresses.id, id));
  }

  async getOutages(): Promise<Outage[]> {
    return db.select().from(outages).orderBy(desc(outages.id));
  }
  async getOutage(id: number): Promise<Outage | undefined> {
    const [o] = await db.select().from(outages).where(eq(outages.id, id));
    return o;
  }
  async createOutage(o: InsertOutage): Promise<Outage> {
    const [created] = await db.insert(outages).values(o).returning();
    return created;
  }
  async updateOutage(id: number, data: Partial<InsertOutage>): Promise<Outage | undefined> {
    const [updated] = await db.update(outages).set(data).where(eq(outages.id, id)).returning();
    return updated;
  }
  async deleteOutage(id: number): Promise<void> {
    await db.delete(outages).where(eq(outages.id, id));
  }

  async getNetworkDevices(): Promise<NetworkDevice[]> {
    return db.select().from(networkDevices).orderBy(desc(networkDevices.id));
  }
  async getNetworkDevice(id: number): Promise<NetworkDevice | undefined> {
    const [d] = await db.select().from(networkDevices).where(eq(networkDevices.id, id));
    return d;
  }
  async createNetworkDevice(d: InsertNetworkDevice): Promise<NetworkDevice> {
    const [created] = await db.insert(networkDevices).values(d).returning();
    return created;
  }
  async updateNetworkDevice(id: number, data: Partial<InsertNetworkDevice>): Promise<NetworkDevice | undefined> {
    const [updated] = await db.update(networkDevices).set(data).where(eq(networkDevices.id, id)).returning();
    return updated;
  }
  async deleteNetworkDevice(id: number): Promise<void> {
    await db.delete(networkDevices).where(eq(networkDevices.id, id));
  }

  async getPppoeUsers(): Promise<(PppoeUser & { customerName?: string })[]> {
    const result = await db
      .select({
        id: pppoeUsers.id,
        username: pppoeUsers.username,
        password: pppoeUsers.password,
        customerId: pppoeUsers.customerId,
        profileName: pppoeUsers.profileName,
        serviceType: pppoeUsers.serviceType,
        status: pppoeUsers.status,
        ipAddress: pppoeUsers.ipAddress,
        macAddress: pppoeUsers.macAddress,
        uploadSpeed: pppoeUsers.uploadSpeed,
        downloadSpeed: pppoeUsers.downloadSpeed,
        dataLimit: pppoeUsers.dataLimit,
        bytesIn: pppoeUsers.bytesIn,
        bytesOut: pppoeUsers.bytesOut,
        lastOnline: pppoeUsers.lastOnline,
        nasDevice: pppoeUsers.nasDevice,
        callerStationId: pppoeUsers.callerStationId,
        sessionTimeout: pppoeUsers.sessionTimeout,
        idleTimeout: pppoeUsers.idleTimeout,
        createdAt: pppoeUsers.createdAt,
        customerName: customers.fullName,
      })
      .from(pppoeUsers)
      .leftJoin(customers, eq(pppoeUsers.customerId, customers.id))
      .orderBy(desc(pppoeUsers.id));
    return result.map(r => ({ ...r, customerName: r.customerName || undefined }));
  }
  async getPppoeUser(id: number): Promise<PppoeUser | undefined> {
    const [u] = await db.select().from(pppoeUsers).where(eq(pppoeUsers.id, id));
    return u;
  }
  async createPppoeUser(u: InsertPppoeUser): Promise<PppoeUser> {
    const [created] = await db.insert(pppoeUsers).values(u).returning();
    return created;
  }
  async updatePppoeUser(id: number, data: Partial<InsertPppoeUser>): Promise<PppoeUser | undefined> {
    const [updated] = await db.update(pppoeUsers).set(data).where(eq(pppoeUsers.id, id)).returning();
    return updated;
  }
  async deletePppoeUser(id: number): Promise<void> {
    await db.delete(pppoeUsers).where(eq(pppoeUsers.id, id));
  }

  async getRadiusProfiles(): Promise<RadiusProfile[]> {
    return db.select().from(radiusProfiles).orderBy(desc(radiusProfiles.id));
  }
  async getRadiusProfile(id: number): Promise<RadiusProfile | undefined> {
    const [p] = await db.select().from(radiusProfiles).where(eq(radiusProfiles.id, id));
    return p;
  }
  async createRadiusProfile(p: InsertRadiusProfile): Promise<RadiusProfile> {
    const [created] = await db.insert(radiusProfiles).values(p).returning();
    return created;
  }
  async updateRadiusProfile(id: number, data: Partial<InsertRadiusProfile>): Promise<RadiusProfile | undefined> {
    const [updated] = await db.update(radiusProfiles).set(data).where(eq(radiusProfiles.id, id)).returning();
    return updated;
  }
  async deleteRadiusProfile(id: number): Promise<void> {
    await db.delete(radiusProfiles).where(eq(radiusProfiles.id, id));
  }

  async getPaymentGateways(): Promise<PaymentGateway[]> {
    return db.select().from(paymentGateways).orderBy(desc(paymentGateways.id));
  }
  async getPaymentGateway(id: number): Promise<PaymentGateway | undefined> {
    const [g] = await db.select().from(paymentGateways).where(eq(paymentGateways.id, id));
    return g;
  }
  async createPaymentGateway(g: InsertPaymentGateway): Promise<PaymentGateway> {
    const [created] = await db.insert(paymentGateways).values(g).returning();
    return created;
  }
  async updatePaymentGateway(id: number, data: Partial<InsertPaymentGateway>): Promise<PaymentGateway | undefined> {
    const [updated] = await db.update(paymentGateways).set(data).where(eq(paymentGateways.id, id)).returning();
    return updated;
  }
  async deletePaymentGateway(id: number): Promise<void> {
    await db.delete(paymentGateways).where(eq(paymentGateways.id, id));
  }

  async getPayments(): Promise<(Payment & { customerName?: string })[]> {
    const result = await db
      .select({
        id: payments.id,
        paymentId: payments.paymentId,
        customerId: payments.customerId,
        invoiceId: payments.invoiceId,
        amount: payments.amount,
        method: payments.method,
        gateway: payments.gateway,
        transactionRef: payments.transactionRef,
        status: payments.status,
        paidAt: payments.paidAt,
        receivedBy: payments.receivedBy,
        notes: payments.notes,
        customerName: customers.fullName,
      })
      .from(payments)
      .leftJoin(customers, eq(payments.customerId, customers.id))
      .orderBy(desc(payments.id));
    return result.map(r => ({ ...r, customerName: r.customerName || undefined }));
  }
  async getPayment(id: number): Promise<Payment | undefined> {
    const [p] = await db.select().from(payments).where(eq(payments.id, id));
    return p;
  }
  async createPayment(p: InsertPayment): Promise<Payment> {
    const [created] = await db.insert(payments).values(p).returning();
    return created;
  }
  async updatePayment(id: number, data: Partial<InsertPayment>): Promise<Payment | undefined> {
    const [updated] = await db.update(payments).set(data).where(eq(payments.id, id)).returning();
    return updated;
  }
  async deletePayment(id: number): Promise<void> {
    await db.delete(payments).where(eq(payments.id, id));
  }

  async getBillingRules(): Promise<BillingRule[]> {
    return db.select().from(billingRules).orderBy(desc(billingRules.id));
  }
  async getBillingRule(id: number): Promise<BillingRule | undefined> {
    const [r] = await db.select().from(billingRules).where(eq(billingRules.id, id));
    return r;
  }
  async createBillingRule(r: InsertBillingRule): Promise<BillingRule> {
    const [created] = await db.insert(billingRules).values(r).returning();
    return created;
  }
  async updateBillingRule(id: number, data: Partial<InsertBillingRule>): Promise<BillingRule | undefined> {
    const [updated] = await db.update(billingRules).set(data).where(eq(billingRules.id, id)).returning();
    return updated;
  }
  async deleteBillingRule(id: number): Promise<void> {
    await db.delete(billingRules).where(eq(billingRules.id, id));
  }

  async getBandwidthUsage(): Promise<(BandwidthUsage & { customerName?: string })[]> {
    const result = await db
      .select({
        id: bandwidthUsage.id,
        customerId: bandwidthUsage.customerId,
        pppoeUserId: bandwidthUsage.pppoeUserId,
        date: bandwidthUsage.date,
        downloadMb: bandwidthUsage.downloadMb,
        uploadMb: bandwidthUsage.uploadMb,
        totalMb: bandwidthUsage.totalMb,
        peakDownload: bandwidthUsage.peakDownload,
        peakUpload: bandwidthUsage.peakUpload,
        sessionCount: bandwidthUsage.sessionCount,
        avgLatency: bandwidthUsage.avgLatency,
        customerName: customers.fullName,
      })
      .from(bandwidthUsage)
      .leftJoin(customers, eq(bandwidthUsage.customerId, customers.id))
      .orderBy(desc(bandwidthUsage.id));
    return result.map(r => ({ ...r, customerName: r.customerName || undefined }));
  }
  async getBandwidthUsageById(id: number): Promise<BandwidthUsage | undefined> {
    const [u] = await db.select().from(bandwidthUsage).where(eq(bandwidthUsage.id, id));
    return u;
  }
  async getBandwidthUsageByCustomer(customerId: number): Promise<BandwidthUsage[]> {
    return db.select().from(bandwidthUsage).where(eq(bandwidthUsage.customerId, customerId)).orderBy(desc(bandwidthUsage.id));
  }
  async createBandwidthUsage(u: InsertBandwidthUsage): Promise<BandwidthUsage> {
    const [created] = await db.insert(bandwidthUsage).values(u).returning();
    return created;
  }
  async updateBandwidthUsage(id: number, data: Partial<InsertBandwidthUsage>): Promise<BandwidthUsage | undefined> {
    const [updated] = await db.update(bandwidthUsage).set(data).where(eq(bandwidthUsage.id, id)).returning();
    return updated;
  }
  async deleteBandwidthUsage(id: number): Promise<void> {
    await db.delete(bandwidthUsage).where(eq(bandwidthUsage.id, id));
  }

  async getUsers(): Promise<User[]> {
    return db.select().from(users).orderBy(desc(users.id));
  }
  async updateUser(id: number, data: Partial<InsertUser>): Promise<User | undefined> {
    const [updated] = await db.update(users).set(data).where(eq(users.id, id)).returning();
    return updated;
  }
  async deleteUser(id: number): Promise<void> {
    await db.delete(users).where(eq(users.id, id));
  }

  async getDailyCollections(): Promise<(DailyCollection & { customerName?: string; customerCode?: string; customerPhone?: string; customerUsername?: string; monthlyBill?: string })[]> {
    const result = await db
      .select({
        id: dailyCollections.id,
        date: dailyCollections.date,
        customerId: dailyCollections.customerId,
        invoiceId: dailyCollections.invoiceId,
        amount: dailyCollections.amount,
        received: dailyCollections.received,
        vat: dailyCollections.vat,
        discount: dailyCollections.discount,
        balanceDue: dailyCollections.balanceDue,
        paymentMethod: dailyCollections.paymentMethod,
        receivedBy: dailyCollections.receivedBy,
        approvedBy: dailyCollections.approvedBy,
        createdBy: dailyCollections.createdBy,
        notes: dailyCollections.notes,
        status: dailyCollections.status,
        connectionType: dailyCollections.connectionType,
        area: dailyCollections.area,
        transactionType: dailyCollections.transactionType,
        customerName: customers.fullName,
        customerCode: customers.customerId,
        customerPhone: customers.phone,
        customerUsername: customers.usernameIp,
        monthlyBill: customers.monthlyBill,
      })
      .from(dailyCollections)
      .leftJoin(customers, eq(dailyCollections.customerId, customers.id))
      .orderBy(desc(dailyCollections.id));
    return result.map(r => ({
      ...r,
      customerName: r.customerName || undefined,
      customerCode: r.customerCode || undefined,
      customerPhone: r.customerPhone || undefined,
      customerUsername: r.customerUsername || undefined,
      monthlyBill: r.monthlyBill || undefined,
    }));
  }

  async getDailyCollection(id: number): Promise<DailyCollection | undefined> {
    const [item] = await db.select().from(dailyCollections).where(eq(dailyCollections.id, id));
    return item;
  }

  async createDailyCollection(d: InsertDailyCollection): Promise<DailyCollection> {
    const [created] = await db.insert(dailyCollections).values(d).returning();
    return created;
  }

  async updateDailyCollection(id: number, d: Partial<InsertDailyCollection>): Promise<DailyCollection | undefined> {
    const [updated] = await db.update(dailyCollections).set(d).where(eq(dailyCollections.id, id)).returning();
    return updated;
  }

  async deleteDailyCollection(id: number): Promise<void> {
    await db.delete(dailyCollections).where(eq(dailyCollections.id, id));
  }
}

export const storage = new DatabaseStorage();
