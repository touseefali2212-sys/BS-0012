# NetSphere - Enterprise ISP Billing & Management System

## Overview
Multi-tenant SaaS ISP Billing & Operations Management System for Internet Service Providers in Pakistan. Built with React + Express + PostgreSQL. Enterprise-grade with 29+ fully functional modules, each with expandable submenus and tab-based sub-features.

## Current State
Full enterprise system with 29+ modules, each with collapsible sidebar submenus and tab-based navigation for sub-features. Includes SMS/Email notifications, MikroTik/RADIUS integration, network monitoring, customer portal, payment gateway, analytics, and billing automation.

### Recent Enterprise Features
- **Customer Query Wizard**: 4-step multi-step wizard for new customer registration queries (Personal Info with file uploads, Contact Info, Network & Product, Service Info). Data-driven query list with search, status management (approve/reject/convert), and delete. Document upload endpoint for profile pictures, NID pictures, and registration forms.
- **Vendor Module (Bandwidth & Panel)**: Two vendor types - Bandwidth (CIR-based fixed monthly) and Panel (recharge/wallet-based). Vendor packages with ISP/reseller margin tracking. Wallet recharge/deduct with transaction history for panel vendors.
- **Reseller Module with Wallet**: Reseller wallet system, commission tracking, vendor linking, wallet recharge/deduct with full transaction history.
- **Expandable Sidebar Submenus**: All 19 modules now have collapsible sidebar navigation with 3-10 sub-items each
- **Tab-Based Sub-Features**: Every module page uses tab navigation matching sidebar sub-items
- **SMS Notification System**: Configurable SMS API with custom HTTP endpoint, headers, body template
- **Email Notification System**: SMTP configuration with send/test functionality
- **Notification Templates**: CRUD for reusable notification templates
- **Bulk & Campaign Notifications**: Send to multiple recipients via email or SMS
- **Multi-Service Packages**: serviceType (internet, iptv, cable_tv, bundle) with conditional fields
- **Recurring Invoices**: Auto-generate invoices for customers with recurring billing
- **Branch Management**: Multi-branch support with CRUD
- **Activity Logging**: System-wide activity log tracking
- **MikroTik Integration**: Device management for MikroTik routers, PPPoE user management with customer linking, bandwidth queue visualization
- **RADIUS/AAA Integration**: RADIUS profile management with download/upload rates, burst settings, data quotas, address pools, session/idle timeouts
- **Network Monitoring Dashboard**: Real-time device status monitoring (routers, switches, APs, OLTs, servers, UPS), CPU/memory usage, uptime tracking, multi-vendor support
- **Customer Portal**: Admin-side portal management, customer access control, portal settings configuration
- **Payment Gateway Integration**: JazzCash/Easypaisa/bank transfer support, payment recording and tracking, gateway configuration (test/live modes)
- **Auto Late Fee & Suspension**: Configurable billing rules for automatic late fees (fixed/percentage), grace periods, auto-suspension/disconnection after X days overdue
- **Customer Connection Map**: Visual area-based customer location mapping with status indicators, area grouping, customer detail popups
- **Revenue Analytics Dashboard**: Monthly revenue trends, collection rates, ARPU, customer status breakdown, revenue by package/area analysis
- **Area Management Service Availability Map**: Interactive Leaflet/OpenStreetMap map with Esri Street/Satellite/Topo tile layers, live autocomplete address search (Nominatim), GPS coordinate input, map-click pinning, customer markers
- **Multi-Branch Analytics Dashboard**: Per-branch and per-area KPI cards with Total/Active/Suspended customers, Monthly Revenue, Reseller Revenue, Expenses, Profit/Loss, Customer Growth %, Customer Closed %, New Customers this month. Backend `/api/analytics/branch-stats` endpoint computes all stats server-side.
- **Expenses Area/Branch Tagging**: Added `area` and `branch` fields to the expenses table (DB pushed). Expense form has area dropdown (auto-fills branch) for tagging expenses per area, which feeds into the branch analytics P&L calculation.
- **Customer Aging Report**: 30/60/90+ day outstanding invoice tracking with color-coded aging buckets, distribution visualization, CSV export
- **Bandwidth Usage Reports**: Per-customer bandwidth consumption tracking, download/upload statistics, top users ranking, date range filtering

## Tech Stack
- **Frontend**: React 18, Tailwind CSS, Shadcn UI, Wouter (routing), TanStack Query
- **Backend**: Express.js with session-based auth, Nodemailer for emails
- **Database**: PostgreSQL with Drizzle ORM
- **Auth**: Session-based with express-session

## Project Structure
```
client/src/
  App.tsx              - Main app with auth flow, routing (19 routes), sidebar layout
  components/
    app-sidebar.tsx    - Collapsible sidebar with submenus for all 19 modules
    theme-provider.tsx - Dark/light theme toggle
    ui/                - Shadcn components (includes collapsible, tabs, etc.)
  hooks/
    use-auth.ts        - Authentication hook
    use-tab.ts         - URL-synced tab state management hook
  pages/
    dashboard.tsx      - 4 tabs: Overview, Customers Dashboard, Revenue, Quick Actions
    customers.tsx      - 5 tabs: Customer Type, Add, List, Query New, Query List
    customer-profile.tsx - 5 tabs: Overview, Invoices, Tickets, Connection, Notes
    packages.tsx       - 3 tabs: Packages List, Tax & Extra Fee, Reseller Packages
    invoices.tsx       - 4 tabs: Invoice Type, Add, List, Collection Allocation
    tickets.tsx        - 3 tabs: Support Type, Tickets, History
    areas.tsx          - 5 tabs: Add, List, Allocation, Availability, Multi Branch
    vendors.tsx        - 3 tabs: Add, List, Account
    resellers.tsx      - 5 tabs: Type, Add, List, Wallet, Commission
    accounting.tsx     - 5 tabs: Account Type, Add, Income, Expense, Budget
    transactions.tsx   - 8 tabs: Type, List, Customer/Reseller Collections, Refund, Transfer, Wallet, Approval
    tasks.tsx          - 5 tabs: Project, Tasks, Team, Progress, Audit
    assets.tsx         - 5 tabs: Type, List, Requests, Tracking, Allocation
    inventory.tsx      - 10 tabs: Type, Suppliers, Brands, PO, Stock, Purchase, Sales, List, Batch, Warranty
    hr.tsx             - 9 tabs: Add, List, Roles, Shifts, Attendance, Salary, Bonus, Advance, Leave
    access.tsx         - 3 tabs: Roles, Staff Users, Areas Allocation
    company.tsx        - 2 tabs: Company Profile, Branches & Department
    notifications.tsx  - 5 tabs: Types, Templates, Push, Bulk/Campaign, SMS & Email API
    reports.tsx        - Report management + CSV export buttons
    settings.tsx       - 9 tabs: General, Company, Billing, HRM Rights, Customer Rights, Invoice Template, Notification, Payment Gateway, Activity Log
    mikrotik.tsx       - 2 tabs: Devices, PPPoE Users
    radius.tsx         - RADIUS profile management
    network-monitoring.tsx - Network device monitoring dashboard
    customer-portal.tsx - Portal settings + customer access tabs
    payment-gateway.tsx - 2 tabs: Payments, Gateway Config
    billing-rules.tsx  - Auto late fee/suspension rules
    customer-map.tsx   - Area-based customer location map
    revenue-analytics.tsx - Revenue charts and trends
    aging-report.tsx   - 30/60/90 day invoice aging
    bandwidth-usage.tsx - Bandwidth consumption tracking

server/
  index.ts             - Express server setup
  routes.ts            - All API routes with auth middleware + notification send endpoints
  storage.ts           - Database storage layer with all CRUD operations
  db.ts                - PostgreSQL/Drizzle connection
  seed.ts              - Comprehensive seed data

shared/
  schema.ts            - Drizzle schemas (36+ tables), Zod validators, TypeScript types
```

## Database Tables
users, customers, packages, invoices, tickets, activity_logs, areas, vendors, resellers, accounts, transactions, tasks, assets, inventory_items, employees, roles, company_settings, notifications, reports, settings, customer_connections, notification_templates, smtp_settings, sms_settings, notification_dispatches, branches, vendor_wallet_transactions, reseller_wallet_transactions, vendor_packages, expenses, attendance, audit_logs, credit_notes, bulk_messages, ip_addresses, outages, network_devices, pppoe_users, radius_profiles, payment_gateways, payments, billing_rules, bandwidth_usage

## API Routes
- POST /api/auth/login, GET /api/auth/me, POST /api/auth/logout
- CRUD for: customers, packages, invoices, tickets, areas, vendors, resellers, accounts, transactions, tasks, assets, inventory, employees, roles, notifications, reports, notification-templates, branches, vendor-packages
- GET/POST /api/company (company settings)
- GET/POST/DELETE/PATCH /api/settings (system settings)
- POST/PATCH/DELETE /api/customer-connections
- GET /api/smtp-settings, POST /api/smtp-settings
- GET /api/sms-settings, POST /api/sms-settings
- GET /api/notification-dispatches
- GET /api/activity-logs
- POST /api/notifications/send-email (to, subject, body)
- POST /api/notifications/send-sms (to, message)
- POST /api/notifications/send-bulk (channel, recipients[], subject, body)
- POST /api/billing/generate-recurring
- GET /api/dashboard/stats, revenue-overview, ticket-breakdown, technician-performance
- GET /api/vendor-wallet-transactions/:vendorId
- POST /api/vendor-wallet/recharge, POST /api/vendor-wallet/deduct
- GET /api/reseller-wallet-transactions/:resellerId
- POST /api/reseller-wallet/recharge, POST /api/reseller-wallet/deduct
- GET /api/vendor-packages/by-vendor/:vendorId

## Auth
- Demo credentials: admin / admin123
- Session-based auth with express-session

## Enterprise Invoice System
- **Invoice Line Items**: invoice_items table with itemType (service/product/fee/installation/equipment), description, quantity, unitPrice, discount, taxRate, taxAmount, total, packageId reference
- **Full-Page Invoice Creation**: Customer search with auto-fill, line items editor (add/remove), add packages as items, auto-calculate subtotal/discount/tax/grand total
- **Professional Invoice View**: Pakistani ISP format with blue (#0057FF) branded header, company info (NTN, registration), customer billing details, itemized table, totals breakdown, print support
- **Invoice Edit**: Pre-fills all existing data including line items, allows adding/removing items
- **API**: POST /api/invoices-with-items, PUT /api/invoices-with-items/:id, GET /api/invoices/:id/full, CRUD /api/invoice-items

## Future Expansion Roadmap

### Billing & Payments
- **Payment Gateway Integration**: Accept online payments via JazzCash, Easypaisa, or Stripe so customers can pay invoices directly
- **Auto Late Fee Calculation**: Automatically add late fees to overdue invoices based on configurable rules (percentage or fixed amount, grace period)
- **Payment Receipt Generation**: Printable receipts when payments are collected with company branding
- **Invoice Email/SMS Sending**: Send invoices directly to customers via email or SMS from the invoice view page

### Customer Experience
- **Customer Portal**: Separate login for customers to view invoices, make payments, and submit support tickets
- **Customer Connection Map**: Visual map showing customer locations and network coverage areas using leaflet/mapbox
- **Service Usage Dashboard**: Bandwidth usage charts and data consumption tracking per customer

### Operations & Automation
- **Auto Invoice Generation**: Schedule monthly invoice generation for all active customers based on their package and billing cycle
- **Ticket Assignment & SLA Tracking**: Auto-assign tickets to technicians with SLA countdown timers and escalation rules
- **Expense Tracking with Vendor Payments**: Track operational expenses and automate vendor payment schedules

### Reporting & Analytics
- **Revenue Analytics Dashboard**: Charts showing monthly revenue trends, collection rates, and churn analysis
- **Customer Aging Report**: Shows how long invoices have been outstanding (30/60/90 days)
- **Technician Performance Scorecards**: Track ticket resolution times, customer ratings, and workload

### Infrastructure
- **Network Monitoring Integration**: Connect to MikroTik/RADIUS to show real-time connection status
- **IP Address Management (IPAM)**: Track and allocate IP addresses across the network
- **Backup & Data Export**: Export all data to CSV/Excel for offline reporting

## Sidebar Navigation (Collapsible Submenus)
1. Overview: Dashboard (Overview, Customers Dashboard, Revenue, Quick Actions)
2. Management: Company Profile, Vendors, Packages, Area Management
3. HR & People: HR & Payroll, HRM
4. Customers & Resellers: Customers, Reseller Management
5. Billing & Finance: Support & Ticket, Sale, Accounting, Transactions
6. Operations: Task Management, Assets, Inventory
7. System: Notifications, All Reports, Settings
